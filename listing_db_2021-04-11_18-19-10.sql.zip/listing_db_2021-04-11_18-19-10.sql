-- MySQL dump 10.16  Distrib 10.1.47-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: listing_db
-- ------------------------------------------------------
-- Server version	10.1.47-MariaDB-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `listing_db`
--


--
-- Table structure for table `advertising`
--

DROP TABLE IF EXISTS `advertising`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advertising` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `integration` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'unitSlot or autoFit',
  `is_responsive` tinyint(1) DEFAULT '0',
  `slug` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `provider_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Translated in the languages files',
  `tracking_code_large` mediumtext COLLATE utf8_unicode_ci,
  `tracking_code_medium` mediumtext COLLATE utf8_unicode_ci,
  `tracking_code_small` mediumtext COLLATE utf8_unicode_ci,
  `active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `advertising_slug_unique` (`slug`),
  KEY `advertising_active_index` (`active`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `advertising`
--

LOCK TABLES `advertising` WRITE;
/*!40000 ALTER TABLE `advertising` DISABLE KEYS */;
INSERT INTO `advertising` VALUES (1,'unitSlot',0,'top','Google AdSense','advertising_unitSlot_hint','','','',1),(2,'unitSlot',0,'bottom','Google AdSense','advertising_unitSlot_hint','','','',1),(3,'autoFit',1,'auto','Google AdSense','advertising_autoFit_hint','','','',1);
/*!40000 ALTER TABLE `advertising` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blacklist`
--

DROP TABLE IF EXISTS `blacklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blacklist` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('domain','email','ip','word') COLLATE utf8_unicode_ci DEFAULT NULL,
  `entry` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `blacklist_type_entry_index` (`type`,`entry`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blacklist`
--

LOCK TABLES `blacklist` WRITE;
/*!40000 ALTER TABLE `blacklist` DISABLE KEYS */;
INSERT INTO `blacklist` VALUES (4,'email','chiefyonani@gmail.com'),(3,'email','drmamafaima@gmail.com'),(1,'email','mamashamie@gmail.com'),(2,'email','sultanbahoo87@gmail.com');
/*!40000 ALTER TABLE `blacklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `key` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `expiration` int(11) NOT NULL,
  UNIQUE KEY `cache_key_unique` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `translation_lang` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `translation_of` int(10) unsigned DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `icon_class` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `depth` int(10) unsigned DEFAULT NULL,
  `type` enum('classified','job-offer','job-search','not-salable') COLLATE utf8_unicode_ci DEFAULT 'classified' COMMENT 'Only select this for parent categories',
  `is_for_permanent` tinyint(1) DEFAULT '0',
  `active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `categories_translation_lang_index` (`translation_lang`),
  KEY `categories_translation_of_index` (`translation_of`),
  KEY `categories_parent_id_index` (`parent_id`),
  KEY `categories_slug_index` (`slug`),
  KEY `categories_lft_translation_lang_index` (`lft`,`translation_lang`),
  KEY `categories_rgt_translation_lang_index` (`rgt`,`translation_lang`),
  KEY `categories_depth_translation_lang_index` (`depth`,`translation_lang`)
) ENGINE=InnoDB AUTO_INCREMENT=135 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'en',1,NULL,'Automobiles','automobiles',NULL,'app/categories/skin-red/car.png',NULL,4,5,3,'classified',0,1),(2,'en',2,1,'Cars','cars',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,4,5,3,'classified',0,1),(3,'en',3,1,'Buses & Minibus','buses-and-minibus',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,2,3,3,'classified',0,1),(4,'en',4,1,'Heavy Equipment','heavy-equipment',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,6,7,3,'classified',0,1),(5,'en',5,1,'Motorcycles & Scooters','motorcycles-and-scooters',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,8,7,9,'classified',0,1),(6,'en',6,1,'Trucks & Trailers','trucks-and-trailers',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,8,7,1,'classified',0,1),(7,'en',7,1,'Vehicle Parts & Accessories','car-parts-and-accessories',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,8,9,4,'classified',0,1),(8,'en',8,1,'Watercraft & Boats','watercraft-and-boats',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,10,11,3,'classified',0,1),(9,'en',9,NULL,'Phones & Tablets','phones-and-tablets',NULL,'app/categories/skin-red/mobile-alt.png','icon-laptop',16,17,2,'classified',0,1),(10,'en',10,9,'Mobile Phones','mobile-phones',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,8,7,9,'classified',0,1),(11,'en',11,9,'Accessories for Mobile Phones & Tablets','mobile-phones-tablets-accessories',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,7,8,5,'classified',0,1),(12,'en',12,9,'Smart Watches & Trackers','smart-watches-and-trackers',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,8,7,9,'classified',0,1),(13,'en',13,9,'Tablets','tablets',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,7,8,5,'classified',0,1),(14,'en',14,NULL,'Electronics','electronics',NULL,'app/categories/skin-red/fa-laptop.png','icon-theatre',8,7,1,'classified',0,1),(15,'en',15,14,'Accessories & Supplies for Electronics','accessories-supplies for Electronics',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,7,8,5,'classified',0,1),(16,'en',16,14,'Laptops & Computers','laptops-and-computers',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,8,7,9,'classified',0,1),(17,'en',17,14,'TV & DVD Equipment','tv-dvd-equipment',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,7,8,5,'classified',0,1),(18,'en',18,14,'Audio & Music Equipment','audio-music-equipment',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,8,7,9,'classified',0,1),(19,'en',19,14,'Computer Accessories','computer-accessories',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,7,2,5,'classified',0,1),(20,'en',20,14,'Computer Hardware','computer-hardware',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,2,3,3,'classified',0,1),(21,'en',21,14,'Computer Monitors','computer-monitors',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,3,2,4,'classified',0,1),(22,'en',22,14,'Headphones','headphones',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,2,3,3,'classified',0,1),(23,'en',23,14,'Networking Products','networking-products',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,3,4,4,'classified',0,1),(24,'en',24,14,'Photo & Video Cameras','photo-video-cameras',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,4,5,3,'classified',0,1),(25,'en',25,14,'Printers & Scanners','printers-and-scanners',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,5,6,3,'classified',0,1),(26,'en',26,14,'Security & Surveillance','security-and-surveillance',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,6,7,3,'classified',0,1),(27,'en',27,14,'Software','software',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,7,8,6,'classified',0,1),(28,'en',28,14,'Video Games','video-games',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,8,7,9,'classified',0,1),(29,'en',29,14,'Game Consoles','video-game-consoles',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,7,8,6,'classified',0,1),(30,'en',30,NULL,'Furniture & Appliances','furniture-appliances',NULL,'app/categories/skin-red/couch.png','icon-basket-1',10,11,3,'classified',0,1),(31,'en',31,30,'Furniture - Tableware','furniture-tableware',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,7,8,2,'classified',0,1),(32,'en',32,30,'Antiques - Art - Decoration','antiques-art-decoration',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,8,9,4,'classified',0,1),(33,'en',33,30,'Appliances','appliances',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,9,8,4,'classified',0,1),(34,'en',34,30,'Garden','garden',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,8,9,4,'classified',0,1),(35,'en',35,30,'Toys - Games - Figurines','toys-games-figurines',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,9,10,4,'classified',0,1),(36,'en',36,30,'Wine & Gourmet - Recipes','wine-gourmet-recipes',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,10,11,3,'classified',0,1),(37,'en',37,NULL,'Real estate','real-estate',NULL,'app/categories/skin-red/fa-home.png','icon-home',18,19,2,'classified',0,1),(38,'en',38,37,'Houses & Apartments For Rent','houses-apartments-for-rent',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,14,15,1,'classified',0,1),(39,'en',39,37,'Houses & Apartments For Sale','houses-apartments-for-sale',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,15,16,2,'classified',0,1),(40,'en',40,37,'Land & Plots for Rent','land-and-plots-for-rent',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,16,17,2,'classified',0,1),(41,'en',41,37,'Land & Plots For Sale','land-and-plots-for-sale',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,17,18,2,'classified',0,1),(42,'en',42,37,'Commercial Property For Rent','commercial-property-for-rent',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,18,19,2,'classified',0,1),(43,'en',43,37,'Commercial Property For Sale','commercial-properties',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,19,20,2,'classified',0,1),(44,'en',44,37,'Event centres, Venues and Workstations','event-centers-and-venues',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,20,21,2,'classified',0,1),(45,'en',45,37,'Short Rental','temporary-and-vacation-rentals',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,21,22,2,'classified',0,1),(46,'en',46,NULL,'Animals & Pets','animals-and-pets',NULL,'app/categories/skin-red/paw.png','icon-guidedog',2,3,3,'classified',0,1),(47,'en',47,46,'Birds','birds',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,25,26,0,'classified',0,1),(48,'en',48,46,'Cats & Kittens','cats-and-kittens',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,26,27,1,'classified',0,1),(49,'en',49,46,'Dogs','dogs-and-puppies',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,27,28,1,'classified',0,1),(50,'en',50,46,'Fish','fish',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,28,29,1,'classified',0,1),(51,'en',51,46,'Pet\'s Accessories','pets-accessories',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,29,30,1,'classified',0,1),(52,'en',52,46,'Reptiles','reptiles',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,30,31,1,'classified',0,1),(53,'en',53,46,'Other Animals','other-animals',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,31,32,1,'classified',0,1),(54,'en',54,NULL,'Fashion','fashion',NULL,'app/categories/skin-red/tshirt.png','icon-heart',8,9,4,'classified',0,1),(55,'en',55,54,'Bags','bags',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,35,36,0,'classified',0,1),(56,'en',56,54,'Clothing','clothing',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,36,37,1,'classified',0,1),(57,'en',57,54,'Clothing Accessories','clothing-accessories',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,37,38,1,'classified',0,1),(58,'en',58,54,'Jewelry','jewelry',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,38,39,1,'classified',0,1),(59,'en',59,54,'Shoes','shoes',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,39,40,1,'classified',0,1),(60,'en',60,54,'Watches','watches',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,40,41,1,'classified',0,1),(61,'en',61,54,'Wedding Wear & Accessories','wedding-wear-accessories',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,41,42,1,'classified',0,1),(62,'en',62,NULL,'Beauty & Well being','beauty-well-being',NULL,'app/categories/skin-red/spa.png','icon-search',6,7,3,'classified',0,1),(63,'en',63,62,'Bath & Body','bath-and-body',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,45,46,0,'classified',0,1),(64,'en',64,62,'Fragrance','fragrance',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,46,47,1,'classified',0,1),(65,'en',65,62,'Hair Beauty','hair-beauty',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,47,48,1,'classified',0,1),(66,'en',66,62,'Makeup','makeup',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,48,49,1,'classified',0,1),(67,'en',67,62,'Sexual Wellness','sexual-wellness',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,49,50,1,'classified',0,1),(68,'en',68,62,'Skin Care','skin-care',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,50,51,1,'classified',0,1),(69,'en',69,62,'Tobacco Accessories','tobacco-accessories',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,51,52,1,'classified',0,1),(70,'en',70,62,'Tools & Accessories','tools-and-accessories',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,52,53,1,'classified',0,1),(71,'en',71,62,'Vitamins & Supplements','vitamins-and-supplements',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,53,54,1,'classified',0,1),(72,'en',72,62,'Pro Massage','pro-massage',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,54,55,1,'classified',0,1),(73,'en',73,NULL,'Jobs','jobs',NULL,'app/categories/skin-red/mfglabs-users.png','icon-megaphone-1',12,13,0,'job-offer',0,1),(74,'en',74,73,'Agriculture - Environment','agriculture-environment',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,58,59,0,'job-offer',0,1),(75,'en',75,73,'Assistantship - Secretariat - Helpdesk','assistantship-secretariat-helpdesk',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,59,60,1,'job-offer',0,1),(76,'en',76,73,'Automotive - Mechanic','automotive-mechanic',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,60,61,1,'job-offer',0,1),(77,'en',77,73,'BTP - Construction - Building','btp-construction-building',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,61,62,1,'job-offer',0,1),(78,'en',78,73,'Trade - Business Services','trade-business-services',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,62,63,1,'job-offer',0,1),(79,'en',79,73,'Commercial - Sale Jobs','commercial-sale-jobs',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,63,64,1,'job-offer',0,1),(80,'en',80,73,'Accounting - Management - Finance','accounting-management-finance',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,64,65,1,'job-offer',0,1),(81,'en',81,73,'Steering - Manager','steering-manager',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,65,66,1,'job-offer',0,1),(82,'en',82,73,'Aesthetics - Hair - Beauty','aesthetics-hair-beauty',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,66,67,1,'job-offer',0,1),(83,'en',83,73,'Public Service Jobs','public-service-jobs',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,67,68,1,'job-offer',0,1),(84,'en',84,73,'Real Estate Jobs','real-estate-jobs',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,68,69,1,'job-offer',0,1),(85,'en',85,73,'Independent - Freelance - Telecommuting','independent-freelance-telecommuting',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,69,70,1,'job-offer',0,1),(86,'en',86,73,'Computers - Internet - Telecommunications','computers-internet-telecommunications',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,70,71,1,'job-offer',0,1),(87,'en',87,73,'Industry, Production & engineering','industry-production-engineering',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,71,72,1,'job-offer',0,1),(88,'en',88,73,'Marketing - Communication','marketing-communication',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,72,73,1,'job-offer',0,1),(89,'en',89,73,'Babysitting - Nanny Work','babysitting-nanny-work',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,73,74,1,'job-offer',0,1),(90,'en',90,73,'HR - Training - Education','hr-training-education',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,74,75,1,'job-offer',0,1),(91,'en',91,73,'Medical - Healthcare - Social','medical-healthcare-social',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,75,76,1,'job-offer',0,1),(92,'en',92,73,'Security - Guarding','security-guarding',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,76,77,1,'job-offer',0,1),(93,'en',93,73,'Household Services - Housekeeping','household-services-housekeeping',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,77,78,1,'job-offer',0,1),(94,'en',94,73,'Tourism - Hotels - Restaurants - Leisure','tourism-hotels-restaurants-leisure',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,78,79,1,'job-offer',0,1),(95,'en',95,73,'Transportation - Logistics','transportation-logistics',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,79,80,1,'job-offer',0,1),(96,'en',96,73,'Others Jobs Offer','others-jobs-offer',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,80,81,1,'job-offer',0,1),(97,'en',97,NULL,'Services','services',NULL,'app/categories/skin-red/ion-clipboard.png','fa fa-briefcase',20,21,2,'classified',0,1),(98,'en',98,97,'Casting, Model, Photographer','casting-model-photographer',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,84,85,0,'classified',0,1),(99,'en',99,97,'Carpooling','carpooling',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,85,86,1,'classified',0,1),(100,'en',100,97,'Moving, Furniture Guard','moving-furniture-guard',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,86,87,1,'classified',0,1),(101,'en',101,97,'Destocking - Commercial','destocking-commercial',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,87,88,1,'classified',0,1),(102,'en',102,97,'Industrial Equipment','industrial-equipment',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,88,89,1,'classified',0,1),(103,'en',103,97,'Aesthetics, Hairstyling','aesthetics-hairstyling',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,89,90,1,'classified',0,1),(104,'en',104,97,'Materials and Equipment Pro','materials-and-equipment-pro',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,90,91,1,'classified',0,1),(105,'en',105,97,'Event Organization Services','event-organization-services',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,91,92,1,'classified',0,1),(106,'en',106,97,'Service Provision','service-provision',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,92,93,1,'classified',0,1),(107,'en',107,97,'Health, Beauty','health-beauty',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,93,94,1,'classified',0,1),(108,'en',108,97,'Artisan, Troubleshooting, Handyman','artisan-troubleshooting-handyman',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,94,95,1,'classified',0,1),(109,'en',109,97,'Computing Services','computing-services',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,95,96,1,'classified',0,1),(110,'en',110,97,'Tourism and Travel Services','tourism-and-travel-services',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,96,97,1,'classified',0,1),(111,'en',111,97,'Translation, Writing','translation-writing',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,97,98,1,'classified',0,1),(112,'en',112,97,'Construction - Renovation - Carpentry','construction-renovation-carpentry',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,98,99,1,'classified',0,1),(113,'en',113,97,'Other services','other-services',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,99,100,1,'classified',0,1),(114,'en',114,NULL,'Education','education',NULL,'app/categories/skin-red/fa-graduation-cap.png','icon-book-open',8,7,9,'classified',0,1),(115,'en',115,114,'Language Classes','language-classes',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,103,104,0,'classified',0,1),(116,'en',116,114,'Computer Courses','computer-courses',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,104,105,1,'classified',0,1),(117,'en',117,114,'Tutoring, Private Lessons','tutoring-private-lessons',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,105,106,1,'classified',0,1),(118,'en',118,114,'Vocational Training','vocational-training',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,106,107,1,'classified',0,1),(119,'en',119,114,'Maths, Physics, Chemistry','maths-physics-chemistry',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,107,108,1,'classified',0,1),(120,'en',120,114,'Music, Theatre, Dance','music-theatre-dance',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,108,109,1,'classified',0,1),(121,'en',121,114,'School support','school-support',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,109,110,1,'classified',0,1),(122,'en',122,NULL,'Local Events','local-events',NULL,'app/categories/skin-red/calendar-alt.png','icon-megaphone-1',14,15,1,'classified',0,1),(123,'en',123,122,'Concerts & Festivals','concerts-and-festivals',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,113,114,0,'classified',0,1),(124,'en',124,122,'Networking & Meetups','networking-and-meetups',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,114,115,1,'classified',0,1),(125,'en',125,122,'Sports & Outdoors','sports-and-outdoors',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,115,116,1,'classified',0,1),(126,'en',126,122,'Trade Shows & Conventions','trade-shows-conventions',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,116,117,1,'classified',0,1),(127,'en',127,122,'Training & Seminars','training-and-seminars',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,117,118,1,'classified',0,1),(128,'en',128,122,'Ceremonies','ceremonies',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,118,119,1,'classified',0,1),(129,'en',129,122,'Conferences','conferences',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,119,120,1,'classified',0,1),(130,'en',130,122,'Weddings','weddings',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,120,121,1,'classified',0,1),(131,'en',131,122,'Birthdays','birthdays',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,121,122,1,'classified',0,1),(132,'en',132,122,'Family Events','family-events',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,122,123,1,'classified',0,1),(133,'en',133,122,'Nightlife','nightlife',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,123,124,1,'classified',0,1),(134,'en',134,122,'All others events','all-others-events',NULL,'app/default/categories/fa-folder-skin-blue.png',NULL,124,125,1,'classified',0,1);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_field`
--

DROP TABLE IF EXISTS `category_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category_field` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned DEFAULT NULL,
  `field_id` int(10) unsigned DEFAULT NULL,
  `disabled_in_subcategories` tinyint(1) unsigned DEFAULT '0',
  `parent_id` int(10) unsigned DEFAULT NULL,
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `depth` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_field_category_id_field_id_unique` (`category_id`,`field_id`)
) ENGINE=InnoDB AUTO_INCREMENT=207 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_field`
--

LOCK TABLES `category_field` WRITE;
/*!40000 ALTER TABLE `category_field` DISABLE KEYS */;
INSERT INTO `category_field` VALUES (5,1,5,0,0,8,9,1),(6,1,6,0,0,18,19,1),(7,1,7,0,0,10,11,1),(8,1,8,0,0,12,13,1),(9,9,14,0,NULL,4,5,1),(10,9,15,0,NULL,2,3,1),(11,14,16,0,NULL,4,5,1),(13,30,8,0,NULL,NULL,NULL,NULL),(14,37,9,0,NULL,2,3,1),(15,37,10,0,NULL,4,5,1),(16,37,11,0,NULL,8,9,1),(17,37,12,0,NULL,10,11,1),(18,37,13,0,NULL,6,7,1),(19,54,8,0,NULL,NULL,NULL,NULL),(20,73,18,0,NULL,NULL,NULL,NULL),(21,73,19,0,NULL,NULL,NULL,NULL),(22,73,20,0,NULL,NULL,NULL,NULL),(24,122,22,0,NULL,NULL,NULL,NULL),(25,122,23,0,NULL,NULL,NULL,NULL),(49,7,84,0,NULL,NULL,NULL,NULL),(102,3,128,0,0,8,9,NULL),(143,3,159,0,0,2,3,NULL),(149,2,161,0,0,2,3,NULL),(150,4,160,0,0,2,3,NULL),(151,5,163,0,0,2,3,NULL),(152,6,164,0,0,2,3,NULL),(154,7,167,0,NULL,NULL,NULL,NULL),(155,4,168,0,0,4,5,NULL),(162,4,174,0,0,6,7,NULL),(163,4,173,0,0,10,11,NULL),(164,46,176,0,NULL,NULL,NULL,NULL),(167,3,178,0,0,10,11,NULL),(168,2,179,0,0,6,7,NULL),(169,5,180,0,0,4,5,NULL),(170,6,181,0,0,10,11,NULL),(171,6,182,0,0,6,7,NULL),(173,6,175,0,0,4,5,NULL),(175,7,179,0,NULL,NULL,NULL,NULL),(176,8,178,0,0,12,13,NULL),(177,8,185,0,0,2,3,NULL),(178,8,186,0,0,10,11,NULL),(179,8,174,0,0,8,9,NULL),(180,8,166,0,0,6,7,NULL),(182,8,187,0,0,4,5,NULL),(184,62,176,0,NULL,NULL,NULL,NULL),(185,14,176,0,NULL,NULL,NULL,NULL),(186,54,176,0,NULL,NULL,NULL,NULL),(187,114,176,0,NULL,NULL,NULL,NULL),(188,30,176,0,NULL,NULL,NULL,NULL),(189,73,176,0,NULL,NULL,NULL,NULL),(190,122,176,0,NULL,NULL,NULL,NULL),(191,9,176,0,NULL,NULL,NULL,NULL),(192,37,176,0,NULL,NULL,NULL,NULL),(193,97,176,0,NULL,NULL,NULL,NULL),(194,7,175,0,NULL,NULL,NULL,NULL),(195,6,173,0,0,8,9,NULL),(196,5,173,0,0,8,9,NULL),(197,5,175,0,0,6,7,NULL),(198,4,175,0,0,8,9,NULL),(199,2,175,0,0,4,5,NULL),(200,2,178,0,0,10,11,NULL),(201,4,178,0,0,12,13,NULL),(202,3,175,0,0,4,5,NULL),(203,2,173,0,0,8,9,NULL),(204,3,173,0,0,6,7,NULL),(205,5,178,0,0,10,11,NULL),(206,6,178,0,0,12,13,NULL);
/*!40000 ALTER TABLE `category_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cities`
--

DROP TABLE IF EXISTS `cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `country_code` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `asciiname` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitude` double(8,2) DEFAULT NULL COMMENT 'longitude in decimal degrees (wgs84)',
  `latitude` double(8,2) DEFAULT NULL COMMENT 'latitude in decimal degrees (wgs84)',
  `feature_class` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `feature_code` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subadmin1_code` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subadmin2_code` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `population` bigint(20) DEFAULT NULL,
  `time_zone` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cities_country_code_index` (`country_code`),
  KEY `cities_name_index` (`name`),
  KEY `cities_subadmin1_code_index` (`subadmin1_code`),
  KEY `cities_subadmin2_code_index` (`subadmin2_code`),
  KEY `cities_active_index` (`active`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cities`
--

LOCK TABLES `cities` WRITE;
/*!40000 ALTER TABLE `cities` DISABLE KEYS */;
INSERT INTO `cities` VALUES (1,'NA','Katima Mulilo','Katima Mulilo',24.27,-17.50,'P','PPLA','NA.28',NULL,25027,'Africa/Windhoek',1,'2017-06-13 23:00:00','2017-06-13 23:00:00'),(2,'NA','Windhoek','Windhoek',17.08,-22.56,'P','PPLC','NA.21',NULL,268132,'Africa/Windhoek',1,'2019-09-04 23:00:00','2019-09-04 23:00:00'),(3,'NA','Warmbad','Warmbad',18.73,-28.45,'P','PPL','NA.31',NULL,6700,'Africa/Windhoek',1,'2012-01-31 23:00:00','2012-01-31 23:00:00'),(4,'NA','Usakos','Usakos',15.60,-22.00,'P','PPL','NA.29',NULL,9147,'Africa/Windhoek',1,'2012-01-16 23:00:00','2012-01-16 23:00:00'),(5,'NA','Tsumeb','Tsumeb',17.72,-19.23,'P','PPL','NA.38',NULL,12190,'Africa/Windhoek',1,'2013-10-31 23:00:00','2013-10-31 23:00:00'),(6,'NA','Swakopmund','Swakopmund',14.53,-22.68,'P','PPLA','NA.29',NULL,25047,'Africa/Windhoek',1,'2018-01-18 23:00:00','2018-01-18 23:00:00'),(7,'NA','Rundu','Rundu',19.77,-17.93,'P','PPLA','NA.40',NULL,58172,'Africa/Windhoek',1,'2014-03-05 23:00:00','2014-03-05 23:00:00'),(8,'NA','Rehoboth','Rehoboth',17.09,-23.32,'P','PPL','NA.30',NULL,21377,'Africa/Windhoek',1,'2016-09-18 23:00:00','2016-09-18 23:00:00'),(9,'NA','Outjo','Outjo',16.15,-20.12,'P','PPL','NA.32',NULL,6557,'Africa/Windhoek',1,'2012-01-16 23:00:00','2012-01-16 23:00:00'),(10,'NA','Otjiwarongo','Otjiwarongo',16.65,-20.46,'P','PPLA','NA.39',NULL,21224,'Africa/Windhoek',1,'2016-12-19 23:00:00','2016-12-19 23:00:00'),(11,'NA','Otjimbingwe','Otjimbingwe',16.13,-22.35,'P','PPL','NA.29',NULL,7677,'Africa/Windhoek',1,'2012-01-16 23:00:00','2012-01-16 23:00:00'),(12,'NA','Oshakati','Oshakati',15.70,-17.79,'P','PPLA','NA.37',NULL,33618,'Africa/Windhoek',1,'2017-08-17 23:00:00','2017-08-17 23:00:00'),(13,'NA','Oranjemund','Oranjemund',16.43,-28.55,'P','PPL','NA.31',NULL,8496,'Africa/Windhoek',1,'2014-08-17 23:00:00','2014-08-17 23:00:00'),(14,'NA','Opuwo','Opuwo',13.84,-18.06,'P','PPLA','NA.32',NULL,5101,'Africa/Windhoek',1,'2017-06-13 23:00:00','2017-06-13 23:00:00'),(15,'NA','Ongwediva','Ongwediva',15.77,-17.78,'P','PPL','NA.37',NULL,9654,'Africa/Windhoek',1,'2012-01-16 23:00:00','2012-01-16 23:00:00'),(16,'NA','Ondangwa','Ondangwa',15.95,-17.92,'P','PPL','NA.37',NULL,9124,'Africa/Windhoek',1,'2012-01-16 23:00:00','2012-01-16 23:00:00'),(17,'NA','Omuthiya','Omuthiya',16.58,-18.36,'P','PPLA','NA.38',NULL,5000,'Africa/Windhoek',1,'2017-05-10 23:00:00','2017-05-10 23:00:00'),(18,'NA','Omaruru','Omaruru',15.93,-21.43,'P','PPL','NA.29',NULL,11547,'Africa/Windhoek',1,'2012-01-16 23:00:00','2012-01-16 23:00:00'),(19,'NA','Okakarara','Okakarara',17.43,-20.58,'P','PPL','NA.39',NULL,5255,'Africa/Windhoek',1,'2012-01-16 23:00:00','2012-01-16 23:00:00'),(20,'NA','Okahao','Okahao',15.07,-17.89,'P','PPLA2','NA.36','NA.36.11979320',7000,'Africa/Windhoek',1,'2018-11-25 23:00:00','2018-11-25 23:00:00'),(21,'NA','Okahandja','Okahandja',16.92,-21.98,'P','PPL','NA.39',NULL,20879,'Africa/Windhoek',1,'2012-01-16 23:00:00','2012-01-16 23:00:00'),(22,'NA','Nkurenkuru','Nkurenkuru',18.60,-17.62,'P','PPLA','NA.41',NULL,0,'Africa/Windhoek',1,'2014-03-05 23:00:00','2014-03-05 23:00:00'),(23,'NA','Mariental','Mariental',17.97,-24.63,'P','PPLA','NA.30',NULL,13380,'Africa/Windhoek',1,'2013-06-27 23:00:00','2013-06-27 23:00:00'),(24,'NA','Lüderitz','Luderitz',15.15,-26.65,'P','PPL','NA.31',NULL,15137,'Africa/Windhoek',1,'2018-01-28 23:00:00','2018-01-28 23:00:00'),(25,'NA','Khorixas','Khorixas',14.97,-20.37,'P','PPL','NA.32',NULL,12021,'Africa/Windhoek',1,'2012-01-16 23:00:00','2012-01-16 23:00:00'),(26,'NA','Keetmanshoop','Keetmanshoop',18.13,-26.58,'P','PPLA','NA.31',NULL,15608,'Africa/Windhoek',1,'2012-01-13 23:00:00','2012-01-13 23:00:00'),(27,'NA','Katutura','Katutura',17.06,-22.52,'P','PPLX','NA.21',NULL,21243,'Africa/Windhoek',1,'2018-02-24 23:00:00','2018-02-24 23:00:00'),(28,'NA','Karibib','Karibib',15.83,-21.93,'P','PPL','NA.29',NULL,6898,'Africa/Windhoek',1,'2012-01-16 23:00:00','2012-01-16 23:00:00'),(29,'NA','Karasburg','Karasburg',18.75,-28.02,'P','PPL','NA.31',NULL,6054,'Africa/Windhoek',1,'2013-10-25 23:00:00','2013-10-25 23:00:00'),(30,'NA','Grootfontein','Grootfontein',18.12,-19.57,'P','PPL','NA.39',NULL,24099,'Africa/Windhoek',1,'2014-08-18 23:00:00','2014-08-18 23:00:00'),(31,'NA','Gobabis','Gobabis',18.97,-22.45,'P','PPLA','NA.35',NULL,16321,'Africa/Windhoek',1,'2012-01-13 23:00:00','2012-01-13 23:00:00'),(32,'NA','Eenhana','Eenhana',16.33,-17.47,'P','PPLA','NA.33',NULL,0,'Africa/Windhoek',1,'2012-01-13 23:00:00','2012-01-13 23:00:00'),(33,'NA','Bethanie','Bethanie',17.15,-26.48,'P','PPL','NA.31',NULL,10363,'Africa/Windhoek',1,'2012-01-16 23:00:00','2012-01-16 23:00:00'),(34,'NA','Walvis Bay','Walvis Bay',14.51,-22.96,'P','PPL','NA.29',NULL,52058,'Africa/Windhoek',1,'2019-09-04 23:00:00','2019-09-04 23:00:00'),(35,'NA','Outapi','Outapi',14.98,-17.50,'P','PPLA','NA.36',NULL,2640,'Africa/Windhoek',1,'2013-10-08 23:00:00','2013-10-08 23:00:00');
/*!40000 ALTER TABLE `cities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `continents`
--

DROP TABLE IF EXISTS `continents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `continents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `continents_code_unique` (`code`),
  KEY `continents_active_index` (`active`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `continents`
--

LOCK TABLES `continents` WRITE;
/*!40000 ALTER TABLE `continents` DISABLE KEYS */;
INSERT INTO `continents` VALUES (1,'AF','Africa',1),(2,'AN','Antarctica',1),(3,'AS','Asia',1),(4,'EU','Europe',1),(5,'NA','North America',1),(6,'OC','Oceania',1),(7,'SA','South America',1);
/*!40000 ALTER TABLE `continents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `iso3` char(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `iso_numeric` int(10) unsigned DEFAULT NULL,
  `fips` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `asciiname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `capital` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `area` int(10) unsigned DEFAULT NULL,
  `population` int(10) unsigned DEFAULT NULL,
  `continent_code` char(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tld` char(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `currency_code` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postal_code_format` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postal_code_regex` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `languages` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `neighbours` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `equivalent_fips_code` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `background_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_type` enum('0','1','2') COLLATE utf8_unicode_ci DEFAULT '0',
  `admin_field_active` tinyint(1) unsigned DEFAULT '0',
  `active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `countries_code_unique` (`code`),
  KEY `countries_active_index` (`active`)
) ENGINE=InnoDB AUTO_INCREMENT=253 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` VALUES (1,'AD','AND',20,'AN','Andorra','Andorra','Andorra la Vella',468,84000,'EU','.ad','EUR','376','AD###','^(?:AD)*(d{3})$','ca','ES,FR','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(2,'AE','ARE',784,'AE','al-Imārāt','United Arab Emirates','Abu Dhabi',82880,4975593,'AS','.ae','AED','971','','','ar-AE,fa,en,hi,ur','SA,OM','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(3,'AF','AFG',4,'AF','Afġānistān','Afghanistan','Kabul',647500,29121286,'AS','.af','AFN','93','','','fa-AF,ps,uz-AF,tk','TM,CN,IR,TJ,PK,UZ','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(4,'AG','ATG',28,'AC','Antigua and Barbuda','Antigua and Barbuda','St. John\'s',443,86754,'NA','.ag','XCD','+1-268','','','en-AG','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(5,'AI','AIA',660,'AV','Anguilla','Anguilla','The Valley',102,13254,'NA','.ai','XCD','+1-264','','','en-AI','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(6,'AL','ALB',8,'AL','Shqipëria','Albania','Tirana',28748,2986952,'EU','.al','ALL','355','','','sq,el','MK,GR,ME,RS,XK','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(7,'AM','ARM',51,'AM','Hayastan','Armenia','Yerevan',29800,2968000,'AS','.am','AMD','374','######','^(d{6})$','hy','GE,IR,AZ,TR','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(8,'AN','ANT',530,'NT','Netherlands Antilles','Netherlands Antilles','Willemstad',960,136197,'NA','.an','ANG','599','','','nl-AN,en,es','GP','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(9,'AO','AGO',24,'AO','Angola','Angola','Luanda',1246700,13068161,'AF','.ao','AOA','244','','','pt-AO','CD,NA,ZM,CG','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(10,'AQ','ATA',10,'AY','Antarctica','Antarctica','',14000000,0,'AN','.aq','','','','','','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(11,'AR','ARG',32,'AR','Argentina','Argentina','Buenos Aires',2766890,41343201,'SA','.ar','ARS','54','@####@@@','^([A-Z]d{4}[A-Z]{3})$','es-AR,en,it,de,fr,gn','CL,BO,UY,PY,BR','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(12,'AS','ASM',16,'AQ','American Samoa','American Samoa','Pago Pago',199,57881,'OC','.as','USD','+1-684','','','en-AS,sm,to','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(13,'AT','AUT',40,'AU','Österreich','Austria','Vienna',83858,8205000,'EU','.at','EUR','43','####','^(d{4})$','de-AT,hr,hu,sl','CH,DE,HU,SK,CZ,IT,SI,LI','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(14,'AU','AUS',36,'AS','Australia','Australia','Canberra',7686850,21515754,'OC','.au','AUD','61','####','^(d{4})$','en-AU','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(15,'AW','ABW',533,'AA','Aruba','Aruba','Oranjestad',193,71566,'NA','.aw','AWG','297','','','nl-AW,es,en','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(16,'AX','ALA',248,'','Aland Islands','Aland Islands','Mariehamn',1580,26711,'EU','.ax','EUR','+358-18','#####','^(?:FI)*(d{5})$','sv-AX','','FI',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(17,'AZ','AZE',31,'AJ','Azərbaycan','Azerbaijan','Baku',86600,8303512,'AS','.az','AZN','994','AZ ####','^(?:AZ)*(d{4})$','az,ru,hy','GE,IR,AM,TR,RU','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(18,'BA','BIH',70,'BK','Bosna i Hercegovina','Bosnia and Herzegovina','Sarajevo',51129,4590000,'EU','.ba','BAM','387','#####','^(d{5})$','bs,hr-BA,sr-BA','HR,ME,RS','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(19,'BB','BRB',52,'BB','Barbados','Barbados','Bridgetown',431,285653,'NA','.bb','BBD','+1-246','BB#####','^(?:BB)*(d{5})$','en-BB','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(20,'BD','BGD',50,'BG','Bāṅlādēś','Bangladesh','Dhaka',144000,156118464,'AS','.bd','BDT','880','####','^(d{4})$','bn-BD,en','MM,IN','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(21,'BE','BEL',56,'BE','Belgique','Belgium','Brussels',30510,10403000,'EU','.be','EUR','32','####','^(d{4})$','nl-BE,fr-BE,de-BE','DE,NL,LU,FR','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(22,'BF','BFA',854,'UV','Burkina Faso','Burkina Faso','Ouagadougou',274200,16241811,'AF','.bf','XOF','226','','','fr-BF','NE,BJ,GH,CI,TG,ML','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(23,'BG','BGR',100,'BU','Bŭlgarija','Bulgaria','Sofia',110910,7148785,'EU','.bg','BGN','359','####','^(d{4})$','bg,tr-BG,rom','MK,GR,RO,TR,RS','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(24,'BH','BHR',48,'BA','al-Baḥrayn','Bahrain','Manama',665,738004,'AS','.bh','BHD','973','####|###','^(d{3}d?)$','ar-BH,en,fa,ur','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(25,'BI','BDI',108,'BY','Burundi','Burundi','Bujumbura',27830,9863117,'AF','.bi','BIF','257','','','fr-BI,rn','TZ,CD,RW','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(26,'BJ','BEN',204,'BN','Bénin','Benin','Porto-Novo',112620,9056010,'AF','.bj','XOF','+229','','','fr-BJ','NE,TG,BF,NG','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(27,'BL','BLM',652,'TB','Saint Barthelemy','Saint Barthelemy','Gustavia',21,8450,'NA','.gp','EUR','590','### ###','','fr','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(28,'BM','BMU',60,'BD','Bermuda','Bermuda','Hamilton',53,65365,'NA','.bm','BMD','+1-441','@@ ##','^([A-Z]{2}d{2})$','en-BM,pt','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(29,'BN','BRN',96,'BX','Brunei Darussalam','Brunei','Bandar Seri Begawan',5770,395027,'AS','.bn','BND','673','@@####','^([A-Z]{2}d{4})$','ms-BN,en-BN','MY','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(30,'BO','BOL',68,'BL','Bolivia','Bolivia','Sucre',1098580,9947418,'SA','.bo','BOB','591','','','es-BO,qu,ay','PE,CL,PY,BR,AR','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(31,'BQ','BES',535,'','Bonaire, Saint Eustatius and Saba ','Bonaire, Saint Eustatius and Saba ','',328,18012,'NA','.bq','USD','599','','','nl,pap,en','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(32,'BR','BRA',76,'BR','Brasil','Brazil','Brasilia',8511965,201103330,'SA','.br','BRL','55','#####-###','^(d{8})$','pt-BR,es,en,fr','SR,PE,BO,UY,GY,PY,GF,VE,CO,AR','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(33,'BS','BHS',44,'BF','Bahamas','Bahamas','Nassau',13940,301790,'NA','.bs','BSD','+1-242','','','en-BS','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(34,'BT','BTN',64,'BT','Druk-yul','Bhutan','Thimphu',47000,699847,'AS','.bt','BTN','975','','','dz','CN,IN','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(35,'BV','BVT',74,'BV','Bouvet Island','Bouvet Island','',49,0,'AN','.bv','NOK','','','','','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(36,'BW','BWA',72,'BC','Botswana','Botswana','Gaborone',600370,2029307,'AF','.bw','BWP','267','','','en-BW,tn-BW','ZW,ZA,NA','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(37,'BY','BLR',112,'BO','Biełaruś','Belarus','Minsk',207600,9685000,'EU','.by','BYR','375','######','^(d{6})$','be,ru','PL,LT,UA,RU,LV','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(38,'BZ','BLZ',84,'BH','Belize','Belize','Belmopan',22966,314522,'NA','.bz','BZD','501','','','en-BZ,es','GT,MX','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(39,'CA','CAN',124,'CA','Canada','Canada','Ottawa',9984670,33679000,'NA','.ca','CAD','1','@#@ #@#','^([ABCEGHJKLMNPRSTVXY]d[ABCEGHJKLMNPRSTVWXYZ]) ?(d[ABCEGHJKLMNPRSTVWXYZ]d)$ ','en-CA,fr-CA,iu','US','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(40,'CC','CCK',166,'CK','Cocos Islands','Cocos Islands','West Island',14,628,'AS','.cc','AUD','61','','','ms-CC,en','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(41,'CD','COD',180,'CG','RDC','Democratic Republic of the Congo','Kinshasa',2345410,70916439,'AF','.cd','CDF','243','','','fr-CD,ln,kg','TZ,CF,SS,RW,ZM,BI,UG,CG,AO','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(42,'CF','CAF',140,'CT','Centrafrique','Central African Republic','Bangui',622984,4844927,'AF','.cf','XAF','236','','','fr-CF,sg,ln,kg','TD,SD,CD,SS,CM,CG','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(43,'CG','COG',178,'CF','Congo','Republic of the Congo','Brazzaville',342000,3039126,'AF','.cg','XAF','242','','','fr-CG,kg,ln-CG','CF,GA,CD,CM,AO','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(44,'CH','CHE',756,'SZ','Switzerland','Switzerland','Berne',41290,7581000,'EU','.ch','CHF','41','####','^(d{4})$','de-CH,fr-CH,it-CH,rm','DE,IT,LI,FR,AT','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(45,'CI','CIV',384,'IV','Côte d\'Ivoire','Ivory Coast','Yamoussoukro',322460,21058798,'AF','.ci','XOF','225','','','fr-CI','LR,GH,GN,BF,ML','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(46,'CK','COK',184,'CW','Cook Islands','Cook Islands','Avarua',240,21388,'OC','.ck','NZD','682','','','en-CK,mi','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(47,'CL','CHL',152,'CI','Chile','Chile','Santiago',756950,16746491,'SA','.cl','CLP','56','#######','^(d{7})$','es-CL','PE,BO,AR','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(48,'CM','CMR',120,'CM','Cameroun','Cameroon','Yaounde',475440,19294149,'AF','.cm','XAF','237','','','fr-CM,en-CM','TD,CF,GA,GQ,CG,NG','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(49,'CN','CHN',156,'CH','Zhōngguó','China','Beijing',9596960,1330044000,'AS','.cn','CNY','86','######','^(d{6})$','zh-CN,yue,wuu,dta,ug,za','LA,BT,TJ,KZ,MN,AF,NP,MM,KG,PK,KP,RU,VN,IN','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(50,'CO','COL',170,'CO','Colombia','Colombia','Bogota',1138910,47790000,'SA','.co','COP','57','','','es-CO','EC,PE,PA,BR,VE','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(51,'CR','CRI',188,'CS','Costa Rica','Costa Rica','San Jose',51100,4516220,'NA','.cr','CRC','506','####','^(d{4})$','es-CR,en','PA,NI','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(52,'CS','SCG',891,'YI','Serbia and Montenegro','Serbia and Montenegro','Belgrade',102350,10829175,'EU','.cs','RSD','381','#####','^(d{5})$','cu,hu,sq,sr','AL,HU,MK,RO,HR,BA,BG','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(53,'CU','CUB',192,'CU','Cuba','Cuba','Havana',110860,11423000,'NA','.cu','CUP','53','CP #####','^(?:CP)*(d{5})$','es-CU','US','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(54,'CV','CPV',132,'CV','Cabo Verde','Cape Verde','Praia',4033,508659,'AF','.cv','CVE','238','####','^(d{4})$','pt-CV','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(55,'CW','CUW',531,'UC','Curacao','Curacao',' Willemstad',444,141766,'NA','.cw','ANG','599','','','nl,pap','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(56,'CX','CXR',162,'KT','Christmas Island','Christmas Island','Flying Fish Cove',135,1500,'AS','.cx','AUD','61','####','^(d{4})$','en,zh,ms-CC','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(57,'CY','CYP',196,'CY','Kýpros (Kıbrıs)','Cyprus','Nicosia',9250,1102677,'EU','.cy','EUR','357','####','^(d{4})$','el-CY,tr-CY,en','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(58,'CZ','CZE',203,'EZ','Česko','Czech Republic','Prague',78866,10476000,'EU','.cz','CZK','420','### ##','^(d{5})$','cs,sk','PL,DE,SK,AT','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(59,'DE','DEU',276,'GM','Deutschland','Germany','Berlin',357021,81802257,'EU','.de','EUR','49','#####','^(d{5})$','de','CH,PL,NL,DK,BE,CZ,LU,FR,AT','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(60,'DJ','DJI',262,'DJ','Djibouti','Djibouti','Djibouti',23000,740528,'AF','.dj','DJF','253','','','fr-DJ,ar,so-DJ,aa','ER,ET,SO','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(61,'DK','DNK',208,'DA','Danmark','Denmark','Copenhagen',43094,5484000,'EU','.dk','DKK','45','####','^(d{4})$','da-DK,en,fo,de-DK','DE','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(62,'DM','DMA',212,'DO','Dominica','Dominica','Roseau',754,72813,'NA','.dm','XCD','+1-767','','','en-DM','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(63,'DO','DOM',214,'DR','República Dominicana','Dominican Republic','Santo Domingo',48730,9823821,'NA','.do','DOP','+809/829/849','#####','^(d{5})$','es-DO','HT','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(64,'DZ','DZA',12,'AG','Algérie','Algeria','Algiers',2381740,34586184,'AF','.dz','DZD','213','#####','^(d{5})$','ar-DZ,fr','NE,EH,LY,MR,TN,MA,ML','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(65,'EC','ECU',218,'EC','Ecuador','Ecuador','Quito',283560,14790608,'SA','.ec','USD','593','@####@','^([a-zA-Z]d{4}[a-zA-Z])$','es-EC','PE,CO','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(66,'EE','EST',233,'EN','Eesti','Estonia','Tallinn',45226,1291170,'EU','.ee','EUR','372','#####','^(d{5})$','et,ru','RU,LV','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(67,'EG','EGY',818,'EG','Egypt','Egypt','Cairo',1001450,80471869,'AF','.eg','EGP','20','#####','^(d{5})$','ar-EG,en,fr','LY,SD,IL,PS','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(68,'EH','ESH',732,'WI','aṣ-Ṣaḥrāwīyâ al-ʿArabīyâ','Western Sahara','El-Aaiun',266000,273008,'AF','.eh','MAD','212','','','ar,mey','DZ,MR,MA','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(69,'ER','ERI',232,'ER','Ertrā','Eritrea','Asmara',121320,5792984,'AF','.er','ERN','291','','','aa-ER,ar,tig,kun,ti-ER','ET,SD,DJ','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(70,'ES','ESP',724,'SP','España','Spain','Madrid',504782,46505963,'EU','.es','EUR','34','#####','^(d{5})$','es-ES,ca,gl,eu,oc','AD,PT,GI,FR,MA','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(71,'ET','ETH',231,'ET','Ityoṗya','Ethiopia','Addis Ababa',1127127,88013491,'AF','.et','ETB','251','####','^(d{4})$','am,en-ET,om-ET,ti-ET,so-ET,sid','ER,KE,SD,SS,SO,DJ','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(72,'FI','FIN',246,'FI','Suomi (Finland)','Finland','Helsinki',337030,5244000,'EU','.fi','EUR','358','#####','^(?:FI)*(d{5})$','fi-FI,sv-FI,smn','NO,RU,SE','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(73,'FJ','FJI',242,'FJ','Viti','Fiji','Suva',18270,875983,'OC','.fj','FJD','679','','','en-FJ,fj','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(74,'FK','FLK',238,'FK','Falkland Islands','Falkland Islands','Stanley',12173,2638,'SA','.fk','FKP','500','','','en-FK','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(75,'FM','FSM',583,'FM','Micronesia','Micronesia','Palikir',702,107708,'OC','.fm','USD','691','#####','^(d{5})$','en-FM,chk,pon,yap,kos,uli,woe,nkr,kpg','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(76,'FO','FRO',234,'FO','Føroyar','Faroe Islands','Torshavn',1399,48228,'EU','.fo','DKK','298','FO-###','^(?:FO)*(d{3})$','fo,da-FO','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(77,'FR','FRA',250,'FR','France','France','Paris',547030,64768389,'EU','.fr','EUR','33','#####','^(d{5})$','fr-FR,frp,br,co,ca,eu,oc','CH,DE,BE,LU,IT,AD,MC,ES','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(78,'GA','GAB',266,'GB','Gabon','Gabon','Libreville',267667,1545255,'AF','.ga','XAF','241','','','fr-GA','CM,GQ,CG','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(79,'GD','GRD',308,'GJ','Grenada','Grenada','St. George\'s',344,107818,'NA','.gd','XCD','+1-473','','','en-GD','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(80,'GE','GEO',268,'GG','Sak\'art\'velo','Georgia','Tbilisi',69700,4630000,'AS','.ge','GEL','995','####','^(d{4})$','ka,ru,hy,az','AM,AZ,TR,RU','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(81,'GF','GUF',254,'FG','Guyane','French Guiana','Cayenne',91000,195506,'SA','.gf','EUR','594','#####','^((97|98)3d{2})$','fr-GF','SR,BR','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(82,'GG','GGY',831,'GK','Guernsey','Guernsey','St Peter Port',78,65228,'EU','.gg','GBP','+44-1481','@# #@@|@## #@@|@@# #@@|@@## #@@|@#@ #@@|@@#@ #@@|G','^(([A-Z]d{2}[A-Z]{2})|([A-Z]d{3}[A-Z]{2})|([A-Z]{2}d{2}[A-Z]{2})|([A-Z]{2}d{3}[A-Z]{2})|([A-Z]d[A-Z]d[A-Z]{2})|([A-Z]{2}d[A-Z]d[A-Z]{2})|(GIR0AA))$','en,fr','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(83,'GH','GHA',288,'GH','Ghana','Ghana','Accra',239460,24339838,'AF','.gh','GHS','233','','','en-GH,ak,ee,tw','CI,TG,BF','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(84,'GI','GIB',292,'GI','Gibraltar','Gibraltar','Gibraltar',7,27884,'EU','.gi','GIP','350','','','en-GI,es,it,pt','ES','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(85,'GL','GRL',304,'GL','Grønland','Greenland','Nuuk',2166086,56375,'NA','.gl','DKK','299','####','^(d{4})$','kl,da-GL,en','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(86,'GM','GMB',270,'GA','Gambia','Gambia','Banjul',11300,1593256,'AF','.gm','GMD','220','','','en-GM,mnk,wof,wo,ff','SN','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(87,'GN','GIN',324,'GV','Guinée','Guinea','Conakry',245857,10324025,'AF','.gn','GNF','224','','','fr-GN','LR,SN,SL,CI,GW,ML','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(88,'GP','GLP',312,'GP','Guadeloupe','Guadeloupe','Basse-Terre',1780,443000,'NA','.gp','EUR','590','#####','^((97|98)d{3})$','fr-GP','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(89,'GQ','GNQ',226,'EK','Guinée Equatoriale','Equatorial Guinea','Malabo',28051,1014999,'AF','.gq','XAF','240','','','es-GQ,fr','GA,CM','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(90,'GR','GRC',300,'GR','Elláda','Greece','Athens',131940,11000000,'EU','.gr','EUR','30','### ##','^(d{5})$','el-GR,en,fr','AL,MK,TR,BG','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(91,'GS','SGS',239,'SX','South Georgia and the South Sandwich Islands','South Georgia and the South Sandwich Islands','Grytviken',3903,30,'AN','.gs','GBP','','','','en','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(92,'GT','GTM',320,'GT','Guatemala','Guatemala','Guatemala City',108890,13550440,'NA','.gt','GTQ','502','#####','^(d{5})$','es-GT','MX,HN,BZ,SV','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(93,'GU','GUM',316,'GQ','Guam','Guam','Hagatna',549,159358,'OC','.gu','USD','+1-671','969##','^(969d{2})$','en-GU,ch-GU','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(94,'GW','GNB',624,'PU','Guiné-Bissau','Guinea-Bissau','Bissau',36120,1565126,'AF','.gw','XOF','245','####','^(d{4})$','pt-GW,pov','SN,GN','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(95,'GY','GUY',328,'GY','Guyana','Guyana','Georgetown',214970,748486,'SA','.gy','GYD','592','','','en-GY','SR,BR,VE','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(96,'HK','HKG',344,'HK','Hèunggóng','Hong Kong','Hong Kong',1092,6898686,'AS','.hk','HKD','852','','','zh-HK,yue,zh,en','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(97,'HM','HMD',334,'HM','Heard Island and McDonald Islands','Heard Island and McDonald Islands','',412,0,'AN','.hm','AUD',' ','','','','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(98,'HN','HND',340,'HO','Honduras','Honduras','Tegucigalpa',112090,7989415,'NA','.hn','HNL','504','@@####','^([A-Z]{2}d{4})$','es-HN','GT,NI,SV','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(99,'HR','HRV',191,'HR','Hrvatska','Croatia','Zagreb',56542,4491000,'EU','.hr','HRK','385','#####','^(?:HR)*(d{5})$','hr-HR,sr','HU,SI,BA,ME,RS','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(100,'HT','HTI',332,'HA','Haïti','Haiti','Port-au-Prince',27750,9648924,'NA','.ht','HTG','509','HT####','^(?:HT)*(d{4})$','ht,fr-HT','DO','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(101,'HU','HUN',348,'HU','Magyarország','Hungary','Budapest',93030,9982000,'EU','.hu','HUF','36','####','^(d{4})$','hu-HU','SK,SI,RO,UA,HR,AT,RS','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(102,'ID','IDN',360,'ID','Indonesia','Indonesia','Jakarta',1919440,242968342,'AS','.id','IDR','62','#####','^(d{5})$','id,en,nl,jv','PG,TL,MY','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(103,'IE','IRL',372,'EI','Ireland','Ireland','Dublin',70280,4622917,'EU','.ie','EUR','353','','','en-IE,ga-IE','GB','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(104,'IL','ISR',376,'IS','Yiśrā\'ēl','Israel','Jerusalem',20770,7353985,'AS','.il','ILS','972','#####','^(d{5})$','he,ar-IL,en-IL,','SY,JO,LB,EG,PS','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(105,'IM','IMN',833,'IM','Isle of Man','Isle of Man','Douglas, Isle of Man',572,75049,'EU','.im','GBP','+44-1624','@# #@@|@## #@@|@@# #@@|@@## #@@|@#@ #@@|@@#@ #@@|G','^(([A-Z]d{2}[A-Z]{2})|([A-Z]d{3}[A-Z]{2})|([A-Z]{2}d{2}[A-Z]{2})|([A-Z]{2}d{3}[A-Z]{2})|([A-Z]d[A-Z]d[A-Z]{2})|([A-Z]{2}d[A-Z]d[A-Z]{2})|(GIR0AA))$','en,gv','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(106,'IN','IND',356,'IN','Bhārat','India','New Delhi',3287590,1173108018,'AS','.in','INR','91','######','^(d{6})$','en-IN,hi,bn,te,mr,ta,ur,gu,kn,ml,or,pa,as,bh,sat,k','CN,NP,MM,BT,PK,BD','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(107,'IO','IOT',86,'IO','British Indian Ocean Territory','British Indian Ocean Territory','Diego Garcia',60,4000,'AS','.io','USD','246','','','en-IO','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(108,'IQ','IRQ',368,'IZ','al-ʿIrāq','Iraq','Baghdad',437072,29671605,'AS','.iq','IQD','964','#####','^(d{5})$','ar-IQ,ku,hy','SY,SA,IR,JO,TR,KW','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(109,'IR','IRN',364,'IR','Īrān','Iran','Tehran',1648000,76923300,'AS','.ir','IRR','98','##########','^(d{10})$','fa-IR,ku','TM,AF,IQ,AM,PK,AZ,TR','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(110,'IS','ISL',352,'IC','Ísland','Iceland','Reykjavik',103000,308910,'EU','.is','ISK','354','###','^(d{3})$','is,en,de,da,sv,no','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(111,'IT','ITA',380,'IT','Italia','Italy','Rome',301230,60340328,'EU','.it','EUR','39','#####','^(d{5})$','it-IT,en,de-IT,fr-IT,sc,ca,co,sl','CH,VA,SI,SM,FR,AT','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(112,'JE','JEY',832,'JE','Jersey','Jersey','Saint Helier',116,90812,'EU','.je','GBP','+44-1534','@# #@@|@## #@@|@@# #@@|@@## #@@|@#@ #@@|@@#@ #@@|G','^(([A-Z]d{2}[A-Z]{2})|([A-Z]d{3}[A-Z]{2})|([A-Z]{2}d{2}[A-Z]{2})|([A-Z]{2}d{3}[A-Z]{2})|([A-Z]d[A-Z]d[A-Z]{2})|([A-Z]{2}d[A-Z]d[A-Z]{2})|(GIR0AA))$','en,pt','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(113,'JM','JAM',388,'JM','Jamaica','Jamaica','Kingston',10991,2847232,'NA','.jm','JMD','+1-876','','','en-JM','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(114,'JO','JOR',400,'JO','al-Urdun','Jordan','Amman',92300,6407085,'AS','.jo','JOD','962','#####','^(d{5})$','ar-JO,en','SY,SA,IQ,IL,PS','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(115,'JP','JPN',392,'JA','Nihon','Japan','Tokyo',377835,127288000,'AS','.jp','JPY','81','###-####','^(d{7})$','ja','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(116,'KE','KEN',404,'KE','Kenya','Kenya','Nairobi',582650,40046566,'AF','.ke','KES','254','#####','^(d{5})$','en-KE,sw-KE','ET,TZ,SS,SO,UG','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(117,'KG','KGZ',417,'KG','Kyrgyzstan','Kyrgyzstan','Bishkek',198500,5508626,'AS','.kg','KGS','996','######','^(d{6})$','ky,uz,ru','CN,TJ,UZ,KZ','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(118,'KH','KHM',116,'CB','Kambucā','Cambodia','Phnom Penh',181040,14453680,'AS','.kh','KHR','855','#####','^(d{5})$','km,fr,en','LA,TH,VN','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(119,'KI','KIR',296,'KR','Kiribati','Kiribati','Tarawa',811,92533,'OC','.ki','AUD','686','','','en-KI,gil','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(120,'KM','COM',174,'CN','Comores','Comoros','Moroni',2170,773407,'AF','.km','KMF','269','','','ar,fr-KM','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(121,'KN','KNA',659,'SC','Saint Kitts and Nevis','Saint Kitts and Nevis','Basseterre',261,51134,'NA','.kn','XCD','+1-869','','','en-KN','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(122,'KP','PRK',408,'KN','Joseon','North Korea','Pyongyang',120540,22912177,'AS','.kp','KPW','850','###-###','^(d{6})$','ko-KP','CN,KR,RU','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(123,'KR','KOR',410,'KS','Hanguk','South Korea','Seoul',98480,48422644,'AS','.kr','KRW','82','SEOUL ###-###','^(?:SEOUL)*(d{6})$','ko-KR,en','KP','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(124,'KW','KWT',414,'KU','al-Kuwayt','Kuwait','Kuwait City',17820,2789132,'AS','.kw','KWD','965','#####','^(d{5})$','ar-KW,en','SA,IQ','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(125,'KY','CYM',136,'CJ','Cayman Islands','Cayman Islands','George Town',262,44270,'NA','.ky','KYD','+1-345','','','en-KY','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(126,'KZ','KAZ',398,'KZ','Ķazaķstan','Kazakhstan','Astana',2717300,15340000,'AS','.kz','KZT','7','######','^(d{6})$','kk,ru','TM,CN,KG,UZ,RU','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(127,'LA','LAO',418,'LA','Lāw','Laos','Vientiane',236800,6368162,'AS','.la','LAK','856','#####','^(d{5})$','lo,fr,en','CN,MM,KH,TH,VN','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(128,'LB','LBN',422,'LE','Lubnān','Lebanon','Beirut',10400,4125247,'AS','.lb','LBP','961','#### ####|####','^(d{4}(d{4})?)$','ar-LB,fr-LB,en,hy','SY,IL','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(129,'LC','LCA',662,'ST','Saint Lucia','Saint Lucia','Castries',616,160922,'NA','.lc','XCD','+1-758','','','en-LC','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(130,'LI','LIE',438,'LS','Liechtenstein','Liechtenstein','Vaduz',160,35000,'EU','.li','CHF','423','####','^(d{4})$','de-LI','CH,AT','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(131,'LK','LKA',144,'CE','Šrī Laṁkā','Sri Lanka','Colombo',65610,21513990,'AS','.lk','LKR','94','#####','^(d{5})$','si,ta,en','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(132,'LR','LBR',430,'LI','Liberia','Liberia','Monrovia',111370,3685076,'AF','.lr','LRD','231','####','^(d{4})$','en-LR','SL,CI,GN','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(133,'LS','LSO',426,'LT','Lesotho','Lesotho','Maseru',30355,1919552,'AF','.ls','LSL','266','###','^(d{3})$','en-LS,st,zu,xh','ZA','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(134,'LT','LTU',440,'LH','Lietuva','Lithuania','Vilnius',65200,2944459,'EU','.lt','EUR','370','LT-#####','^(?:LT)*(d{5})$','lt,ru,pl','PL,BY,RU,LV','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(135,'LU','LUX',442,'LU','Lëtzebuerg','Luxembourg','Luxembourg',2586,497538,'EU','.lu','EUR','352','L-####','^(d{4})$','lb,de-LU,fr-LU','DE,BE,FR','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(136,'LV','LVA',428,'LG','Latvija','Latvia','Riga',64589,2217969,'EU','.lv','EUR','371','LV-####','^(?:LV)*(d{4})$','lv,ru,lt','LT,EE,BY,RU','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(137,'LY','LBY',434,'LY','Lībiyā','Libya','Tripolis',1759540,6461454,'AF','.ly','LYD','218','','','ar-LY,it,en','TD,NE,DZ,SD,TN,EG','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(138,'MA','MAR',504,'MO','Maroc','Morocco','Rabat',446550,31627428,'AF','.ma','MAD','212','#####','^(d{5})$','ar-MA,fr','DZ,EH,ES','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(139,'MC','MCO',492,'MN','Monaco','Monaco','Monaco',2,32965,'EU','.mc','EUR','377','#####','^(d{5})$','fr-MC,en,it','FR','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(140,'MD','MDA',498,'MD','Moldova','Moldova','Chisinau',33843,4324000,'EU','.md','MDL','373','MD-####','^(?:MD)*(d{4})$','ro,ru,gag,tr','RO,UA','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(141,'ME','MNE',499,'MJ','Crna Gora','Montenegro','Podgorica',14026,666730,'EU','.me','EUR','382','#####','^(d{5})$','sr,hu,bs,sq,hr,rom','AL,HR,BA,RS,XK','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(142,'MF','MAF',663,'RN','Saint Martin','Saint Martin','Marigot',53,35925,'NA','.gp','EUR','590','### ###','','fr','SX','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(143,'MG','MDG',450,'MA','Madagascar','Madagascar','Antananarivo',587040,21281844,'AF','.mg','MGA','261','###','^(d{3})$','fr-MG,mg','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(144,'MH','MHL',584,'RM','Marshall Islands','Marshall Islands','Majuro',181,65859,'OC','.mh','USD','692','','','mh,en-MH','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(145,'MK','MKD',807,'MK','Makedonija','Macedonia','Skopje',25333,2062294,'EU','.mk','MKD','389','####','^(d{4})$','mk,sq,tr,rmm,sr','AL,GR,BG,RS,XK','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(146,'ML','MLI',466,'ML','Mali','Mali','Bamako',1240000,13796354,'AF','.ml','XOF','223','','','fr-ML,bm','SN,NE,DZ,CI,GN,MR,BF','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(147,'MM','MMR',104,'BM','Mẏanmā','Myanmar','Nay Pyi Taw',678500,53414374,'AS','.mm','MMK','95','#####','^(d{5})$','my','CN,LA,TH,BD,IN','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(148,'MN','MNG',496,'MG','Mongol Uls','Mongolia','Ulan Bator',1565000,3086918,'AS','.mn','MNT','976','######','^(d{6})$','mn,ru','CN,RU','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(149,'MO','MAC',446,'MC','Ngoumún','Macao','Macao',254,449198,'AS','.mo','MOP','853','','','zh,zh-MO,pt','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(150,'MP','MNP',580,'CQ','Northern Mariana Islands','Northern Mariana Islands','Saipan',477,53883,'OC','.mp','USD','+1-670','','','fil,tl,zh,ch-MP,en-MP','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(151,'MQ','MTQ',474,'MB','Martinique','Martinique','Fort-de-France',1100,432900,'NA','.mq','EUR','596','#####','^(d{5})$','fr-MQ','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(152,'MR','MRT',478,'MR','Mauritanie','Mauritania','Nouakchott',1030700,3205060,'AF','.mr','MRO','222','','','ar-MR,fuc,snk,fr,mey,wo','SN,DZ,EH,ML','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(153,'MS','MSR',500,'MH','Montserrat','Montserrat','Plymouth',102,9341,'NA','.ms','XCD','+1-664','','','en-MS','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(154,'MT','MLT',470,'MT','Malta','Malta','Valletta',316,403000,'EU','.mt','EUR','356','@@@ ###|@@@ ##','^([A-Z]{3}d{2}d?)$','mt,en-MT','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(155,'MU','MUS',480,'MP','Mauritius','Mauritius','Port Louis',2040,1294104,'AF','.mu','MUR','230','','','en-MU,bho,fr','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(156,'MV','MDV',462,'MV','Dhivehi','Maldives','Male',300,395650,'AS','.mv','MVR','960','#####','^(d{5})$','dv,en','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(157,'MW','MWI',454,'MI','Malawi','Malawi','Lilongwe',118480,15447500,'AF','.mw','MWK','265','','','ny,yao,tum,swk','TZ,MZ,ZM','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(158,'MX','MEX',484,'MX','México','Mexico','Mexico City',1972550,112468855,'NA','.mx','MXN','52','#####','^(d{5})$','es-MX','GT,US,BZ','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(159,'MY','MYS',458,'MY','Malaysia','Malaysia','Kuala Lumpur',329750,28274729,'AS','.my','MYR','60','#####','^(d{5})$','ms-MY,en,zh,ta,te,ml,pa,th','BN,TH,ID','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(160,'MZ','MOZ',508,'MZ','Moçambique','Mozambique','Maputo',801590,22061451,'AF','.mz','MZN','258','####','^(d{4})$','pt-MZ,vmw','ZW,TZ,SZ,ZA,ZM,MW','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(161,'NA','NAM',516,'WA','Namibia','Namibia','Windhoek',825418,2128471,'AF','.na','NAD','264','','','en-NA,af,de,hz,naq','ZA,BW,ZM,AO','',NULL,'0',0,1,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(162,'NC','NCL',540,'NC','Nouvelle Calédonie','New Caledonia','Noumea',19060,216494,'OC','.nc','XPF','687','#####','^(d{5})$','fr-NC','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(163,'NE','NER',562,'NG','Niger','Niger','Niamey',1267000,15878271,'AF','.ne','XOF','227','####','^(d{4})$','fr-NE,ha,kr,dje','TD,BJ,DZ,LY,BF,NG,ML','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(164,'NF','NFK',574,'NF','Norfolk Island','Norfolk Island','Kingston',35,1828,'OC','.nf','AUD','672','####','^(d{4})$','en-NF','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(165,'NG','NGA',566,'NI','Nigeria','Nigeria','Abuja',923768,154000000,'AF','.ng','NGN','234','######','^(d{6})$','en-NG,ha,yo,ig,ff','TD,NE,BJ,CM','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(166,'NI','NIC',558,'NU','Nicaragua','Nicaragua','Managua',129494,5995928,'NA','.ni','NIO','505','###-###-#','^(d{7})$','es-NI,en','CR,HN','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(167,'NL','NLD',528,'NL','Nederland','Netherlands','Amsterdam',41526,16645000,'EU','.nl','EUR','31','#### @@','^(d{4}[A-Z]{2})$','nl-NL,fy-NL','DE,BE','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(168,'NO','NOR',578,'NO','Norge (Noreg)','Norway','Oslo',324220,5009150,'EU','.no','NOK','47','####','^(d{4})$','no,nb,nn,se,fi','FI,RU,SE','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(169,'NP','NPL',524,'NP','Nēpāl','Nepal','Kathmandu',140800,28951852,'AS','.np','NPR','977','#####','^(d{5})$','ne,en','CN,IN','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(170,'NR','NRU',520,'NR','Naoero','Nauru','Yaren',21,10065,'OC','.nr','AUD','674','','','na,en-NR','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(171,'NU','NIU',570,'NE','Niue','Niue','Alofi',260,2166,'OC','.nu','NZD','683','','','niu,en-NU','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(172,'NZ','NZL',554,'NZ','New Zealand','New Zealand','Wellington',268680,4252277,'OC','.nz','NZD','64','####','^(d{4})$','en-NZ,mi','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(173,'OM','OMN',512,'MU','ʿUmān','Oman','Muscat',212460,2967717,'AS','.om','OMR','968','###','^(d{3})$','ar-OM,en,bal,ur','SA,YE,AE','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(174,'PA','PAN',591,'PM','Panamá','Panama','Panama City',78200,3410676,'NA','.pa','PAB','507','','','es-PA,en','CR,CO','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(175,'PE','PER',604,'PE','Perú','Peru','Lima',1285220,29907003,'SA','.pe','PEN','51','','','es-PE,qu,ay','EC,CL,BO,BR,CO','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(176,'PF','PYF',258,'FP','Polinésie Française','French Polynesia','Papeete',4167,270485,'OC','.pf','XPF','689','#####','^((97|98)7d{2})$','fr-PF,ty','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(177,'PG','PNG',598,'PP','Papua New Guinea','Papua New Guinea','Port Moresby',462840,6064515,'OC','.pg','PGK','675','###','^(d{3})$','en-PG,ho,meu,tpi','ID','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(178,'PH','PHL',608,'RP','Pilipinas','Philippines','Manila',300000,99900177,'AS','.ph','PHP','63','####','^(d{4})$','tl,en-PH,fil','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(179,'PK','PAK',586,'PK','Pākistān','Pakistan','Islamabad',803940,184404791,'AS','.pk','PKR','92','#####','^(d{5})$','ur-PK,en-PK,pa,sd,ps,brh','CN,AF,IR,IN','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(180,'PL','POL',616,'PL','Polska','Poland','Warsaw',312685,38500000,'EU','.pl','PLN','48','##-###','^(d{5})$','pl','DE,LT,SK,CZ,BY,UA,RU','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(181,'PM','SPM',666,'SB','Saint Pierre and Miquelon','Saint Pierre and Miquelon','Saint-Pierre',242,7012,'NA','.pm','EUR','508','#####','^(97500)$','fr-PM','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(182,'PN','PCN',612,'PC','Pitcairn','Pitcairn','Adamstown',47,46,'OC','.pn','NZD','870','','','en-PN','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(183,'PR','PRI',630,'RQ','Puerto Rico','Puerto Rico','San Juan',9104,3916632,'NA','.pr','USD','+1-787/1-939','#####-####','^(d{9})$','en-PR,es-PR','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(184,'PS','PSE',275,'WE','Filasṭīn','Palestinian Territory','East Jerusalem',5970,3800000,'AS','.ps','ILS','970','','','ar-PS','JO,IL,EG','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(185,'PT','PRT',620,'PO','Portugal','Portugal','Lisbon',92391,10676000,'EU','.pt','EUR','351','####-###','^(d{7})$','pt-PT,mwl','ES','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(186,'PW','PLW',585,'PS','Palau','Palau','Melekeok',458,19907,'OC','.pw','USD','680','96940','^(96940)$','pau,sov,en-PW,tox,ja,fil,zh','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(187,'PY','PRY',600,'PA','Paraguay','Paraguay','Asuncion',406750,6375830,'SA','.py','PYG','595','####','^(d{4})$','es-PY,gn','BO,BR,AR','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(188,'QA','QAT',634,'QA','Qaṭar','Qatar','Doha',11437,840926,'AS','.qa','QAR','974','','','ar-QA,en','SA','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(189,'RE','REU',638,'RE','Réunion','Reunion','Saint-Denis',2517,776948,'AF','.re','EUR','262','#####','^((97|98)(4|7|8)d{2})$','fr-RE','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(190,'RO','ROU',642,'RO','România','Romania','Bucharest',237500,21959278,'EU','.ro','RON','40','######','^(d{6})$','ro,hu,rom','MD,HU,UA,BG,RS','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(191,'RS','SRB',688,'RI','Srbija','Serbia','Belgrade',88361,7344847,'EU','.rs','RSD','381','######','^(d{6})$','sr,hu,bs,rom','AL,HU,MK,RO,HR,BA,BG,ME,XK','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(192,'RU','RUS',643,'RS','Rossija','Russia','Moscow',17100000,140702000,'EU','.ru','RUB','7','######','^(d{6})$','ru,tt,xal,cau,ady,kv,ce,tyv,cv,udm,tut,mns,bua,myv','GE,CN,BY,UA,KZ,LV,PL,EE,LT,FI,MN,NO,AZ,KP','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(193,'RW','RWA',646,'RW','Rwanda','Rwanda','Kigali',26338,11055976,'AF','.rw','RWF','250','','','rw,en-RW,fr-RW,sw','TZ,CD,BI,UG','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(194,'SA','SAU',682,'SA','as-Saʿūdīyâ','Saudi Arabia','Riyadh',1960582,25731776,'AS','.sa','SAR','966','#####','^(d{5})$','ar-SA','QA,OM,IQ,YE,JO,AE,KW','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(195,'SB','SLB',90,'BP','Solomon Islands','Solomon Islands','Honiara',28450,559198,'OC','.sb','SBD','677','','','en-SB,tpi','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(196,'SC','SYC',690,'SE','Seychelles','Seychelles','Victoria',455,88340,'AF','.sc','SCR','248','','','en-SC,fr-SC','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(197,'SD','SDN',729,'SU','Sudan','Sudan','Khartoum',1861484,35000000,'AF','.sd','SDG','249','#####','^(d{5})$','ar-SD,en,fia','SS,TD,EG,ET,ER,LY,CF','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(198,'SE','SWE',752,'SW','Sverige','Sweden','Stockholm',449964,9555893,'EU','.se','SEK','46','### ##','^(?:SE)*(d{5})$','sv-SE,se,sma,fi-SE','NO,FI','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(199,'SG','SGP',702,'SN','xīnjiāpō','Singapore','Singapur',693,4701069,'AS','.sg','SGD','65','######','^(d{6})$','cmn,en-SG,ms-SG,ta-SG,zh-SG','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(200,'SH','SHN',654,'SH','Saint Helena','Saint Helena','Jamestown',410,7460,'AF','.sh','SHP','290','STHL 1ZZ','^(STHL1ZZ)$','en-SH','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(201,'SI','SVN',705,'SI','Slovenija','Slovenia','Ljubljana',20273,2007000,'EU','.si','EUR','386','####','^(?:SI)*(d{4})$','sl,sh','HU,IT,HR,AT','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(202,'SJ','SJM',744,'SV','Svalbard and Jan Mayen','Svalbard and Jan Mayen','Longyearbyen',62049,2550,'EU','.sj','NOK','47','','','no,ru','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(203,'SK','SVK',703,'LO','Slovensko','Slovakia','Bratislava',48845,5455000,'EU','.sk','EUR','421','### ##','^(d{5})$','sk,hu','PL,HU,CZ,UA,AT','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(204,'SL','SLE',694,'SL','Sierra Leone','Sierra Leone','Freetown',71740,5245695,'AF','.sl','SLL','232','','','en-SL,men,tem','LR,GN','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(205,'SM','SMR',674,'SM','San Marino','San Marino','San Marino',61,31477,'EU','.sm','EUR','378','4789#','^(4789d)$','it-SM','IT','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(206,'SN','SEN',686,'SG','Sénégal','Senegal','Dakar',196190,12323252,'AF','.sn','XOF','221','#####','^(d{5})$','fr-SN,wo,fuc,mnk','GN,MR,GW,GM,ML','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(207,'SO','SOM',706,'SO','Soomaaliya','Somalia','Mogadishu',637657,10112453,'AF','.so','SOS','252','@@  #####','^([A-Z]{2}d{5})$','so-SO,ar-SO,it,en-SO','ET,KE,DJ','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(208,'SR','SUR',740,'NS','Suriname','Suriname','Paramaribo',163270,492829,'SA','.sr','SRD','597','','','nl-SR,en,srn,hns,jv','GY,BR,GF','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(209,'SS','SSD',728,'OD','South Sudan','South Sudan','Juba',644329,8260490,'AF','','SSP','211','','','en','CD,CF,ET,KE,SD,UG,','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(210,'ST','STP',678,'TP','São Tomé e Príncipe','Sao Tome and Principe','Sao Tome',1001,175808,'AF','.st','STD','239','','','pt-ST','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(211,'SV','SLV',222,'ES','El Salvador','El Salvador','San Salvador',21040,6052064,'NA','.sv','USD','503','CP ####','^(?:CP)*(d{4})$','es-SV','GT,HN','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(212,'SX','SXM',534,'NN','Sint Maarten','Sint Maarten','Philipsburg',21,37429,'NA','.sx','ANG','599','','','nl,en','MF','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(213,'SY','SYR',760,'SY','Sūrīyâ','Syria','Damascus',185180,22198110,'AS','.sy','SYP','963','','','ar-SY,ku,hy,arc,fr,en','IQ,JO,IL,TR,LB','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(214,'SZ','SWZ',748,'WZ','Swaziland','Swaziland','Mbabane',17363,1354051,'AF','.sz','SZL','268','@###','^([A-Z]d{3})$','en-SZ,ss-SZ','ZA,MZ','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(215,'TC','TCA',796,'TK','Turks and Caicos Islands','Turks and Caicos Islands','Cockburn Town',430,20556,'NA','.tc','USD','+1-649','TKCA 1ZZ','^(TKCA 1ZZ)$','en-TC','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(216,'TD','TCD',148,'CD','Tchad','Chad','N\'Djamena',1284000,10543464,'AF','.td','XAF','235','','','fr-TD,ar-TD,sre','NE,LY,CF,SD,CM,NG','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(217,'TF','ATF',260,'FS','French Southern Territories','French Southern Territories','Port-aux-Francais',7829,140,'AN','.tf','EUR','','','','fr','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(218,'TG','TGO',768,'TO','Togo','Togo','Lome',56785,6587239,'AF','.tg','XOF','228','','','fr-TG,ee,hna,kbp,dag,ha','BJ,GH,BF','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(219,'TH','THA',764,'TH','Prathēt tai','Thailand','Bangkok',514000,67089500,'AS','.th','THB','66','#####','^(d{5})$','th,en','LA,MM,KH,MY','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(220,'TJ','TJK',762,'TI','Tojikiston','Tajikistan','Dushanbe',143100,7487489,'AS','.tj','TJS','992','######','^(d{6})$','tg,ru','CN,AF,KG,UZ','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(221,'TK','TKL',772,'TL','Tokelau','Tokelau','',10,1466,'OC','.tk','NZD','690','','','tkl,en-TK','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(222,'TL','TLS',626,'TT','Timór Lorosa\'e','East Timor','Dili',15007,1154625,'OC','.tl','USD','670','','','tet,pt-TL,id,en','ID','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(223,'TM','TKM',795,'TX','Turkmenistan','Turkmenistan','Ashgabat',488100,4940916,'AS','.tm','TMT','993','######','^(d{6})$','tk,ru,uz','AF,IR,UZ,KZ','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(224,'TN','TUN',788,'TS','Tunisie','Tunisia','Tunis',163610,10589025,'AF','.tn','TND','216','####','^(d{4})$','ar-TN,fr','DZ,LY','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(225,'TO','TON',776,'TN','Tonga','Tonga','Nuku\'alofa',748,122580,'OC','.to','TOP','676','','','to,en-TO','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(226,'TR','TUR',792,'TU','Türkiye','Turkey','Ankara',780580,77804122,'AS','.tr','TRY','90','#####','^(d{5})$','tr-TR,ku,diq,az,av','SY,GE,IQ,IR,GR,AM,AZ,BG','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(227,'TT','TTO',780,'TD','Trinidad and Tobago','Trinidad and Tobago','Port of Spain',5128,1228691,'NA','.tt','TTD','+1-868','','','en-TT,hns,fr,es,zh','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(228,'TV','TUV',798,'TV','Tuvalu','Tuvalu','Funafuti',26,10472,'OC','.tv','AUD','688','','','tvl,en,sm,gil','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(229,'TW','TWN',158,'TW','T\'ai2-wan1','Taiwan','Taipei',35980,22894384,'AS','.tw','TWD','886','#####','^(d{5})$','zh-TW,zh,nan,hak','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(230,'TZ','TZA',834,'TZ','Tanzania','Tanzania','Dodoma',945087,41892895,'AF','.tz','TZS','255','','','sw-TZ,en,ar','MZ,KE,CD,RW,ZM,BI,UG,MW','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(231,'UA','UKR',804,'UP','Ukrajina','Ukraine','Kiev',603700,45415596,'EU','.ua','UAH','380','#####','^(d{5})$','uk,ru-UA,rom,pl,hu','PL,MD,HU,SK,BY,RO,RU','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(232,'UG','UGA',800,'UG','Uganda','Uganda','Kampala',236040,33398682,'AF','.ug','UGX','256','','','en-UG,lg,sw,ar','TZ,KE,SS,CD,RW','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(233,'UK','GBR',826,'UK','United Kingdom','United Kingdom','London',244820,62348447,'EU','.uk','GBP','44','@# #@@|@## #@@|@@# #@@|@@## #@@|@#@ #@@|@@#@ #@@|G','^(([A-Z]d{2}[A-Z]{2})|([A-Z]d{3}[A-Z]{2})|([A-Z]{2}d{2}[A-Z]{2})|([A-Z]{2}d{3}[A-Z]{2})|([A-Z]d[A-Z]d[A-Z]{2})|([A-Z]{2}d[A-Z]d[A-Z]{2})|(GIR0AA))$','en-GB,cy-GB,gd','IE','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(234,'UM','UMI',581,'','United States Minor Outlying Islands','United States Minor Outlying Islands','',0,0,'OC','.um','USD','1','','','en-UM','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(235,'US','USA',840,'US','USA','United States','Washington',9629091,310232863,'NA','.us','USD','1','#####-####','^d{5}(-d{4})?$','en-US,es-US,haw,fr','CA,MX,CU','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(236,'UY','URY',858,'UY','Uruguay','Uruguay','Montevideo',176220,3477000,'SA','.uy','UYU','598','#####','^(d{5})$','es-UY','BR,AR','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(237,'UZ','UZB',860,'UZ','O\'zbekiston','Uzbekistan','Tashkent',447400,27865738,'AS','.uz','UZS','998','######','^(d{6})$','uz,ru,tg','TM,AF,KG,TJ,KZ','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(238,'VA','VAT',336,'VT','Vaticanum','Vatican','Vatican City',0,921,'EU','.va','EUR','379','#####','^(d{5})$','la,it,fr','IT','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(239,'VC','VCT',670,'VC','Saint Vincent and the Grenadines','Saint Vincent and the Grenadines','Kingstown',389,104217,'NA','.vc','XCD','+1-784','','','en-VC,fr','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(240,'VE','VEN',862,'VE','Venezuela','Venezuela','Caracas',912050,27223228,'SA','.ve','VEF','58','####','^(d{4})$','es-VE','GY,BR,CO','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(241,'VG','VGB',92,'VI','British Virgin Islands','British Virgin Islands','Road Town',153,21730,'NA','.vg','USD','+1-284','','','en-VG','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(242,'VI','VIR',850,'VQ','U.S. Virgin Islands','U.S. Virgin Islands','Charlotte Amalie',352,108708,'NA','.vi','USD','+1-340','#####-####','^d{5}(-d{4})?$','en-VI','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(243,'VN','VNM',704,'VM','Việt Nam','Vietnam','Hanoi',329560,89571130,'AS','.vn','VND','84','######','^(d{6})$','vi,en,fr,zh,km','CN,LA,KH','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(244,'VU','VUT',548,'NH','Vanuatu','Vanuatu','Port Vila',12200,221552,'OC','.vu','VUV','678','','','bi,en-VU,fr-VU','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(245,'WF','WLF',876,'WF','Wallis and Futuna','Wallis and Futuna','Mata Utu',274,16025,'OC','.wf','XPF','681','#####','^(986d{2})$','wls,fud,fr-WF','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(246,'WS','WSM',882,'WS','Samoa','Samoa','Apia',2944,192001,'OC','.ws','WST','685','','','sm,en-WS','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(247,'XK','XKX',0,'KV','Kosovo','Kosovo','Pristina',10908,1800000,'EU','','EUR','','','','sq,sr','RS,AL,MK,ME','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(248,'YE','YEM',887,'YM','al-Yaman','Yemen','Sanaa',527970,23495361,'AS','.ye','YER','967','','','ar-YE','SA,OM','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(249,'YT','MYT',175,'MF','Mayotte','Mayotte','Mamoudzou',374,159042,'AF','.yt','EUR','262','#####','^(d{5})$','fr-YT','','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(250,'ZA','ZAF',710,'SF','South Africa','South Africa','Pretoria',1219912,49000000,'AF','.za','ZAR','27','####','^(d{4})$','zu,xh,af,nso,en-ZA,tn,st,ts,ss,ve,nr','ZW,SZ,MZ,BW,NA,LS','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(251,'ZM','ZMB',894,'ZA','Zambia','Zambia','Lusaka',752614,13460305,'AF','.zm','ZMW','260','#####','^(d{5})$','en-ZM,bem,loz,lun,lue,ny,toi','ZW,TZ,MZ,CD,NA,MW,AO','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29'),(252,'ZW','ZWE',716,'ZI','Zimbabwe','Zimbabwe','Harare',390580,11651858,'AF','.zw','ZWL','263','','','en-ZW,sn,nr,nd','ZA,MZ,BW,ZM','',NULL,'0',0,0,'2020-12-02 04:58:29','2020-12-02 04:58:29');
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currencies`
--

DROP TABLE IF EXISTS `currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currencies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(3) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `html_entity` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `font_arial` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `font_code2000` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unicode_decimal` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unicode_hex` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `in_left` tinyint(1) unsigned DEFAULT '0',
  `decimal_places` int(10) unsigned DEFAULT '0' COMMENT 'Currency Decimal Places - ISO 4217',
  `decimal_separator` varchar(10) COLLATE utf8_unicode_ci DEFAULT '.',
  `thousand_separator` varchar(10) COLLATE utf8_unicode_ci DEFAULT ',',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `currencies_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=171 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currencies`
--

LOCK TABLES `currencies` WRITE;
/*!40000 ALTER TABLE `currencies` DISABLE KEYS */;
INSERT INTO `currencies` VALUES (1,'AED','United Arab Emirates Dirham','&#1583;.&#1573;','د.إ','د.إ',NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(2,'AFN','Afghanistan Afghani','&#65;&#102;','؋','؋','1547','60b',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(3,'ALL','Albania Lek','&#76;&#101;&#107;','Lek','Lek','76, 1','4c, 6',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(4,'AMD','Armenia Dram','',NULL,NULL,NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(5,'ANG','Netherlands Antilles Guilder','&#402;','ƒ','ƒ','402','192',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(6,'AOA','Angola Kwanza','&#75;&#122;','Kz','Kz',NULL,NULL,1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(7,'ARS','Argentina Peso','&#36;','$','$','36','24',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(8,'AUD','Australia Dollar','&#36;','$','$','36','24',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(9,'AWG','Aruba Guilder','&#402;','ƒ','ƒ','402','192',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(10,'AZN','Azerbaijan New Manat','&#1084;&#1072;&#1085;','ман','ман','1084,','43c, ',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(11,'BAM','Bosnia and Herzegovina Convertible Marka','&#75;&#77;','KM','KM','75, 7','4b, 4',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(12,'BBD','Barbados Dollar','&#36;','$','$','36','24',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(13,'BDT','Bangladesh Taka','&#2547;','৳','৳',NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(14,'BGN','Bulgaria Lev','&#1083;&#1074;','лв','лв','1083,','43b, ',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(15,'BHD','Bahrain Dinar','.&#1583;.&#1576;',NULL,NULL,NULL,NULL,0,3,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(16,'BIF','Burundi Franc','&#70;&#66;&#117;','FBu','FBu',NULL,NULL,0,0,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(17,'BMD','Bermuda Dollar','&#36;','$','$','36','24',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(18,'BND','Brunei Darussalam Dollar','&#36;','$','$','36','24',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(19,'BOB','Bolivia Boliviano','&#36;&#98;','$b','$b','36, 9','24, 6',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(20,'BRL','Brazil Real','&#82;&#36;','R$','R$','82, 3','52, 2',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(21,'BSD','Bahamas Dollar','&#36;','$','$','36','24',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(22,'BTN','Bhutan Ngultrum','&#78;&#117;&#46;',NULL,NULL,NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(23,'BWP','Botswana Pula','&#80;','P','P','80','50',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(24,'BYR','Belarus Ruble','&#112;&#46;','p.','p.','112, ','70, 2',0,0,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(25,'BZD','Belize Dollar','&#66;&#90;&#36;','BZ$','BZ$','66, 9','42, 5',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(26,'CAD','Canada Dollar','&#36;','$','$','36','24',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(27,'CDF','Congo/Kinshasa Franc','&#70;&#67;','Fr','Fr',NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(28,'CHF','Switzerland Franc','&#67;&#72;&#70;','Fr','Fr','67, 7','43, 4',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(29,'CLP','Chile Peso','&#36;','$','$','36','24',0,0,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(30,'CNY','China Yuan Renminbi','&#165;','¥','¥','165','a5',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(31,'COP','Colombia Peso','&#36;','$','$','36','24',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(32,'CRC','Costa Rica Colon','&#8353;','₡','₡','8353','20a1',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(33,'CUC','Cuba Convertible Peso',NULL,NULL,NULL,NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(34,'CUP','Cuba Peso','&#8396;','₱','₱','8369','20b1',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(35,'CVE','Cape Verde Escudo','&#x24;','$','$',NULL,NULL,1,0,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(36,'CZK','Czech Republic Koruna','&#75;&#269;','Kč','Kč','75, 2','4b, 1',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(37,'DJF','Djibouti Franc','&#70;&#100;&#106;','Fr','Fr',NULL,NULL,0,0,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(38,'DKK','Denmark Krone','&#107;&#114;','kr','kr','107, ','6b, 7',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(39,'DOP','Dominican Republic Peso','&#82;&#68;&#36;','RD$','RD$','82, 6','52, 4',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(40,'DZD','Algeria Dinar','&#1583;&#1580;','DA','DA',NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(41,'EEK','Estonia Kroon',NULL,'kr','kr','107, ','6b, 7',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(42,'EGP','Egypt Pound','&#163;','£','£','163','a3',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(43,'ERN','Eritrea Nakfa','&#x4E;&#x66;&#x6B;','Nfk','Nfk',NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(44,'ETB','Ethiopia Birr','&#66;&#114;','Br','Br',NULL,NULL,1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(45,'EUR','Euro Member Countries','€','€','€','8364','20ac',0,2,',',' ','2020-12-02 04:58:26','2020-12-02 04:58:26'),(46,'FJD','Fiji Dollar','&#36;','$','$','36','24',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(47,'FKP','Falkland Islands (Malvinas) Pound','&#163;','£','£','163','a3',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(48,'GBP','United Kingdom Pound','&#163;','£','£','163','a3',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(49,'GEL','Georgia Lari','&#4314;',NULL,NULL,NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(50,'GGP','Guernsey Pound',NULL,'£','£','163','a3',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(51,'GHC','Ghana Cedi','&#x47;&#x48;&#xA2;','GH¢','GH¢','162','a2',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(52,'GHS','Ghana Cedi','&#x47;&#x48;&#xA2;','GH¢','GH¢',NULL,NULL,1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(53,'GIP','Gibraltar Pound','&#163;','£','£','163','a3',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(54,'GMD','Gambia Dalasi','&#68;','D','D',NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(55,'GNF','Guinea Franc','&#70;&#71;','Fr','Fr',NULL,NULL,0,0,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(56,'GTQ','Guatemala Quetzal','&#81;','Q','Q','81','51',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(57,'GYD','Guyana Dollar','&#36;','$','$','36','24',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(58,'HKD','Hong Kong Dollar','&#36;','$','$','36','24',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(59,'HNL','Honduras Lempira','&#76;','L','L','76','4c',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(60,'HRK','Croatia Kuna','&#107;&#110;','kn','kn','107, ','6b, 6',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(61,'HTG','Haiti Gourde','&#71;',NULL,NULL,NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(62,'HUF','Hungary Forint','&#70;&#116;','Ft','Ft','70, 1','46, 7',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(63,'IDR','Indonesia Rupiah','&#82;&#112;','Rp','Rp','82, 1','52, 7',0,0,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(64,'ILS','Israel Shekel','&#8362;','₪','₪','8362','20aa',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(65,'IMP','Isle of Man Pound',NULL,'£','£','163','a3',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(66,'INR','India Rupee','&#8377;','₨','₨','','',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(67,'IQD','Iraq Dinar','&#1593;.&#1583;','د.ع;','د.ع;',NULL,NULL,0,0,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(68,'IRR','Iran Rial','&#65020;','﷼','﷼','65020','fdfc',0,0,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(69,'ISK','Iceland Krona','&#107;&#114;','kr','kr','107, ','6b, 7',0,0,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(70,'JEP','Jersey Pound','&#163;','£','£','163','a3',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(71,'JMD','Jamaica Dollar','&#74;&#36;','J$','J$','74, 3','4a, 2',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(72,'JOD','Jordan Dinar','&#74;&#68;',NULL,NULL,NULL,NULL,0,3,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(73,'JPY','Japan Yen','&#165;','¥','¥','165','a5',0,0,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(74,'KES','Kenya Shilling','&#x4B;&#x53;&#x68;','KSh','KSh',NULL,NULL,1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(75,'KGS','Kyrgyzstan Som','&#1083;&#1074;','лв','лв','1083,','43b, ',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(76,'KHR','Cambodia Riel','&#6107;','៛','៛','6107','17db',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(77,'KMF','Comoros Franc','&#67;&#70;','Fr','Fr',NULL,NULL,0,0,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(78,'KPW','Korea (North) Won','&#8361;','₩','₩','8361','20a9',0,0,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(79,'KRW','Korea (South) Won','&#8361;','₩','₩','8361','20a9',0,0,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(80,'KWD','Kuwait Dinar','&#1583;.&#1603;','د.ك','د.ك',NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(81,'KYD','Cayman Islands Dollar','&#36;','$','$','36','24',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(82,'KZT','Kazakhstan Tenge','&#1083;&#1074;','лв','лв','1083,','43b, ',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(83,'LAK','Laos Kip','&#8365;','₭','₭','8365','20ad',0,0,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(84,'LBP','Lebanon Pound','&#163;','£','£','163','a3',0,0,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(85,'LKR','Sri Lanka Rupee','&#8360;','₨','₨','8360','20a8',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(86,'LRD','Liberia Dollar','&#36;','$','$','36','24',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(87,'LSL','Lesotho Loti','&#76;','M','M',NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(88,'LTL','Lithuania Litas','&#76;&#116;','Lt','Lt','76, 1','4c, 7',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(89,'LVL','Latvia Lat','&#76;&#115;','Ls','Ls','76, 1','4c, 7',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(90,'LYD','Libya Dinar','&#1604;.&#1583;','DL','DL',NULL,NULL,0,3,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(91,'MAD','Morocco Dirham','&#1583;.&#1605;.','Dhs','Dhs',NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(92,'MDL','Moldova Leu','&#76;',NULL,NULL,NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(93,'MGA','Madagascar Ariary','&#65;&#114;','Ar','Ar',NULL,NULL,0,5,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(94,'MKD','Macedonia Denar','&#1076;&#1077;&#1085;','ден','ден','1076,','434, ',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(95,'MMK','Myanmar (Burma) Kyat','&#75;',NULL,NULL,NULL,NULL,0,0,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(96,'MNT','Mongolia Tughrik','&#8366;','₮','₮','8366','20ae',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(97,'MOP','Macau Pataca','&#77;&#79;&#80;&#36;',NULL,NULL,NULL,NULL,0,1,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(98,'MRO','Mauritania Ouguiya','&#85;&#77;','UM','UM',NULL,NULL,0,5,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(99,'MUR','Mauritius Rupee','&#8360;','₨','₨','8360','20a8',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(100,'MVR','Maldives (Maldive Islands) Rufiyaa','.&#1923;',NULL,NULL,NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(101,'MWK','Malawi Kwacha','&#77;&#75;','MK','MK',NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(102,'MXN','Mexico Peso','&#36;','$','$','36','24',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(103,'MYR','Malaysia Ringgit','&#82;&#77;','RM','RM','82, 7','52, 4',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(104,'MZN','Mozambique Metical','&#77;&#84;','MT','MT','77, 8','4d, 5',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(105,'NAD','Namibia Dollar','&#36;','N$','N$','36','24',1,2,'.',',','2020-12-02 04:58:26','2020-12-08 07:46:45'),(106,'NGN','Nigeria Naira','&#8358;','₦','₦','8358','20a6',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(107,'NIO','Nicaragua Cordoba','&#67;&#36;','C$','C$','67, 3','43, 2',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(108,'NOK','Norway Krone','&#107;&#114;','kr','kr','107, ','6b, 7',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(109,'NPR','Nepal Rupee','&#8360;','₨','₨','8360','20a8',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(110,'NZD','New Zealand Dollar','&#36;','$','$','36','24',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(111,'OMR','Oman Rial','&#65020;','﷼','﷼','65020','fdfc',0,3,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(112,'PAB','Panama Balboa','&#66;&#47;&#46;','B/.','B/.','66, 4','42, 2',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(113,'PEN','Peru Nuevo Sol','&#83;&#47;&#46;','S/.','S/.','83, 4','53, 2',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(114,'PGK','Papua New Guinea Kina','&#75;',NULL,NULL,NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(115,'PHP','Philippines Peso','&#8369;','₱','₱','8369','20b1',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(116,'PKR','Pakistan Rupee','&#8360;','₨','₨','8360','20a8',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(117,'PLN','Poland Zloty','&#122;&#322;','zł','zł','122, ','7a, 1',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(118,'PYG','Paraguay Guarani','&#71;&#115;','Gs','Gs','71, 1','47, 7',0,0,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(119,'QAR','Qatar Riyal','&#65020;','﷼','﷼','65020','fdfc',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(120,'RON','Romania New Leu','&#108;&#101;&#105;','lei','lei','108, ','6c, 6',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(121,'RSD','Serbia Dinar','&#1044;&#1080;&#1085;&#46;','Дин.','Дин.','1044,','414, ',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(122,'RUB','Russia Ruble','&#8381;','₽','₽','8381,','20BD',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(123,'RWF','Rwanda Franc','&#1585;.&#1587;','FRw','FRw',NULL,NULL,0,0,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(124,'SAR','Saudi Arabia Riyal','&#65020;','﷼','﷼','65020','fdfc',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(125,'SBD','Solomon Islands Dollar','&#36;','$','$','36','24',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(126,'SCR','Seychelles Rupee','&#8360;','₨','₨','8360','20a8',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(127,'SDG','Sudan Pound','&#163;','DS','DS',NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(128,'SEK','Sweden Krona','&#107;&#114;','kr','kr','107, ','6b, 7',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(129,'SGD','Singapore Dollar','&#36;','$','$','36','24',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(130,'SHP','Saint Helena Pound','&#163;','£','£','163','a3',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(131,'SLL','Sierra Leone Leone','&#76;&#101;','Le','Le',NULL,NULL,1,0,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(132,'SOS','Somalia Shilling','&#83;','S','S','83','53',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(133,'SPL','Seborga Luigino',NULL,NULL,NULL,NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(134,'SRD','Suriname Dollar','&#36;','$','$','36','24',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(135,'SSP','South Sudanese Pound','&#xA3;','£','£',NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(136,'STD','São Tomé and Príncipe Dobra','&#68;&#98;','Db','Db',NULL,NULL,0,0,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(137,'SVC','El Salvador Colon','&#36;','$','$','36','24',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(138,'SYP','Syria Pound','&#163;','£','£','163','a3',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(139,'SZL','Swaziland Lilangeni','&#76;','E','E',NULL,NULL,1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(140,'THB','Thailand Baht','&#3647;','฿','฿','3647','e3f',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(141,'TJS','Tajikistan Somoni','&#84;&#74;&#83;',NULL,NULL,NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(142,'TMT','Turkmenistan Manat','&#109;',NULL,NULL,NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(143,'TND','Tunisia Dinar','&#1583;.&#1578;','DT','DT',NULL,NULL,1,3,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(144,'TOP','Tonga Pa\'anga','&#84;&#36;',NULL,NULL,NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(145,'TRL','Turkey Lira',NULL,'₤','₤','8356','20a4',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(146,'TRY','Turkey Lira','&#x20BA;','₺','₺','','',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(147,'TTD','Trinidad and Tobago Dollar','&#36;','TT$','TT$','84, 8','54, 5',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(148,'TVD','Tuvalu Dollar',NULL,'$','$','36','24',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(149,'TWD','Taiwan New Dollar','&#78;&#84;&#36;','NT$','NT$','78, 8','4e, 5',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(150,'TZS','Tanzania Shilling','&#x54;&#x53;&#x68;','TSh','TSh',NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(151,'UAH','Ukraine Hryvnia','&#8372;','₴','₴','8372','20b4',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(152,'UGX','Uganda Shilling','&#85;&#83;&#104;','USh','USh',NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(153,'USD','United States Dollar','&#36;','$','$','36','24',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(154,'UYU','Uruguay Peso','&#36;&#85;','$U','$U','36, 8','24, 5',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(155,'UZS','Uzbekistan Som','&#1083;&#1074;','лв','лв','1083,','43b, ',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(156,'VEF','Venezuela Bolivar','&#66;&#115;','Bs','Bs','66, 1','42, 7',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(157,'VND','Viet Nam Dong','&#8363;','₫','₫','8363','20ab',1,0,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(158,'VUV','Vanuatu Vatu','&#86;&#84;',NULL,NULL,NULL,NULL,0,0,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(159,'WST','Samoa Tala','&#87;&#83;&#36;',NULL,NULL,NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(160,'XAF','Communauté Financière Africaine (BEAC) CFA Franc B','&#70;&#67;&#70;&#65;','F','F',NULL,NULL,0,0,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(161,'XCD','East Caribbean Dollar','&#36;','$','$','36','24',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(162,'XDR','International Monetary Fund (IMF) Special Drawing ','',NULL,NULL,NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(163,'XOF','Communauté Financière Africaine (BCEAO) Franc','&#70;&#67;&#70;&#65;','F','F',NULL,NULL,0,0,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(164,'XPF','Comptoirs Français du Pacifique (CFP) Franc','&#70;','F','F',NULL,NULL,0,0,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(165,'YER','Yemen Rial','&#65020;','﷼','﷼','65020','fdfc',0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(166,'ZAR','South Africa Rand','&#82;','R','R','82','52',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(167,'ZMW','Zambia Kwacha',NULL,'ZK','ZK',NULL,NULL,0,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(168,'ZWD','Zimbabwe Dollar',NULL,'Z$','Z$','90, 3','5a, 2',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(169,'ZWL','Zimbabwe Dollar',NULL,'Z$','Z$','90, 3','5a, 2',1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26'),(170,'XBT','Bitcoin','฿','฿','฿',NULL,NULL,1,2,'.',',','2020-12-02 04:58:26','2020-12-02 04:58:26');
/*!40000 ALTER TABLE `currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `belongs_to` enum('posts','users') COLLATE utf8_unicode_ci NOT NULL,
  `translation_lang` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `translation_of` int(10) unsigned DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `max` int(10) unsigned DEFAULT '255',
  `default` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `required` tinyint(1) unsigned DEFAULT NULL,
  `use_as_filter` tinyint(1) DEFAULT '0',
  `help` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fields_translation_lang_index` (`translation_lang`),
  KEY `fields_translation_of_index` (`translation_of`),
  KEY `fields_belongs_to_index` (`belongs_to`)
) ENGINE=InnoDB AUTO_INCREMENT=188 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
INSERT INTO `fields` VALUES (5,'posts','en',5,'Fuel Type','select',NULL,NULL,0,1,NULL,1),(6,'posts','en',6,'Features','checkbox_multiple',NULL,NULL,0,1,NULL,1),(7,'posts','en',7,'Transmission','radio',NULL,NULL,0,1,NULL,1),(8,'posts','en',8,'Condition','select',NULL,NULL,0,1,NULL,1),(9,'posts','en',9,'Size','number',50,NULL,1,1,NULL,1),(10,'posts','en',10,'Rooms','select',NULL,NULL,1,1,NULL,1),(11,'posts','en',11,'Building Type','select',NULL,NULL,0,1,NULL,1),(12,'posts','en',12,'Parking','checkbox',NULL,NULL,0,1,NULL,1),(13,'posts','en',13,'Furnished','radio',NULL,NULL,0,1,NULL,1),(14,'posts','en',14,'Mobile Brand','select',NULL,NULL,0,1,NULL,1),(15,'posts','en',15,'Mobile Model','text',NULL,NULL,0,0,NULL,1),(16,'posts','en',16,'Electronic Brand','select',NULL,NULL,0,1,NULL,1),(18,'posts','en',18,'Start Date','date',50,NULL,0,1,NULL,1),(19,'posts','en',19,'Company','text',100,NULL,1,0,NULL,1),(20,'posts','en',20,'Work Type','select',NULL,NULL,1,1,NULL,1),(22,'posts','en',22,'End date','date',50,NULL,1,1,NULL,1),(23,'posts','en',23,'Event Address','text',200,NULL,1,0,NULL,1),(24,'posts','en',24,'Website','url',100,NULL,0,0,NULL,1),(25,'posts','en',25,'Video','video',100,NULL,0,0,NULL,1),(59,'posts','en',59,'Engine Capacity','text',NULL,NULL,0,0,NULL,1),(72,'posts','en',72,'Engine Brand','checkbox_multiple',0,NULL,0,0,NULL,1),(83,'posts','en',83,'Features','checkbox_multiple',NULL,NULL,0,0,NULL,1),(84,'posts','en',84,'Part/Accessory Name','text',NULL,NULL,0,0,NULL,1),(86,'posts','en',86,'Condition','select',NULL,NULL,0,0,NULL,1),(88,'posts','en',88,'Transmission','checkbox_multiple',NULL,NULL,0,0,NULL,1),(90,'posts','en',90,'Car Type','checkbox_multiple',NULL,NULL,0,0,NULL,1),(103,'posts','en',103,'Sedan','checkbox_multiple',NULL,NULL,0,0,NULL,1),(105,'posts','en',105,'Pickup - Single Cab 2 x 4','checkbox_multiple',NULL,NULL,0,0,NULL,1),(109,'posts','en',109,'Pick Up - Double Cab - 4 x 4','checkbox_multiple',NULL,NULL,0,0,NULL,1),(112,'posts','en',112,'SUV - 2 x 4','checkbox_multiple',NULL,NULL,0,0,NULL,1),(113,'posts','en',113,'SUV - 4 x 4','checkbox_multiple',NULL,NULL,0,0,NULL,1),(115,'posts','en',115,'Pick Up - Single Cab -  4 x 4','text',NULL,NULL,0,0,NULL,1),(116,'posts','en',116,'Pick Up Double Cab - 2 x 4','checkbox_multiple',NULL,NULL,0,0,NULL,1),(122,'posts','en',122,'2 x 4','text',NULL,NULL,0,0,NULL,1),(123,'posts','en',123,'4 x 4','text',NULL,NULL,0,0,NULL,1),(128,'posts','en',128,'Seat Capacity','select',NULL,NULL,0,0,NULL,1),(129,'posts','en',129,'2 Wheeler','text',NULL,NULL,0,0,NULL,1),(130,'posts','en',130,'3 Wheeler','text',NULL,NULL,0,0,NULL,1),(131,'posts','en',131,'Quad - 4 Wheeler','text',NULL,NULL,0,0,NULL,1),(132,'posts','en',132,'Loader','text',NULL,NULL,0,0,NULL,1),(133,'posts','en',133,'Excavator','text',NULL,NULL,0,0,NULL,1),(134,'posts','en',134,'Dozer','text',NULL,NULL,0,0,NULL,1),(135,'posts','en',135,'Hauler','text',NULL,NULL,0,0,NULL,1),(136,'posts','en',136,'Compactor','text',NULL,NULL,0,0,NULL,1),(137,'posts','en',137,'Grader','text',NULL,NULL,0,0,NULL,1),(138,'posts','en',138,'Drilling Equipment','text',NULL,NULL,0,0,NULL,1),(139,'posts','en',139,'Tipper','text',NULL,NULL,0,0,NULL,1),(140,'posts','en',140,'Mechanical Horse','text',NULL,NULL,0,0,NULL,1),(141,'posts','en',141,'Water Truck','text',NULL,NULL,0,0,NULL,1),(142,'posts','en',142,'Low Bed','text',NULL,NULL,0,0,NULL,1),(143,'posts','en',143,'Super Link','text',NULL,NULL,0,0,NULL,1),(144,'posts','en',144,'Side Tipper','text',NULL,NULL,0,0,NULL,1),(145,'posts','en',145,'Container Skeleton','text',NULL,NULL,0,0,NULL,1),(146,'posts','en',146,'Cat','text',NULL,NULL,0,0,NULL,1),(147,'posts','en',147,'Komatsu','text',NULL,NULL,0,0,NULL,1),(148,'posts','en',148,'Bell','text',NULL,NULL,0,0,NULL,1),(149,'posts','en',149,'Volvo','text',NULL,NULL,0,0,NULL,1),(150,'posts','en',150,'Hitachi','text',NULL,NULL,0,0,NULL,1),(151,'posts','en',151,'Hyundai','text',NULL,NULL,0,0,NULL,1),(152,'posts','en',152,'6 x 4','text',NULL,NULL,0,0,NULL,1),(153,'posts','en',153,'6 x 6','text',NULL,NULL,0,0,NULL,1),(154,'posts','en',154,'8 x 4','text',NULL,NULL,0,0,NULL,1),(155,'posts','en',155,'8 x 8','text',NULL,NULL,0,0,NULL,1),(157,'posts','en',157,'All Wheel Drive','text',NULL,NULL,0,0,NULL,1),(158,'posts','en',158,'Brand','select',NULL,NULL,1,1,NULL,1),(159,'posts','en',159,'Brand Name','select',NULL,NULL,0,0,NULL,1),(160,'posts','en',160,'Brand','select',NULL,NULL,0,0,NULL,1),(161,'posts','en',161,'Car Brand','select',NULL,NULL,0,0,NULL,1),(162,'posts','en',162,'Brand Name','select',NULL,NULL,0,0,NULL,1),(163,'posts','en',163,'Brand Type','select',NULL,NULL,0,0,NULL,1),(164,'posts','en',164,'Brand Model','select',NULL,NULL,0,0,NULL,1),(166,'posts','en',166,'Engine Make','select',NULL,NULL,0,0,NULL,1),(167,'posts','en',167,'Brand Make','select',NULL,NULL,0,0,NULL,1),(168,'posts','en',168,'Type of Equipment','select',NULL,NULL,0,0,NULL,1),(173,'posts','en',173,'Mileage','text',100,NULL,0,0,NULL,1),(174,'posts','en',174,'Engine Hour Meter Reading','text',100,NULL,0,0,NULL,1),(175,'posts','en',175,'Year Model','text',100,NULL,0,0,NULL,1),(176,'posts','en',176,'Title','select',NULL,NULL,0,0,NULL,1),(178,'posts','en',178,'Colour','select',NULL,NULL,0,0,NULL,1),(179,'posts','en',179,'Series Type','select',NULL,NULL,0,0,NULL,1),(180,'posts','en',180,'Series','select',NULL,NULL,0,0,NULL,1),(181,'posts','en',181,'Traction','select',NULL,NULL,0,0,NULL,1),(182,'posts','en',182,'Manufacturer Series','select',NULL,NULL,0,0,NULL,1),(185,'posts','en',185,'Body Type','select',NULL,NULL,0,0,NULL,1),(186,'posts','en',186,'Engine Configuration','select',NULL,NULL,0,0,NULL,1),(187,'posts','en',187,'Body Manufactured Year','text',100,NULL,0,0,NULL,1);
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields_options`
--

DROP TABLE IF EXISTS `fields_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fields_options` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `field_id` int(10) unsigned DEFAULT NULL,
  `translation_lang` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `translation_of` int(10) unsigned DEFAULT NULL,
  `value` mediumtext COLLATE utf8_unicode_ci,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `depth` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fields_options_field_id_index` (`field_id`),
  KEY `fields_options_translation_lang_index` (`translation_lang`),
  KEY `fields_options_translation_of_index` (`translation_of`)
) ENGINE=InnoDB AUTO_INCREMENT=533 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields_options`
--

LOCK TABLES `fields_options` WRITE;
/*!40000 ALTER TABLE `fields_options` DISABLE KEYS */;
INSERT INTO `fields_options` VALUES (57,5,'en',57,'Petrol',NULL,113,114,NULL),(58,5,'en',58,'Diesel',NULL,115,116,NULL),(59,6,'en',59,'Air Conditioner',NULL,117,118,NULL),(60,6,'en',60,'GPS',NULL,119,120,NULL),(61,6,'en',61,'Security System',NULL,121,122,NULL),(62,6,'en',62,'Spare Tire',NULL,123,124,NULL),(63,7,'en',63,'Automatic',NULL,125,126,NULL),(64,7,'en',64,'Manual',NULL,127,128,NULL),(65,8,'en',65,'New',NULL,129,130,NULL),(66,8,'en',66,'Used',NULL,131,132,NULL),(68,10,'en',68,'1',NULL,135,136,1),(69,10,'en',69,'2',NULL,137,138,1),(70,10,'en',70,'3',NULL,139,140,1),(71,10,'en',71,'4',NULL,141,142,1),(72,10,'en',72,'5',NULL,143,144,1),(73,10,'en',73,'6',NULL,145,146,1),(74,10,'en',74,'7',NULL,147,148,1),(75,10,'en',75,'8',NULL,149,150,1),(76,10,'en',76,'9',NULL,151,152,1),(77,10,'en',77,'10',NULL,153,154,1),(78,10,'en',78,'> 10',NULL,155,156,1),(79,11,'en',79,'Apartment',NULL,157,158,NULL),(80,11,'en',80,'House',NULL,159,160,NULL),(81,11,'en',81,'Office',NULL,161,162,NULL),(82,11,'en',82,'Store',NULL,163,164,NULL),(83,11,'en',83,'Plot of land',NULL,165,166,NULL),(84,13,'en',84,'Yes',NULL,167,168,NULL),(85,13,'en',85,'No',NULL,169,170,NULL),(86,14,'en',86,'Huawei',NULL,171,172,NULL),(87,14,'en',87,'Sony',NULL,173,174,NULL),(88,14,'en',88,'LG',NULL,175,176,NULL),(89,14,'en',89,'Samsung',NULL,177,178,NULL),(90,14,'en',90,'Nokia',NULL,179,180,NULL),(91,14,'en',91,'Alcatel-Lucent',NULL,181,182,NULL),(92,14,'en',92,'Siemens',NULL,183,184,NULL),(93,14,'en',93,'BlackBerry',NULL,185,186,NULL),(94,14,'en',94,'Apple',NULL,187,188,NULL),(95,14,'en',95,'Google',NULL,189,190,NULL),(96,14,'en',96,'Microsoft',NULL,191,192,NULL),(97,14,'en',97,'Motorola',NULL,193,194,NULL),(98,14,'en',98,'Other',NULL,195,196,NULL),(102,16,'en',102,'Xiaomi',NULL,203,204,NULL),(103,16,'en',103,'Canon',NULL,205,206,NULL),(104,16,'en',104,'Casio',NULL,207,208,NULL),(105,16,'en',105,'Epson',NULL,209,210,NULL),(106,16,'en',106,'Fuji',NULL,211,212,NULL),(107,16,'en',107,'Funai',NULL,213,214,NULL),(108,16,'en',108,'JVC',NULL,215,216,NULL),(109,16,'en',109,'Nikon',NULL,217,218,NULL),(110,16,'en',110,'Nintendo',NULL,219,220,NULL),(111,16,'en',111,'Olympus',NULL,221,222,NULL),(112,16,'en',112,'Panasonic',NULL,223,224,NULL),(113,16,'en',113,'Pentax',NULL,225,226,NULL),(114,16,'en',114,'Pioneer',NULL,227,228,NULL),(115,16,'en',115,'Sega',NULL,229,230,NULL),(116,16,'en',116,'Sharp',NULL,231,232,NULL),(117,16,'en',117,'Sony',NULL,233,234,NULL),(118,16,'en',118,'Toshiba',NULL,235,236,NULL),(119,16,'en',119,'Daewoo',NULL,237,238,NULL),(120,16,'en',120,'LG',NULL,239,240,NULL),(121,16,'en',121,'Samsung',NULL,241,242,NULL),(122,16,'en',122,'Acer',NULL,243,244,NULL),(123,16,'en',123,'Asus',NULL,245,246,NULL),(124,16,'en',124,'D-Link',NULL,247,248,NULL),(125,16,'en',125,'Gigabyte',NULL,249,250,NULL),(126,16,'en',126,'Beko',NULL,251,252,NULL),(127,16,'en',127,'Nokia',NULL,253,254,NULL),(128,16,'en',128,'Alcatel-Lucent',NULL,255,256,NULL),(129,16,'en',129,'Bosch',NULL,257,258,NULL),(130,16,'en',130,'Siemens',NULL,259,260,NULL),(131,16,'en',131,'Sennheiser',NULL,261,262,NULL),(132,16,'en',132,'Telefunken',NULL,263,264,NULL),(133,16,'en',133,'Philips',NULL,265,266,NULL),(134,16,'en',134,'Electrolux',NULL,267,268,NULL),(135,16,'en',135,'Russell Hobbs',NULL,269,270,NULL),(136,16,'en',136,'BlackBerry',NULL,271,272,NULL),(137,16,'en',137,'Thomson',NULL,273,274,NULL),(138,16,'en',138,'Amazon',NULL,275,276,NULL),(139,16,'en',139,'Apple',NULL,277,278,NULL),(140,16,'en',140,'Bose',NULL,279,280,NULL),(141,16,'en',141,'Cisco Systems',NULL,281,282,NULL),(142,16,'en',142,'Dell',NULL,283,284,NULL),(143,16,'en',143,'Gateway',NULL,285,286,NULL),(144,16,'en',144,'Google',NULL,287,288,NULL),(145,16,'en',145,'Hewlett-Packard',NULL,289,290,NULL),(146,16,'en',146,'IBM',NULL,291,292,NULL),(147,16,'en',147,'Intel',NULL,293,294,NULL),(148,16,'en',148,'Microsoft',NULL,295,296,NULL),(149,16,'en',149,'Motorola',NULL,297,298,NULL),(150,16,'en',150,'NVIDIA',NULL,299,300,NULL),(151,16,'en',151,'Packard Bell',NULL,301,302,NULL),(152,16,'en',152,'Qualcomm',NULL,303,304,NULL),(153,16,'en',153,'Seagate',NULL,305,306,NULL),(154,16,'en',154,'Sun Microsystems',NULL,307,308,NULL),(155,16,'en',155,'Vizio',NULL,309,310,NULL),(156,16,'en',156,'Western Digital',NULL,311,312,NULL),(157,16,'en',157,'Xerox',NULL,313,314,NULL),(158,16,'en',158,'Other',NULL,315,316,NULL),(159,20,'en',159,'Full-time',NULL,317,318,NULL),(160,20,'en',160,'Part-time',NULL,319,320,NULL),(161,20,'en',161,'Temporary',NULL,321,322,NULL),(162,20,'en',162,'Internship',NULL,323,324,NULL),(163,20,'en',163,'Permanent',NULL,325,326,NULL),(164,5,'en',164,'Hybrid',NULL,NULL,NULL,NULL),(165,7,'en',165,'Semi-Automatic',NULL,NULL,NULL,NULL),(338,158,'en',338,'Scania',NULL,NULL,NULL,NULL),(339,158,'en',339,'Nissan',NULL,NULL,NULL,NULL),(340,158,'en',340,'Volvo',NULL,NULL,NULL,NULL),(341,158,'en',341,'UD',NULL,NULL,NULL,NULL),(342,158,'en',342,'MAN',NULL,NULL,NULL,NULL),(343,128,'en',343,'5',NULL,NULL,NULL,NULL),(344,128,'en',344,'7',NULL,NULL,NULL,NULL),(345,128,'en',345,'10',NULL,NULL,NULL,NULL),(346,128,'en',346,'13',NULL,NULL,NULL,NULL),(347,128,'en',347,'16',NULL,NULL,NULL,NULL),(348,128,'en',348,'18',NULL,NULL,NULL,NULL),(349,128,'en',349,'21',NULL,NULL,NULL,NULL),(350,128,'en',350,'25',NULL,NULL,NULL,NULL),(351,128,'en',351,'30',NULL,NULL,NULL,NULL),(352,128,'en',352,'45',NULL,NULL,NULL,NULL),(353,128,'en',353,'50',NULL,NULL,NULL,NULL),(354,128,'en',354,'55',NULL,NULL,NULL,NULL),(355,128,'en',355,'60',NULL,NULL,NULL,NULL),(356,128,'en',356,'65',NULL,NULL,NULL,NULL),(358,159,'en',358,'Scania',NULL,NULL,NULL,NULL),(359,159,'en',359,'Volvo',NULL,NULL,NULL,NULL),(360,159,'en',360,'UD',NULL,NULL,NULL,NULL),(361,159,'en',361,'MAN',NULL,NULL,NULL,NULL),(362,159,'en',362,'Nissan',NULL,NULL,NULL,NULL),(363,159,'en',363,'Toyota',NULL,NULL,NULL,NULL),(364,159,'en',364,'Mercedes-Benz',NULL,NULL,NULL,NULL),(365,159,'en',365,'Hino',NULL,NULL,NULL,NULL),(366,159,'en',366,'Volkswagen',NULL,NULL,NULL,NULL),(367,159,'en',367,'Iveco',NULL,NULL,NULL,NULL),(368,161,'en',368,'Alfa Romeo',NULL,NULL,NULL,NULL),(369,161,'en',369,'Aston Martin',NULL,NULL,NULL,NULL),(370,161,'en',370,'Audi',NULL,NULL,NULL,NULL),(371,161,'en',371,'Bentley',NULL,NULL,NULL,NULL),(373,161,'en',373,'BMW',NULL,NULL,NULL,NULL),(374,161,'en',374,'Cadillac',NULL,NULL,NULL,NULL),(375,161,'en',375,'Chevrolet',NULL,NULL,NULL,NULL),(376,161,'en',376,'Chevrolet',NULL,NULL,NULL,NULL),(377,161,'en',377,'Chrysler',NULL,NULL,NULL,NULL),(378,161,'en',378,'Citroen',NULL,NULL,NULL,NULL),(379,161,'en',379,'Dodge',NULL,NULL,NULL,NULL),(380,161,'en',380,'Ferrari',NULL,NULL,NULL,NULL),(381,161,'en',381,'Fiat',NULL,NULL,NULL,NULL),(382,161,'en',382,'Ford',NULL,NULL,NULL,NULL),(383,161,'en',383,'GMC',NULL,NULL,NULL,NULL),(384,161,'en',384,'GWM',NULL,NULL,NULL,NULL),(385,161,'en',385,'Honda',NULL,NULL,NULL,NULL),(386,161,'en',386,'Hyundai',NULL,NULL,NULL,NULL),(387,161,'en',387,'Infiniti',NULL,NULL,NULL,NULL),(388,161,'en',388,'Isuzu',NULL,NULL,NULL,NULL),(389,161,'en',389,'Jaguar',NULL,NULL,NULL,NULL),(390,161,'en',390,'Jeep',NULL,NULL,NULL,NULL),(391,161,'en',391,'Kia',NULL,NULL,NULL,NULL),(392,161,'en',392,'Lamborghini',NULL,NULL,NULL,NULL),(393,161,'en',393,'Lancia',NULL,NULL,NULL,NULL),(394,161,'en',394,'Land Rover',NULL,NULL,NULL,NULL),(395,161,'en',395,'Lexus',NULL,NULL,NULL,NULL),(396,161,'en',396,'Maserati',NULL,NULL,NULL,NULL),(397,161,'en',397,'Mazda',NULL,NULL,NULL,NULL),(398,161,'en',398,'Mercedes-Benz',NULL,NULL,NULL,NULL),(399,161,'en',399,'Mini',NULL,NULL,NULL,NULL),(400,161,'en',400,'Mitsubishi',NULL,NULL,NULL,NULL),(401,161,'en',401,'Nissan',NULL,NULL,NULL,NULL),(402,161,'en',402,'Opel',NULL,NULL,NULL,NULL),(403,161,'en',403,'Peugeot',NULL,NULL,NULL,NULL),(404,161,'en',404,'Porsche',NULL,NULL,NULL,NULL),(405,161,'en',405,'Renault',NULL,NULL,NULL,NULL),(406,161,'en',406,'SSangYong',NULL,NULL,NULL,NULL),(407,161,'en',407,'Subaru',NULL,NULL,NULL,NULL),(408,161,'en',408,'Suzuki',NULL,NULL,NULL,NULL),(409,161,'en',409,'Tesla',NULL,NULL,NULL,NULL),(410,161,'en',410,'Toyota',NULL,NULL,NULL,NULL),(411,161,'en',411,'Volkswagen',NULL,NULL,NULL,NULL),(412,161,'en',412,'Volvo',NULL,NULL,NULL,NULL),(413,160,'en',413,'Caterpillar',NULL,NULL,NULL,NULL),(414,160,'en',414,'Komatsu',NULL,NULL,NULL,NULL),(415,160,'en',415,'Hitachi',NULL,NULL,NULL,NULL),(416,160,'en',416,'Volvo',NULL,NULL,NULL,NULL),(417,160,'en',417,'Liebherr',NULL,NULL,NULL,NULL),(418,160,'en',418,'XCMG',NULL,NULL,NULL,NULL),(419,160,'en',419,'Sany',NULL,NULL,NULL,NULL),(420,160,'en',420,'JCB',NULL,NULL,NULL,NULL),(421,163,'en',421,'Honda',NULL,NULL,NULL,NULL),(422,163,'en',422,'BMW',NULL,NULL,NULL,NULL),(423,163,'en',423,'Yamaha',NULL,NULL,NULL,NULL),(425,164,'en',425,'Erf',NULL,NULL,NULL,NULL),(426,164,'en',426,'Scania',NULL,NULL,NULL,NULL),(427,164,'en',427,'Volvo',NULL,NULL,NULL,NULL),(428,164,'en',428,'Volkswagen',NULL,NULL,NULL,NULL),(429,164,'en',429,'Mercedes-Benz',NULL,NULL,NULL,NULL),(430,164,'en',430,'MAN',NULL,NULL,NULL,NULL),(431,164,'en',431,'UD',NULL,NULL,NULL,NULL),(432,164,'en',432,'Hino',NULL,NULL,NULL,NULL),(433,164,'en',433,'Afritrail',NULL,NULL,NULL,NULL),(434,164,'en',434,'Hendred Freuyen',NULL,NULL,NULL,NULL),(435,164,'en',435,'Swift',NULL,NULL,NULL,NULL),(436,164,'en',436,'Serco',NULL,NULL,NULL,NULL),(437,164,'en',437,'Bezers',NULL,NULL,NULL,NULL),(438,167,'en',438,'Nissan',NULL,NULL,NULL,NULL),(439,167,'en',439,'Alfa Romeo',NULL,NULL,NULL,NULL),(440,167,'en',440,'Aston Martin',NULL,NULL,NULL,NULL),(441,167,'en',441,'Audi',NULL,NULL,NULL,NULL),(443,167,'en',443,'Bentley',NULL,NULL,NULL,NULL),(444,167,'en',444,'BMW',NULL,NULL,NULL,NULL),(445,167,'en',445,'Chevrolet',NULL,NULL,NULL,NULL),(446,167,'en',446,'Chrysler',NULL,NULL,NULL,NULL),(447,167,'en',447,'Citroen',NULL,NULL,NULL,NULL),(448,167,'en',448,'Fiat',NULL,NULL,NULL,NULL),(449,167,'en',449,'Ford',NULL,NULL,NULL,NULL),(450,167,'en',450,'GWM',NULL,NULL,NULL,NULL),(451,167,'en',451,'Honda',NULL,NULL,NULL,NULL),(452,167,'en',452,'Isuzu',NULL,NULL,NULL,NULL),(453,167,'en',453,'Jaguar',NULL,NULL,NULL,NULL),(454,167,'en',454,'Jeep',NULL,NULL,NULL,NULL),(455,167,'en',455,'Kia',NULL,NULL,NULL,NULL),(456,167,'en',456,'Land Rover',NULL,NULL,NULL,NULL),(457,167,'en',457,'Lexus',NULL,NULL,NULL,NULL),(458,167,'en',458,'Mazda',NULL,NULL,NULL,NULL),(459,167,'en',459,'Mercedes-Benz',NULL,NULL,NULL,NULL),(460,167,'en',460,'Mini',NULL,NULL,NULL,NULL),(461,167,'en',461,'Mitsubishi',NULL,NULL,NULL,NULL),(462,167,'en',462,'Opel',NULL,NULL,NULL,NULL),(463,167,'en',463,'Peugeot',NULL,NULL,NULL,NULL),(464,167,'en',464,'Renault',NULL,NULL,NULL,NULL),(465,167,'en',465,'Suzuki',NULL,NULL,NULL,NULL),(466,167,'en',466,'Toyota',NULL,NULL,NULL,NULL),(467,167,'en',467,'Volkswagen',NULL,NULL,NULL,NULL),(468,167,'en',468,'Volvo',NULL,NULL,NULL,NULL),(469,168,'en',469,'Dozer',NULL,NULL,NULL,NULL),(470,168,'en',470,'Hauler',NULL,NULL,NULL,NULL),(471,168,'en',471,'Grader',NULL,NULL,NULL,NULL),(472,168,'en',472,'Compactor',NULL,NULL,NULL,NULL),(473,168,'en',473,'Loader',NULL,NULL,NULL,NULL),(474,168,'en',474,'Crane',NULL,NULL,NULL,NULL),(475,168,'en',475,'Loader',NULL,NULL,NULL,NULL),(476,168,'en',476,'Excavator',NULL,NULL,NULL,NULL),(477,176,'en',477,'Mr.',NULL,NULL,NULL,NULL),(478,176,'en',478,'Ms.',NULL,NULL,NULL,NULL),(479,176,'en',479,'Mrs.',NULL,NULL,NULL,NULL),(480,176,'en',480,'Sir.',NULL,NULL,NULL,NULL),(481,176,'en',481,'Prof.',NULL,NULL,NULL,NULL),(483,178,'en',483,'Red',NULL,NULL,NULL,NULL),(484,178,'en',484,'Orange',NULL,NULL,NULL,NULL),(485,178,'en',485,'Yellow',NULL,NULL,NULL,NULL),(486,178,'en',486,'Green',NULL,NULL,NULL,NULL),(487,178,'en',487,'Blue',NULL,NULL,NULL,NULL),(488,178,'en',488,'Violet',NULL,NULL,NULL,NULL),(489,178,'en',489,'White',NULL,NULL,NULL,NULL),(490,178,'en',490,'Silver',NULL,NULL,NULL,NULL),(491,178,'en',491,'Black',NULL,NULL,NULL,NULL),(492,178,'en',492,'Cream',NULL,NULL,NULL,NULL),(493,179,'en',493,'Sedan',NULL,NULL,NULL,NULL),(494,179,'en',494,'All wheel Drive',NULL,NULL,NULL,NULL),(495,179,'en',495,'Pickup Single Cab - 2 x 4',NULL,NULL,NULL,NULL),(496,179,'en',496,'Pickup Single Cab - 4 x 4',NULL,NULL,NULL,NULL),(497,179,'en',497,'Pick Up Double Cab - 2 x 4',NULL,NULL,NULL,NULL),(498,179,'en',498,'Pick Up Double Cab - 4 x 4',NULL,NULL,NULL,NULL),(499,179,'en',499,'SUV - 2 x 4',NULL,NULL,NULL,NULL),(500,179,'en',500,'SUV - 4 x 4',NULL,NULL,NULL,NULL),(501,163,'en',501,'Kawazaki',NULL,NULL,NULL,NULL),(502,163,'en',502,'Ducati',NULL,NULL,NULL,NULL),(503,163,'en',503,'Harley Davidson',NULL,NULL,NULL,NULL),(504,180,'en',504,'2 Wheeler',NULL,NULL,NULL,NULL),(505,180,'en',505,'3 Wheeler',NULL,NULL,NULL,NULL),(506,180,'en',506,'4 Wheeler - 2 x 4',NULL,NULL,NULL,NULL),(507,180,'en',507,'4 Wheeler - 4 x 4',NULL,NULL,NULL,NULL),(508,180,'en',508,'Quad Bike - 4 Wheeler - 2 x 4',NULL,NULL,NULL,NULL),(509,180,'en',509,'Quad Bike - 4 Wheeler - 4 x 4',NULL,NULL,NULL,NULL),(510,164,'en',510,'Power Star',NULL,NULL,NULL,NULL),(511,181,'en',511,'2 x 4',NULL,NULL,NULL,NULL),(512,181,'en',512,'4 x 4',NULL,NULL,NULL,NULL),(513,181,'en',513,'4 x 6',NULL,NULL,NULL,NULL),(514,181,'en',514,'6 x 6',NULL,NULL,NULL,NULL),(515,181,'en',515,'4 x 8',NULL,NULL,NULL,NULL),(516,181,'en',516,'8 x 8',NULL,NULL,NULL,NULL),(517,182,'en',517,'Mechanical Horse',NULL,NULL,NULL,NULL),(518,182,'en',518,'Side Tipper',NULL,NULL,NULL,NULL),(519,182,'en',519,'Super Link',NULL,NULL,NULL,NULL),(520,182,'en',520,'Low Bed',NULL,NULL,NULL,NULL),(521,182,'en',521,'Low Bed',NULL,NULL,NULL,NULL),(522,182,'en',522,'Water Tanker',NULL,NULL,NULL,NULL),(523,182,'en',523,'Container Skeleton',NULL,NULL,NULL,NULL),(524,182,'en',524,'Tipper',NULL,NULL,NULL,NULL),(525,186,'en',525,'Single Engine',NULL,NULL,NULL,NULL),(526,186,'en',526,'Double Engine',NULL,NULL,NULL,NULL),(527,185,'en',527,'Fiberglass',NULL,NULL,NULL,NULL),(528,185,'en',528,'Steel',NULL,NULL,NULL,NULL),(529,185,'en',529,'Other',NULL,NULL,NULL,NULL),(530,166,'en',530,'Honda',NULL,NULL,NULL,NULL),(531,166,'en',531,'Kawazaki',NULL,NULL,NULL,NULL),(532,166,'en',532,'Yamaha',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `fields_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gender`
--

DROP TABLE IF EXISTS `gender`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gender` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `translation_lang` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `translation_of` int(10) unsigned DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `gender_translation_lang_index` (`translation_lang`),
  KEY `gender_translation_of_index` (`translation_of`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gender`
--

LOCK TABLES `gender` WRITE;
/*!40000 ALTER TABLE `gender` DISABLE KEYS */;
INSERT INTO `gender` VALUES (1,'en',1,'Mr'),(2,'en',2,'Mrs'),(5,'en',5,'Ms'),(6,'en',6,'Dr'),(7,'en',7,'Rev'),(8,'en',8,'Prof');
/*!40000 ALTER TABLE `gender` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `home_sections`
--

DROP TABLE IF EXISTS `home_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `home_sections` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `method` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8_unicode_ci,
  `view` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `field` mediumtext COLLATE utf8_unicode_ci,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `depth` int(10) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `home_sections_method_unique` (`method`),
  KEY `home_sections_active_index` (`active`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `home_sections`
--

LOCK TABLES `home_sections` WRITE;
/*!40000 ALTER TABLE `home_sections` DISABLE KEYS */;
INSERT INTO `home_sections` VALUES (1,'getSearchForm','Search Form Area','{\"enable_form_area_customization\":\"1\",\"background_color\":null,\"background_image\":\"app\\/logo\\/header-5ff5faba5249d.jpeg\",\"height\":null,\"parallax\":\"0\",\"hide_form\":\"0\",\"form_border_color\":\"#FFFFFF\",\"form_border_width\":\"1\",\"form_btn_background_color\":null,\"form_btn_text_color\":null,\"hide_titles\":\"0\",\"title_en\":\"Search First on DAZ LISTING\",\"sub_title_en\":\"Automobiles, Electronics, Real estate and More..\",\"big_title_color\":\"#FFFFFF\",\"sub_title_color\":null,\"hide_on_mobile\":\"0\",\"active\":\"1\"}','home.inc.search',NULL,NULL,0,1,1,1),(2,'getLocations','Locations & Country Map','{\"show_cities\":\"1\",\"show_post_btn\":\"1\",\"background_color\":null,\"border_width\":\"1\",\"border_color\":null,\"text_color\":null,\"link_color\":null,\"link_color_hover\":null,\"max_items\":\"14\",\"items_cols\":\"3\",\"count_cities_posts\":\"0\",\"cache_expiration\":null,\"show_map\":\"1\",\"map_background_color\":null,\"map_border\":null,\"map_hover_border\":null,\"map_border_width\":null,\"map_color\":null,\"map_hover\":null,\"map_width\":null,\"map_height\":null,\"hide_on_mobile\":\"0\",\"active\":\"1\"}','home.inc.locations',NULL,NULL,2,3,1,0),(3,'getSponsoredPosts','Sponsored Ads',NULL,'home.inc.featured',NULL,NULL,4,5,1,1),(4,'getCategories','Categories','{\"type_of_display\":\"c_picture_icon\",\"max_items\":null,\"show_icon\":\"0\",\"count_categories_posts\":\"0\",\"max_sub_cats\":\"3\",\"cache_expiration\":null,\"hide_on_mobile\":\"0\",\"active\":\"1\"}','home.inc.categories',NULL,NULL,6,7,1,1),(5,'getLatestPosts','Latest Ads',NULL,'home.inc.latest',NULL,NULL,8,9,1,1),(6,'getStats','Mini Stats',NULL,'home.inc.stats',NULL,NULL,10,11,1,1),(7,'getTopAdvertising','Advertising #1',NULL,'layouts.inc.advertising.top',NULL,NULL,12,13,1,0),(8,'getBottomAdvertising','Advertising #2',NULL,'layouts.inc.advertising.bottom',NULL,NULL,14,15,1,0);
/*!40000 ALTER TABLE `home_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `languages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `abbr` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `locale` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `native` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `flag` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `app_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `script` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direction` enum('ltr','rtl') COLLATE utf8_unicode_ci DEFAULT 'ltr',
  `russian_pluralization` tinyint(1) unsigned DEFAULT '0',
  `active` tinyint(1) DEFAULT '1',
  `default` tinyint(1) DEFAULT '0',
  `parent_id` int(10) unsigned DEFAULT NULL,
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `depth` int(10) unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `languages_abbr_unique` (`abbr`),
  KEY `languages_active_index` (`active`),
  KEY `languages_default_index` (`default`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `languages`
--

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` VALUES (1,'en','en_US','English','English',NULL,'english','Latn','ltr',0,1,1,NULL,2,3,1,NULL,'2020-12-02 04:58:24','2020-12-02 04:58:24');
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `from_user_id` bigint(20) unsigned DEFAULT NULL,
  `from_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `from_email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `from_phone` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `to_user_id` bigint(20) unsigned DEFAULT NULL,
  `to_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `to_email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `to_phone` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subject` mediumtext COLLATE utf8_unicode_ci,
  `message` mediumtext COLLATE utf8_unicode_ci,
  `filename` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_read` tinyint(1) unsigned DEFAULT '0',
  `deleted_by` int(10) unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `messages_post_id_index` (`post_id`),
  KEY `messages_parent_id_index` (`parent_id`),
  KEY `messages_from_user_id_index` (`from_user_id`),
  KEY `messages_to_user_id_index` (`to_user_id`),
  KEY `messages_deleted_by_index` (`deleted_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meta_tags`
--

DROP TABLE IF EXISTS `meta_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `meta_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `translation_lang` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `translation_of` int(10) unsigned DEFAULT NULL,
  `page` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `keywords` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `meta_tags_translation_lang_index` (`translation_lang`),
  KEY `meta_tags_translation_of_index` (`translation_of`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meta_tags`
--

LOCK TABLES `meta_tags` WRITE;
/*!40000 ALTER TABLE `meta_tags` DISABLE KEYS */;
INSERT INTO `meta_tags` VALUES (1,'en',1,'home','{app_name} - Search first on DAZ Listing','Sell and Buy products and services on {app_name} in Minutes {country}. Free ads in {country}. Looking for a product or service - {country}','{app_name}, {country}, free ads, classified, ads, script, app, premium ads',1),(2,'en',2,'register','Sign Up - {app_name}','Sign Up on {app_name}','{app_name}, {country}, free ads, classified, ads, script, app, premium ads',1),(3,'en',3,'login','Login - {app_name}','Log in to {app_name}','{app_name}, {country}, free ads, classified, ads, script, app, premium ads',1),(4,'en',4,'create','Post Free Ads','Post Free Ads - {country}.','{app_name}, {country}, free ads, classified, ads, script, app, premium ads',1),(5,'en',5,'countries','Free Local Classified Ads in the World','Welcome to {app_name} : 100% Free Ads Classified. Sell and buy near you. Simple, fast and efficient.','{app_name}, {country}, free ads, classified, ads, script, app, premium ads',1),(6,'en',6,'contact','Contact Us - {app_name}','Contact Us - {app_name}','{app_name}, {country}, free ads, classified, ads, script, app, premium ads',1),(7,'en',7,'sitemap','Sitemap {app_name} - {country}','Sitemap {app_name} - {country}. 100% Free Ads Classified','{app_name}, {country}, free ads, classified, ads, script, app, premium ads',1),(8,'en',8,'password','Lost your password? - {app_name}','Lost your password? - {app_name}','{app_name}, {country}, free ads, classified, ads, script, app, premium ads',1),(9,'en',9,'pricing','Pricing - {app_name}','Pricing - {app_name}','{app_name}, {country}, pricing, free ads, classified, ads, script, app, premium ads',1);
/*!40000 ALTER TABLE `meta_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2020_10_12_160714_create_languages_table',1),(2,'2020_10_12_160715_create_advertising_table',1),(3,'2020_10_12_160715_create_blacklist_table',1),(4,'2020_10_12_160715_create_cache_table',1),(5,'2020_10_12_160715_create_categories_table',1),(6,'2020_10_12_160715_create_continents_table',1),(7,'2020_10_12_160715_create_currencies_table',1),(8,'2020_10_12_160715_create_fields_table',1),(9,'2020_10_12_160715_create_gender_table',1),(10,'2020_10_12_160715_create_home_sections_table',1),(11,'2020_10_12_160715_create_meta_tags_table',1),(12,'2020_10_12_160715_create_packages_table',1),(13,'2020_10_12_160715_create_pages_table',1),(14,'2020_10_12_160715_create_password_resets_table',1),(15,'2020_10_12_160715_create_payment_methods_table',1),(16,'2020_10_12_160715_create_permission_tables',1),(17,'2020_10_12_160715_create_post_types_table',1),(18,'2020_10_12_160715_create_report_types_table',1),(19,'2020_10_12_160715_create_sessions_table',1),(20,'2020_10_12_160715_create_settings_table',1),(21,'2020_10_12_160715_create_user_types_table',1),(22,'2020_10_12_160716_create_category_field_table',1),(23,'2020_10_12_160716_create_countries_table',1),(24,'2020_10_12_160716_create_fields_options_table',1),(25,'2020_10_12_160716_create_subadmin1_table',1),(26,'2020_10_12_160716_create_subadmin2_table',1),(27,'2020_10_12_160716_create_time_zones_table',1),(28,'2020_10_12_160716_create_users_table',1),(29,'2020_10_12_160717_create_cities_table',1),(30,'2020_10_12_160717_create_posts_table',1),(31,'2020_10_12_160717_create_saved_posts_table',1),(32,'2020_10_12_160717_create_saved_search_table',1),(33,'2020_10_12_160718_create_messages_table',1),(34,'2020_10_12_160718_create_payments_table',1),(35,'2020_10_12_160718_create_pictures_table',1),(36,'2020_10_12_160718_create_post_values_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',1),(1,'App\\Models\\User',2),(1,'App\\Models\\User',6);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packages`
--

DROP TABLE IF EXISTS `packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `translation_lang` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `translation_of` int(10) unsigned DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'In country language',
  `short_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'In country language',
  `ribbon` enum('red','orange','green') COLLATE utf8_unicode_ci DEFAULT NULL,
  `has_badge` tinyint(1) unsigned DEFAULT '0',
  `price` decimal(10,2) unsigned DEFAULT NULL,
  `currency_code` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `promo_duration` int(11) DEFAULT '30' COMMENT 'In days',
  `duration` int(10) unsigned DEFAULT '30' COMMENT 'In days',
  `pictures_limit` int(11) DEFAULT '5',
  `description` text COLLATE utf8_unicode_ci COMMENT 'In country language',
  `facebook_ads_duration` int(10) unsigned DEFAULT '0',
  `google_ads_duration` int(10) unsigned DEFAULT '0',
  `twitter_ads_duration` int(10) unsigned DEFAULT '0',
  `linkedin_ads_duration` int(10) unsigned DEFAULT '0',
  `recommended` tinyint(1) DEFAULT '0',
  `parent_id` int(10) unsigned DEFAULT NULL,
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `depth` int(10) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `packages_active_index` (`active`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages`
--

LOCK TABLES `packages` WRITE;
/*!40000 ALTER TABLE `packages` DISABLE KEYS */;
INSERT INTO `packages` VALUES (2,'en',2,'Top page Ad','Premium','orange',1,300.00,'NAD',30,60,10,'Featured on the homepage\r\nFeatured in the category',0,NULL,0,0,1,NULL,4,5,0,1),(3,'en',3,'Top page Ad+','Premium+','green',1,500.00,'NAD',60,120,15,'Featured on the homepage\r\nFeatured in the category',0,0,0,0,0,NULL,6,7,0,1);
/*!40000 ALTER TABLE `packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `translation_lang` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `translation_of` int(10) unsigned DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `type` enum('standard','terms','privacy','tips') COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` mediumtext COLLATE utf8_unicode_ci,
  `external_link` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `depth` int(10) unsigned DEFAULT NULL,
  `name_color` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title_color` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `target_blank` tinyint(1) unsigned DEFAULT '0',
  `excluded_from_footer` tinyint(1) unsigned DEFAULT '0',
  `active` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pages_translation_lang_index` (`translation_lang`),
  KEY `pages_translation_of_index` (`translation_of`),
  KEY `pages_parent_id_index` (`parent_id`),
  KEY `pages_active_index` (`active`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,'en',1,NULL,'terms','Terms','terms','Terms & Conditions',NULL,'<h4><strong>Definitions</strong></h4>\r\n<p>Each of the terms mentioned below have in these Conditions of Sale of Daz Listing (hereinafter the \"Conditions\") the following meanings:</p>\r\n<ol>\r\n<li>Announcement&nbsp;: refers to all the elements and data (visual, textual, sound, photographs, drawings), presented by an Advertiser editorial under his sole responsibility, in order to buy, rent or sell a product or service and broadcast on the Website and Mobile Site.</li>\r\n<li>Advertiser&nbsp;: means any natural or legal person, a major, established in Namibia, holds an account and having submitted an announcement, from it, on the Website. Any Advertiser must be connected to the Personal Account for deposit and or manage its ads. Ad first deposit automatically entails the establishment of a Personal Account to the Advertiser.</li>\r\n<li>Personal Account&nbsp;: refers to the free space than any Advertiser must create and which it should connect from the Website to disseminate, manage and view its ads.</li>\r\n<li>Paradox Investments Limited : means the company that publishes and operates the Website and Mobile Site {listing.com.na}, registered at the Trade and Companies Register of {YourCity} under the number {YourCompany Registration Number} whose registered office is at {YourCompany Address}.</li>\r\n<li>Customer Service&nbsp;: Daz Listing means the department to which the Advertiser may obtain further information. This service can be contacted via email by clicking the link on the Website and Mobile Site.</li>\r\n<li>Daz Listing : Daz Listing means the services made available to Users and Advertisers on the Website and Mobile Site.</li>\r\n<li>Website&nbsp;: means the website operated by Daz Listing accessed mainly from the URL <a href=\"https://bedigit.com\">https://listing.com.na</a> and allowing Users and Advertisers to access the Service via internet Daz Listing.</li>\r\n<li>Mobile Site&nbsp;: is the mobile site operated by Daz Listing accessible from the URL <a href=\"https://bedigit.com\">https://listing.com.na</a> and allowing Users and Advertisers to access via their mobile phone service {Daz Listing}.</li>\r\n<li>User&nbsp;: any visitor with access to Daz Listing via the Website and Mobile Site and Consultant Service Daz Listing accessible from different media.</li>\r\n</ol>\r\n<h4><strong>Subject</strong></h4>\r\n<p>These Terms and Conditions Of Use establish the contractual conditions applicable to any subscription by an Advertiser connected to its Personal Account from the Website and Mobile Site.</p>\r\n<h4><strong>Acceptance</strong></h4>\r\n<p>Any use of the website by an Advertiser is full acceptance of the current Terms.</p>\r\n<h4><strong>Responsibility</strong></h4>\r\n<p>Responsibility for Daz Listing can not be held liable for non-performance or improper performance of due control, either because of the Advertiser, or a case of major force.</p>\r\n<h4><strong>Modification of these terms</strong></h4>\r\n<p>Paradox Investments Limited reserves the right, at any time, to modify all or part of the Terms and Conditions.</p>\r\n<p>Advertisers are advised to consult the Terms to be aware of the changes.</p>\r\n<h4><strong>Miscellaneous</strong></h4>\r\n<p>If part of the Terms should be illegal, invalid or unenforceable for any reason whatsoever, the provisions in question would be deemed unwritten, without questioning the validity of the remaining provisions will continue to apply between Advertisers and Daz Listing.</p>\r\n<p>Any complaints should be addressed to Customer Service complaints@listing.com.na</p>',NULL,6,7,1,NULL,NULL,0,0,1,'2020-12-02 04:58:28','2020-12-02 11:35:07'),(2,'en',2,NULL,'privacy','Privacy','privacy','Privacy',NULL,'<p>Your privacy is an important part of our relationship with you. Protecting your privacy is only part of our mission to provide a secure web environment. When using our site, including our services, your information will remain strictly confidential. Contributions made on our blog or on our forum are open to public view; so please do not post any personal information in your dealings with others. We accept no liability for those actions because it is your sole responsibility to adequate and safe post content on our site. We will not share, rent or share your information with third parties.</p>\r\n<p>When you visit our site, we collect technical information about your computer and how you access our website and analyze this information such as Internet Protocol (IP) address of your computer, the operating system used by your computer, the browser (eg, Chrome, Firefox, Internet Explorer or other) your computer uses, the name of your Internet service provider (ISP), the Uniform Resource Locator (URL) of the website from which you come and the URL to which you go next and certain operating metrics such as the number of times you use our website. This general information can be used to help us better understand how our site is viewed and used. We may share this general information about our site with our business partners or the general public. For example, we may share the information on the number of daily unique visitors to our site with potential corporate partners or use them for advertising purposes. This information does contain any of your personal data that can be used to contact you or identify you.</p>\r\n<p>When we place links or banners to other sites of our website, please note that we do not control this kind of content or practices or privacy policies of those sites. We do not endorse or assume no responsibility for the privacy policies or information collection practices of any other website other than managed sites Daz Listing.</p>\r\n<p>We use the highest security standard available to protect your identifiable information in transit to us. All data stored on our servers are protected by a secure firewall for the unauthorized use or activity can not take place. Although we make every effort to protect your personal information against loss, misuse or alteration by third parties, you should be aware that there is always a risk that low-intentioned manage to find a way to thwart our security system or that Internet transmissions could be intercepted.</p>\r\n<p>We reserve the right, without notice, to change, modify, add or remove portions of our Privacy Policy at any time and from time to time. These changes will be posted publicly on our website. When you visit our website, you accept all the terms of our privacy policy. Your continued use of this website constitutes your continued agreement to these terms. If you do not agree with the terms of our privacy policy, you should cease using our website.</p>',NULL,8,9,1,NULL,NULL,0,0,1,'2020-12-02 04:58:28','2020-12-02 11:36:24'),(3,'en',3,NULL,'standard','Anti-Scam','anti-scam','Anti-Scam',NULL,'<p><b>Protect yourself against Internet fraud!</b></p><p>The vast majority of ads are posted by honest people and trust. So you can do excellent business. Despite this, it is important to follow a few common sense rules following to prevent any attempt to scam.</p><p><b>Our advices</b></p><ul><li>Doing business with people you can meet in person.</li><li>Never send money by Western Union, MoneyGram or other anonymous payment systems.</li><li>Never send money or products abroad.</li><li>Do not accept checks.</li><li>Ask about the person you\'re dealing with another confirming source name, address and telephone number.</li><li>Keep copies of all correspondence (emails, ads, letters, etc.) and details of the person.</li><li>If a deal seems too good to be true, there is every chance that this is the case. Refrain.</li></ul><p><b>Recognize attempted scam</b></p><ul><li>The majority of scams have one or more of these characteristics:</li><li>The person is abroad or traveling abroad.</li><li>The person refuses to meet you in person.</li><li>Payment is made through Western Union, Money Gram or check.</li><li>The messages are in broken language (English or French or ...).</li><li>The texts seem to be copied and pasted.</li><li>The deal seems to be too good to be true.</li></ul>',NULL,4,5,1,NULL,NULL,0,0,1,'2020-12-02 04:58:28','2020-12-02 04:58:28'),(4,'en',4,NULL,'standard','FAQ','faq','Frequently Asked Questions',NULL,'<p><b>How do I place an ad?</b></p><p>It\'s very easy to place an ad: click on the button \"Post free Ads\" above right.</p><p><b>What does it cost to advertise?</b></p><p>The publication is 100% free throughout the website.</p><p><b>If I post an ad, will I also get more spam e-mails?</b></p><p>Absolutely not because your email address is not visible on the website.</p><p><b>How long will my ad remain on the website?</b></p><p>In general, an ad is automatically deactivated from the website after 3 months. You will receive an email a week before D-Day and another on the day of deactivation. You have the ability to put them online in the following month by logging into your account on the site. After this delay, your ad will be automatically removed permanently from the website.</p><p><b>I sold my item. How do I delete my ad?</b></p><p>Once your product is sold or leased, log in to your account to remove your ad.</p>',NULL,2,3,1,NULL,NULL,0,0,1,'2020-12-02 04:58:28','2020-12-02 04:58:28');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
INSERT INTO `password_resets` VALUES ('melodydoeses@gmail.com','','$2y$10$h/H8Nc6YVN4UpLHKSNBVkeJiZOoKipTccSJ6WSI1YGRyXSNoqCbzW','2021-03-02 11:48:48',NULL);
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_methods`
--

DROP TABLE IF EXISTS `payment_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_methods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `display_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` mediumtext COLLATE utf8_unicode_ci,
  `has_ccbox` tinyint(1) unsigned DEFAULT '0',
  `is_compatible_api` tinyint(1) DEFAULT '0',
  `countries` mediumtext COLLATE utf8_unicode_ci COMMENT 'Countries codes separated by comma.',
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `depth` int(10) unsigned DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT '0',
  `active` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `payment_methods_has_ccbox_index` (`has_ccbox`),
  KEY `payment_methods_active_index` (`active`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_methods`
--

LOCK TABLES `payment_methods` WRITE;
/*!40000 ALTER TABLE `payment_methods` DISABLE KEYS */;
INSERT INTO `payment_methods` VALUES (1,'paypal','Paypal','Payment with Paypal',0,0,'',0,0,1,0,1);
/*!40000 ALTER TABLE `payment_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `package_id` int(10) unsigned DEFAULT NULL,
  `payment_method_id` int(10) unsigned DEFAULT NULL,
  `transaction_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Transaction''s ID at the Provider',
  `amount` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `active` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payments_package_id_index` (`package_id`),
  KEY `payments_payment_method_id_index` (`payment_method_id`),
  KEY `payments_post_id_index` (`post_id`),
  KEY `payments_active_index` (`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'permission-list','web','2020-12-02 04:58:32','2020-12-02 04:58:32'),(2,'permission-create','web','2020-12-02 04:58:32','2020-12-02 04:58:32'),(3,'permission-update','web','2020-12-02 04:58:32','2020-12-02 04:58:32'),(4,'permission-delete','web','2020-12-02 04:58:32','2020-12-02 04:58:32'),(5,'role-list','web','2020-12-02 04:58:32','2020-12-02 04:58:32'),(6,'role-create','web','2020-12-02 04:58:32','2020-12-02 04:58:32'),(7,'role-update','web','2020-12-02 04:58:32','2020-12-02 04:58:32'),(8,'role-delete','web','2020-12-02 04:58:32','2020-12-02 04:58:32'),(9,'dashboard-access','web','2020-12-02 04:58:32','2020-12-02 04:58:32');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pictures`
--

DROP TABLE IF EXISTS `pictures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pictures` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `position` int(10) unsigned NOT NULL DEFAULT '0',
  `active` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pictures_post_id_index` (`post_id`),
  KEY `pictures_active_index` (`active`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pictures`
--

LOCK TABLES `pictures` WRITE;
/*!40000 ALTER TABLE `pictures` DISABLE KEYS */;
INSERT INTO `pictures` VALUES (30,24,'files/na/24/70a1c9df9dc934dbc0e017dcd0baa9d2.jpeg',1,1,'2021-01-05 23:12:06','2021-01-05 23:12:06'),(72,44,'files/na/44/eca4407fc5ef8c0b6352a740cbb159cb.jpg',1,1,'2021-02-14 14:27:54','2021-02-14 14:27:54');
/*!40000 ALTER TABLE `pictures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_types`
--

DROP TABLE IF EXISTS `post_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `translation_lang` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `translation_of` int(10) unsigned DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `depth` int(10) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `post_types_translation_lang_index` (`translation_lang`),
  KEY `post_types_translation_of_index` (`translation_of`),
  KEY `post_types_active_index` (`active`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_types`
--

LOCK TABLES `post_types` WRITE;
/*!40000 ALTER TABLE `post_types` DISABLE KEYS */;
INSERT INTO `post_types` VALUES (1,'en',1,'Private individual',NULL,NULL,NULL,1),(2,'en',2,'Professional/ Business/ Organisation',NULL,NULL,NULL,1);
/*!40000 ALTER TABLE `post_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_values`
--

DROP TABLE IF EXISTS `post_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_values` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `field_id` int(10) unsigned DEFAULT NULL,
  `option_id` int(10) unsigned DEFAULT NULL,
  `value` mediumtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `post_values_post_id_index` (`post_id`),
  KEY `post_values_field_id_index` (`field_id`),
  KEY `post_values_option_id_index` (`option_id`)
) ENGINE=InnoDB AUTO_INCREMENT=177 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_values`
--

LOCK TABLES `post_values` WRITE;
/*!40000 ALTER TABLE `post_values` DISABLE KEYS */;
INSERT INTO `post_values` VALUES (131,24,176,NULL,'478'),(166,44,161,NULL,'373'),(167,44,175,NULL,'1998'),(168,44,179,NULL,'493'),(169,44,173,NULL,'122500'),(170,44,7,NULL,'63'),(171,44,178,NULL,'487'),(172,44,8,NULL,'66'),(173,44,6,59,'59'),(174,44,6,60,'60'),(175,44,6,61,'61'),(176,44,6,62,'62');
/*!40000 ALTER TABLE `post_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `country_code` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `post_type_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `tags` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price` decimal(17,2) unsigned DEFAULT NULL,
  `negotiable` tinyint(1) DEFAULT '0',
  `contact_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone_hidden` tinyint(1) DEFAULT '0',
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city_id` bigint(20) unsigned DEFAULT NULL,
  `lon` double(8,2) DEFAULT NULL COMMENT 'longitude in decimal degrees (wgs84)',
  `lat` double(8,2) DEFAULT NULL COMMENT 'latitude in decimal degrees (wgs84)',
  `ip_addr` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `visits` int(10) unsigned DEFAULT '0',
  `email_token` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone_token` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tmp_token` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `verified_email` tinyint(1) unsigned DEFAULT '0',
  `verified_phone` tinyint(1) unsigned DEFAULT '1',
  `accept_terms` tinyint(1) DEFAULT '0',
  `accept_marketing_offers` tinyint(1) DEFAULT '0',
  `is_permanent` tinyint(1) DEFAULT '0',
  `reviewed` tinyint(1) DEFAULT '0',
  `featured` tinyint(1) unsigned DEFAULT '0',
  `archived` tinyint(1) DEFAULT '0',
  `archived_at` timestamp NULL DEFAULT NULL,
  `archived_manually` tinyint(1) unsigned DEFAULT '0',
  `deletion_mail_sent_at` timestamp NULL DEFAULT NULL,
  `fb_profile` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `partner` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `posts_lon_lat_index` (`lon`,`lat`),
  KEY `posts_country_code_index` (`country_code`),
  KEY `posts_user_id_index` (`user_id`),
  KEY `posts_category_id_index` (`category_id`),
  KEY `posts_title_index` (`title`),
  KEY `posts_address_index` (`address`),
  KEY `posts_city_id_index` (`city_id`),
  KEY `posts_reviewed_index` (`reviewed`),
  KEY `posts_featured_index` (`featured`),
  KEY `posts_post_type_id_index` (`post_type_id`),
  KEY `posts_contact_name_index` (`contact_name`),
  KEY `posts_verified_email_index` (`verified_email`),
  KEY `posts_verified_phone_index` (`verified_phone`),
  KEY `posts_archived_index` (`archived`),
  KEY `posts_tags_index` (`tags`),
  KEY `posts_is_permanent_index` (`is_permanent`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES (24,'NA',0,65,2,'Nj hair','<p>100% human deep curls </p>','na',200.00,NULL,'Ndina Jonas','Ndinajonas20@gmail.com','+264813049244',NULL,NULL,2,17.08,-22.56,'105.232.255.172',97,NULL,NULL,NULL,1,1,1,1,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,'2021-01-05 23:11:25','2021-04-10 17:18:05'),(44,'NA',6,2,1,'cars','<p>1998 bmw shadoline</p>\n<p> </p>','',120000.00,NULL,'Benny Josea','bf788864@gmail.com','+264813588650',NULL,NULL,2,17.08,-22.56,'41.182.98.120',34,NULL,NULL,NULL,1,1,0,0,0,0,0,0,NULL,0,NULL,NULL,NULL,NULL,'2021-02-14 14:26:35','2021-04-10 17:00:57');
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_types`
--

DROP TABLE IF EXISTS `report_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `translation_lang` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `translation_of` int(10) unsigned DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `report_types_translation_lang_index` (`translation_lang`),
  KEY `report_types_translation_of_index` (`translation_of`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_types`
--

LOCK TABLES `report_types` WRITE;
/*!40000 ALTER TABLE `report_types` DISABLE KEYS */;
INSERT INTO `report_types` VALUES (1,'en',1,'Fraud'),(2,'en',2,'Duplicate'),(3,'en',3,'Spam'),(4,'en',4,'Wrong category'),(5,'en',5,'Other');
/*!40000 ALTER TABLE `report_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,1),(1,2),(2,1),(2,2),(3,1),(4,1),(5,1),(5,2),(6,1),(6,2),(7,1),(8,1),(9,1),(9,2);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'super-admin','web','2020-12-02 04:58:32','2020-12-02 04:58:32'),(2,'Manager','web','2020-12-02 10:43:34','2020-12-02 10:43:34');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saved_posts`
--

DROP TABLE IF EXISTS `saved_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saved_posts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `saved_posts_user_id_index` (`user_id`),
  KEY `saved_posts_post_id_index` (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saved_posts`
--

LOCK TABLES `saved_posts` WRITE;
/*!40000 ALTER TABLE `saved_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `saved_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saved_search`
--

DROP TABLE IF EXISTS `saved_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saved_search` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `country_code` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `keyword` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'To show',
  `query` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `count` int(10) unsigned DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `saved_search_user_id_index` (`user_id`),
  KEY `saved_search_country_code_index` (`country_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saved_search`
--

LOCK TABLES `saved_search` WRITE;
/*!40000 ALTER TABLE `saved_search` DISABLE KEYS */;
/*!40000 ALTER TABLE `saved_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(11) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `payload` mediumtext COLLATE utf8_unicode_ci,
  `last_activity` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `ip_address` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_agent` mediumtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8_unicode_ci,
  `description` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `field` mediumtext COLLATE utf8_unicode_ci,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `lft` int(10) unsigned DEFAULT NULL,
  `rgt` int(10) unsigned DEFAULT NULL,
  `depth` int(10) unsigned DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`),
  KEY `settings_active_index` (`active`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'app','Application','{\"purchase_code\":\"385532ec-d3c2-404d-8e45-592dd76acdef\",\"app_name\":\"DAZ LISTING\",\"slogan\":\"LIFE DOSE IMPROVE HERE\",\"logo\":\"app\\/logo\\/logo-5ff5f97b55944.png\",\"favicon\":\"app\\/ico\\/ico-5ff5f97b59b51.png\",\"email\":\"paul@parezagroup.com\",\"phone_number\":null,\"auto_detect_language\":\"0\",\"default_date_format\":\"%d %B %Y\",\"default_datetime_format\":\"%d %B %Y %H:%M\",\"default_timezone\":\"Africa\\/Windhoek\",\"date_force_utf8\":\"0\",\"logo_dark\":\"app\\/backend\\/logo-dark-5ff5f97b664d8.png\",\"logo_light\":\"app\\/backend\\/logo-light-5ff5f97b72a54.png\",\"vector_charts_type\":\"morris_bar\",\"latest_entries_limit\":\"5\",\"show_countries_charts\":\"1\"}','Application Setup',NULL,0,2,3,1,1,NULL,NULL),(2,'style','Style','{\"app_skin\":\"skin-red\",\"body_background_color\":null,\"body_text_color\":null,\"body_background_image\":null,\"body_background_image_fixed\":\"0\",\"page_width\":null,\"title_color\":null,\"progress_background_color\":null,\"link_color\":null,\"link_color_hover\":null,\"header_sticky\":\"0\",\"header_height\":null,\"header_background_color\":null,\"header_bottom_border_width\":null,\"header_bottom_border_color\":\"#E8E8E8\",\"header_link_color\":null,\"header_link_color_hover\":null,\"footer_background_color\":null,\"footer_text_color\":null,\"footer_title_color\":null,\"footer_link_color\":null,\"footer_link_color_hover\":null,\"payment_icon_top_border_width\":null,\"payment_icon_top_border_color\":null,\"payment_icon_bottom_border_width\":null,\"payment_icon_bottom_border_color\":null,\"btn_post_bg_top_color\":\"#D10F33\",\"btn_post_bg_bottom_color\":\"#D10F33\",\"btn_post_border_color\":\"#D10F33\",\"btn_post_text_color\":\"#FFFFFF\",\"btn_post_bg_top_color_hover\":\"#D10F33\",\"btn_post_bg_bottom_color_hover\":\"#D10F33\",\"btn_post_border_color_hover\":\"#D10F33\",\"btn_post_text_color_hover\":\"#FFFFFF\",\"custom_css\":null,\"login_bg_image\":null,\"admin_logo_bg\":\"skin2\",\"admin_navbar_bg\":\"skin6\",\"admin_sidebar_type\":\"full\",\"admin_sidebar_bg\":\"skin5\",\"admin_sidebar_position\":\"1\",\"admin_header_position\":\"1\",\"admin_boxed_layout\":\"0\",\"admin_dark_theme\":\"0\"}','Style Customization',NULL,0,4,5,1,1,NULL,NULL),(3,'listing','Listing & Search','{\"display_mode\":\".grid-view\",\"grid_view_cols\":\"4\",\"items_per_page\":\"16\",\"left_sidebar\":\"1\",\"cities_extended_searches\":\"1\",\"distance_calculation_formula\":\"haversine\",\"search_distance_default\":\"50\",\"search_distance_max\":\"1000\",\"search_distance_interval\":\"100\"}','Listing & Search Options',NULL,0,6,7,1,1,NULL,NULL),(4,'single','Ads (Form & Single Page)','{\"publication_form_type\":\"1\",\"picture_mandatory\":\"1\",\"pictures_limit\":\"6\",\"tags_limit\":\"15\",\"guests_can_post_ads\":\"1\",\"posts_review_activation\":\"0\",\"permanent_posts_enabled\":\"0\",\"pricing_page_enabled\":\"1\",\"auto_registration\":\"1\",\"wysiwyg_editor\":\"tinymce\",\"remove_url_before\":\"1\",\"remove_url_after\":\"1\",\"remove_email_before\":\"0\",\"remove_email_after\":\"1\",\"remove_phone_before\":\"0\",\"remove_phone_after\":\"0\",\"convert_phone_number_to_img\":\"0\",\"hide_phone_number\":\"0\",\"show_security_tips\":\"0\",\"enable_whatsapp_btn\":\"0\",\"pre_filled_whatsapp_message\":\"0\",\"guests_can_contact_ads_authors\":\"1\",\"similar_posts\":\"1\",\"show_post_on_googlemap\":\"0\",\"activation_facebook_comments\":\"0\"}','Ads (Form & Single Page) Options',NULL,0,8,9,1,1,NULL,NULL),(5,'mail','Mail','{\"email_sender\":\"paul@parezagroup.com\",\"driver\":\"sendmail\",\"sendmail_path\":\"\\/usr\\/sbin\\/sendmail -bs\"}','Mail Sending Configuration',NULL,0,10,11,1,1,NULL,NULL),(6,'sms','SMS',NULL,'SMS Sending Configuration',NULL,0,12,13,1,1,NULL,NULL),(7,'upload','Upload','{\"file_types\":\"pdf,doc,docx,word,rtf,rtx,ppt,pptx,odt,odp,wps,jpeg,jpg,bmp,png\",\"min_file_size\":\"0\",\"max_file_size\":\"3500\",\"image_types\":\"jpg,jpeg,gif,png\",\"image_quality\":\"90\",\"min_image_size\":\"0\",\"max_image_size\":\"2500\",\"img_resize_width\":\"1500\",\"img_resize_height\":\"1500\",\"img_resize_ratio\":\"1\",\"img_resize_upsize\":\"0\",\"img_resize_logo_width\":\"500\",\"img_resize_logo_height\":\"100\",\"img_resize_logo_ratio\":\"1\",\"img_resize_logo_upsize\":\"0\",\"img_resize_cat_width\":\"70\",\"img_resize_cat_height\":\"70\",\"img_resize_cat_ratio\":\"1\",\"img_resize_cat_upsize\":\"0\",\"img_resize_small_resize_type\":\"2\",\"img_resize_small_width\":\"120\",\"img_resize_small_height\":\"90\",\"img_resize_small_ratio\":\"1\",\"img_resize_small_upsize\":\"0\",\"img_resize_small_position\":\"center\",\"img_resize_small_relative\":\"0\",\"img_resize_small_bg_color\":\"#FFFFFF\",\"img_resize_medium_resize_type\":\"2\",\"img_resize_medium_width\":\"320\",\"img_resize_medium_height\":\"240\",\"img_resize_medium_ratio\":\"1\",\"img_resize_medium_upsize\":\"0\",\"img_resize_medium_position\":\"center\",\"img_resize_medium_relative\":\"0\",\"img_resize_medium_bg_color\":\"#FFFFFF\",\"img_resize_big_resize_type\":\"0\",\"img_resize_big_width\":\"816\",\"img_resize_big_height\":\"460\",\"img_resize_big_ratio\":\"1\",\"img_resize_big_upsize\":\"0\",\"img_resize_big_position\":\"center\",\"img_resize_big_relative\":\"0\",\"img_resize_big_bg_color\":\"#FFFFFF\"}','Upload Settings',NULL,0,14,15,1,1,NULL,NULL),(8,'geo_location','Geo Location','{\"default_country_code\":\"NA\"}','Geo Location Configuration',NULL,0,16,17,1,1,NULL,NULL),(9,'security','Security',NULL,'Security Options',NULL,0,18,19,1,1,NULL,NULL),(10,'social_auth','Social Login',NULL,'Social Network Login',NULL,0,20,21,1,1,NULL,NULL),(11,'social_link','Social Network',NULL,'Social Network Profiles',NULL,0,22,23,1,1,NULL,NULL),(12,'optimization','Optimization',NULL,'Optimization Tools',NULL,0,24,25,1,1,NULL,NULL),(13,'seo','SEO',NULL,'SEO Tools',NULL,0,26,27,1,1,NULL,NULL),(14,'other','Others',NULL,'Other Options',NULL,0,28,29,1,1,NULL,NULL),(15,'cron','Cron',NULL,'Cron Job',NULL,0,30,31,1,1,NULL,NULL),(16,'footer','Footer','{\"hide_links\":\"0\",\"hide_payment_plugins_logos\":\"1\",\"hide_powered_by\":\"0\",\"powered_by_info\":\"Pareza\",\"tracking_code\":null}','Pages Footer',NULL,0,32,33,1,1,NULL,NULL),(17,'backup','Backup',NULL,'Backup Configuration',NULL,0,34,35,1,1,NULL,NULL);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subadmin1`
--

DROP TABLE IF EXISTS `subadmin1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subadmin1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `country_code` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `asciiname` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `subadmin1_code_unique` (`code`),
  KEY `subadmin1_name_index` (`name`),
  KEY `subadmin1_active_index` (`active`),
  KEY `subadmin1_country_code_index` (`country_code`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subadmin1`
--

LOCK TABLES `subadmin1` WRITE;
/*!40000 ALTER TABLE `subadmin1` DISABLE KEYS */;
INSERT INTO `subadmin1` VALUES (1,'NA.28','NA','Zambezi','Zambezi',1,NULL,NULL),(2,'NA.21','NA','Khomas','Khomas',1,NULL,NULL),(3,'NA.29','NA','Erongo','Erongo',1,NULL,NULL),(4,'NA.30','NA','Hardap','Hardap',1,NULL,NULL),(5,'NA.31','NA','Karas','Karas',1,NULL,NULL),(6,'NA.32','NA','Kunene','Kunene',1,NULL,NULL),(7,'NA.33','NA','Ohangwena','Ohangwena',1,NULL,NULL),(8,'NA.35','NA','Omaheke','Omaheke',1,NULL,NULL),(9,'NA.36','NA','Omusati','Omusati',1,NULL,NULL),(10,'NA.37','NA','Oshana','Oshana',1,NULL,NULL),(11,'NA.38','NA','Oshikoto','Oshikoto',1,NULL,NULL),(12,'NA.39','NA','Otjozondjupa','Otjozondjupa',1,NULL,NULL),(13,'NA.40','NA','Kavango East','Kavango East',1,NULL,NULL),(14,'NA.41','NA','Kavango West','Kavango West',1,NULL,NULL);
/*!40000 ALTER TABLE `subadmin1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subadmin2`
--

DROP TABLE IF EXISTS `subadmin2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subadmin2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `country_code` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subadmin1_code` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `asciiname` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `subadmin2_code_unique` (`code`),
  KEY `subadmin2_name_index` (`name`),
  KEY `subadmin2_active_index` (`active`),
  KEY `subadmin2_country_code_index` (`country_code`),
  KEY `subadmin2_subadmin1_code_index` (`subadmin1_code`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subadmin2`
--

LOCK TABLES `subadmin2` WRITE;
/*!40000 ALTER TABLE `subadmin2` DISABLE KEYS */;
INSERT INTO `subadmin2` VALUES (1,'NA.32.7931901','NA','NA.32','Epupa Constituency','Epupa Constituency',1,NULL,NULL),(2,'NA.32.7931902','NA','NA.32','Opuwo Constituency','Opuwo Constituency',1,NULL,NULL),(3,'NA.32.7931903','NA','NA.32','Sesfontein Constituency','Sesfontein Constituency',1,NULL,NULL),(4,'NA.32.7931904','NA','NA.32','Khorixas Constituency','Khorixas Constituency',1,NULL,NULL),(5,'NA.29.7931905','NA','NA.29','Daures Constituency','Daures Constituency',1,NULL,NULL),(6,'NA.29.7931906','NA','NA.29','Arandis Constituency','Arandis Constituency',1,NULL,NULL),(7,'NA.29.7931907','NA','NA.29','Swakopmund Constituency','Swakopmund Constituency',1,NULL,NULL),(8,'NA.29.7931908','NA','NA.29','Walvis Bay Urban Constituency','Walvis Bay Urban Constituency',1,NULL,NULL),(9,'NA.29.7931909','NA','NA.29','Walvis Bay Rural Constituency','Walvis Bay Rural Constituency',1,NULL,NULL),(10,'NA.30.7931910','NA','NA.30','Gibeon Constituency','Gibeon Constituency',1,NULL,NULL),(11,'NA.31.7931911','NA','NA.31','Luderitz Constituency','Luderitz Constituency',1,NULL,NULL),(12,'NA.31.7931912','NA','NA.31','Oranjemund Constituency','Oranjemund Constituency',1,NULL,NULL),(13,'NA.39.10400504','NA','NA.39','Omatako Constituency','Omatako Constituency',1,NULL,NULL),(14,'NA.21.11125897','NA','NA.21','Moses Garoeb','Moses Garoeb',1,NULL,NULL),(15,'NA.35.11204872','NA','NA.35','Otjombinde','Otjombinde',1,NULL,NULL),(16,'NA.38.11204947','NA','NA.38','Olukonda Constituency','Olukonda Constituency',1,NULL,NULL),(17,'NA.39.11204952','NA','NA.39','Okahandja Constituency','Okahandja Constituency',1,NULL,NULL),(18,'NA.33.11205493','NA','NA.33','Epembe Constituency','Epembe Constituency',1,NULL,NULL),(19,'NA.33.11205499','NA','NA.33','Endola','Endola',1,NULL,NULL),(20,'NA.37.11205500','NA','NA.37','Oshakati East','Oshakati East',1,NULL,NULL),(21,'NA.38.11205505','NA','NA.38','Omuntele Constituency','Omuntele Constituency',1,NULL,NULL),(22,'NA.40.11205595','NA','NA.40','Rundu Rural West','Rundu Rural West',1,NULL,NULL),(23,'NA.33.11238950','NA','NA.33','Oshikango','Oshikango',1,NULL,NULL),(24,'NA.41.11256866','NA','NA.41','Kapako Constituency','Kapako Constituency',1,NULL,NULL),(25,'NA.40.11256901','NA','NA.40','Mashare','Mashare',1,NULL,NULL),(26,'NA.36.11256953','NA','NA.36','Tsandi','Tsandi',1,NULL,NULL),(27,'NA.21.11257205','NA','NA.21','Samora Machel','Samora Machel',1,NULL,NULL),(28,'NA.37.11257218','NA','NA.37','Oshakati West','Oshakati West',1,NULL,NULL),(29,'NA.36.11257223','NA','NA.36','Etayi','Etayi',1,NULL,NULL),(30,'NA.30.11257257','NA','NA.30','Rehoboth Rural','Rehoboth Rural',1,NULL,NULL),(31,'NA.31.11257293','NA','NA.31','Karasburg Constituency','Karasburg Constituency',1,NULL,NULL),(32,'NA.38.11257350','NA','NA.38','Eengodi','Eengodi',1,NULL,NULL),(33,'NA.21.11287032','NA','NA.21','Windhoek Rural','Windhoek Rural',1,NULL,NULL),(34,'NA.30.11427240','NA','NA.30','Mariental Rural','Mariental Rural',1,NULL,NULL),(35,'NA.37.11428032','NA','NA.37','Okaku Constituency','Okaku Constituency',1,NULL,NULL),(36,'NA.36.11428097','NA','NA.36','Oshikuku','Oshikuku',1,NULL,NULL),(37,'NA.37.11428703','NA','NA.37','Ongwediva','Ongwediva',1,NULL,NULL),(38,'NA.33.11428769','NA','NA.33','Omuthiyagwiipundi','Omuthiyagwiipundi',1,NULL,NULL),(39,'NA.39.11428998','NA','NA.39','Otavi','Otavi',1,NULL,NULL),(40,'NA.41.11429079','NA','NA.41','Mpungu','Mpungu',1,NULL,NULL),(41,'NA.40.11429192','NA','NA.40','Rundu Urban','Rundu Urban',1,NULL,NULL),(42,'NA.28.11467713','NA','NA.28','Linyanti','Linyanti',1,NULL,NULL),(43,'NA.37.11467743','NA','NA.37','Uukwiyu','Uukwiyu',1,NULL,NULL),(44,'NA.38.11467812','NA','NA.38','Onayena','Onayena',1,NULL,NULL),(45,'NA.36.11495912','NA','NA.36','Anamulenge Constituency','Anamulenge Constituency',1,NULL,NULL),(46,'NA.21.11609877','NA','NA.21','Windhoek East','Windhoek East',1,NULL,NULL),(47,'NA.36.11979320','NA','NA.36','Okahao','Okahao',1,NULL,NULL);
/*!40000 ALTER TABLE `subadmin2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `time_zones`
--

DROP TABLE IF EXISTS `time_zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `time_zones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `country_code` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `time_zone_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gmt` double DEFAULT NULL,
  `dst` double DEFAULT NULL,
  `raw` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `time_zones_time_zone_id_unique` (`time_zone_id`),
  KEY `time_zones_country_code_index` (`country_code`)
) ENGINE=InnoDB AUTO_INCREMENT=425 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `time_zones`
--

LOCK TABLES `time_zones` WRITE;
/*!40000 ALTER TABLE `time_zones` DISABLE KEYS */;
INSERT INTO `time_zones` VALUES (1,'CI','Africa/Abidjan',0,0,0),(2,'GH','Africa/Accra',0,0,0),(3,'ET','Africa/Addis_Ababa',3,3,3),(4,'DZ','Africa/Algiers',1,1,1),(5,'ER','Africa/Asmara',3,3,3),(6,'ML','Africa/Bamako',0,0,0),(7,'CF','Africa/Bangui',1,1,1),(8,'GM','Africa/Banjul',0,0,0),(9,'GW','Africa/Bissau',0,0,0),(10,'MW','Africa/Blantyre',2,2,2),(11,'CG','Africa/Brazzaville',1,1,1),(12,'BI','Africa/Bujumbura',2,2,2),(13,'EG','Africa/Cairo',2,2,2),(14,'MA','Africa/Casablanca',0,1,0),(15,'ES','Africa/Ceuta',1,2,1),(16,'GN','Africa/Conakry',0,0,0),(17,'SN','Africa/Dakar',0,0,0),(18,'TZ','Africa/Dar_es_Salaam',3,3,3),(19,'DJ','Africa/Djibouti',3,3,3),(20,'CM','Africa/Douala',1,1,1),(21,'EH','Africa/El_Aaiun',0,1,0),(22,'SL','Africa/Freetown',0,0,0),(23,'BW','Africa/Gaborone',2,2,2),(24,'ZW','Africa/Harare',2,2,2),(25,'ZA','Africa/Johannesburg',2,2,2),(26,'SS','Africa/Juba',3,3,3),(27,'UG','Africa/Kampala',3,3,3),(28,'SD','Africa/Khartoum',3,3,3),(29,'RW','Africa/Kigali',2,2,2),(30,'CD','Africa/Kinshasa',1,1,1),(31,'NG','Africa/Lagos',1,1,1),(32,'GA','Africa/Libreville',1,1,1),(33,'TG','Africa/Lome',0,0,0),(34,'AO','Africa/Luanda',1,1,1),(35,'CD','Africa/Lubumbashi',2,2,2),(36,'ZM','Africa/Lusaka',2,2,2),(37,'GQ','Africa/Malabo',1,1,1),(38,'MZ','Africa/Maputo',2,2,2),(39,'LS','Africa/Maseru',2,2,2),(40,'SZ','Africa/Mbabane',2,2,2),(41,'SO','Africa/Mogadishu',3,3,3),(42,'LR','Africa/Monrovia',0,0,0),(43,'KE','Africa/Nairobi',3,3,3),(44,'TD','Africa/Ndjamena',1,1,1),(45,'NE','Africa/Niamey',1,1,1),(46,'MR','Africa/Nouakchott',0,0,0),(47,'BF','Africa/Ouagadougou',0,0,0),(48,'BJ','Africa/Porto-Novo',1,1,1),(49,'ST','Africa/Sao_Tome',0,0,0),(50,'LY','Africa/Tripoli',2,2,2),(51,'TN','Africa/Tunis',1,1,1),(52,'NA','Africa/Windhoek',2,1,1),(53,'US','America/Adak',-10,-9,-10),(54,'US','America/Anchorage',-9,-8,-9),(55,'AI','America/Anguilla',-4,-4,-4),(56,'AG','America/Antigua',-4,-4,-4),(57,'BR','America/Araguaina',-3,-3,-3),(58,'AR','America/Argentina/Buenos_Aires',-3,-3,-3),(59,'AR','America/Argentina/Catamarca',-3,-3,-3),(60,'AR','America/Argentina/Cordoba',-3,-3,-3),(61,'AR','America/Argentina/Jujuy',-3,-3,-3),(62,'AR','America/Argentina/La_Rioja',-3,-3,-3),(63,'AR','America/Argentina/Mendoza',-3,-3,-3),(64,'AR','America/Argentina/Rio_Gallegos',-3,-3,-3),(65,'AR','America/Argentina/Salta',-3,-3,-3),(66,'AR','America/Argentina/San_Juan',-3,-3,-3),(67,'AR','America/Argentina/San_Luis',-3,-3,-3),(68,'AR','America/Argentina/Tucuman',-3,-3,-3),(69,'AR','America/Argentina/Ushuaia',-3,-3,-3),(70,'AW','America/Aruba',-4,-4,-4),(71,'PY','America/Asuncion',-3,-4,-4),(72,'CA','America/Atikokan',-5,-5,-5),(73,'BR','America/Bahia',-3,-3,-3),(74,'MX','America/Bahia_Banderas',-6,-5,-6),(75,'BB','America/Barbados',-4,-4,-4),(76,'BR','America/Belem',-3,-3,-3),(77,'BZ','America/Belize',-6,-6,-6),(78,'CA','America/Blanc-Sablon',-4,-4,-4),(79,'BR','America/Boa_Vista',-4,-4,-4),(80,'CO','America/Bogota',-5,-5,-5),(81,'US','America/Boise',-7,-6,-7),(82,'CA','America/Cambridge_Bay',-7,-6,-7),(83,'BR','America/Campo_Grande',-3,-4,-4),(84,'MX','America/Cancun',-5,-5,-5),(85,'VE','America/Caracas',-4,-4,-4),(86,'GF','America/Cayenne',-3,-3,-3),(87,'KY','America/Cayman',-5,-5,-5),(88,'US','America/Chicago',-6,-5,-6),(89,'MX','America/Chihuahua',-7,-6,-7),(90,'CR','America/Costa_Rica',-6,-6,-6),(91,'CA','America/Creston',-7,-7,-7),(92,'BR','America/Cuiaba',-3,-4,-4),(93,'CW','America/Curacao',-4,-4,-4),(94,'GL','America/Danmarkshavn',0,0,0),(95,'CA','America/Dawson',-8,-7,-8),(96,'CA','America/Dawson_Creek',-7,-7,-7),(97,'US','America/Denver',-7,-6,-7),(98,'US','America/Detroit',-5,-4,-5),(99,'DM','America/Dominica',-4,-4,-4),(100,'CA','America/Edmonton',-7,-6,-7),(101,'BR','America/Eirunepe',-5,-5,-5),(102,'SV','America/El_Salvador',-6,-6,-6),(103,'CA','America/Fort_Nelson',-7,-7,-7),(104,'BR','America/Fortaleza',-3,-3,-3),(105,'CA','America/Glace_Bay',-4,-3,-4),(106,'GL','America/Godthab',-3,-2,-3),(107,'CA','America/Goose_Bay',-4,-3,-4),(108,'TC','America/Grand_Turk',-4,-4,-4),(109,'GD','America/Grenada',-4,-4,-4),(110,'GP','America/Guadeloupe',-4,-4,-4),(111,'GT','America/Guatemala',-6,-6,-6),(112,'EC','America/Guayaquil',-5,-5,-5),(113,'GY','America/Guyana',-4,-4,-4),(114,'CA','America/Halifax',-4,-3,-4),(115,'CU','America/Havana',-5,-4,-5),(116,'MX','America/Hermosillo',-7,-7,-7),(117,'US','America/Indiana/Indianapolis',-5,-4,-5),(118,'US','America/Indiana/Knox',-6,-5,-6),(119,'US','America/Indiana/Marengo',-5,-4,-5),(120,'US','America/Indiana/Petersburg',-5,-4,-5),(121,'US','America/Indiana/Tell_City',-6,-5,-6),(122,'US','America/Indiana/Vevay',-5,-4,-5),(123,'US','America/Indiana/Vincennes',-5,-4,-5),(124,'US','America/Indiana/Winamac',-5,-4,-5),(125,'CA','America/Inuvik',-7,-6,-7),(126,'CA','America/Iqaluit',-5,-4,-5),(127,'JM','America/Jamaica',-5,-5,-5),(128,'US','America/Juneau',-9,-8,-9),(129,'US','America/Kentucky/Louisville',-5,-4,-5),(130,'US','America/Kentucky/Monticello',-5,-4,-5),(131,'BQ','America/Kralendijk',-4,-4,-4),(132,'BO','America/La_Paz',-4,-4,-4),(133,'PE','America/Lima',-5,-5,-5),(134,'US','America/Los_Angeles',-8,-7,-8),(135,'SX','America/Lower_Princes',-4,-4,-4),(136,'BR','America/Maceio',-3,-3,-3),(137,'NI','America/Managua',-6,-6,-6),(138,'BR','America/Manaus',-4,-4,-4),(139,'MF','America/Marigot',-4,-4,-4),(140,'MQ','America/Martinique',-4,-4,-4),(141,'MX','America/Matamoros',-6,-5,-6),(142,'MX','America/Mazatlan',-7,-6,-7),(143,'US','America/Menominee',-6,-5,-6),(144,'MX','America/Merida',-6,-5,-6),(145,'US','America/Metlakatla',-9,-8,-9),(146,'MX','America/Mexico_City',-6,-5,-6),(147,'PM','America/Miquelon',-3,-2,-3),(148,'CA','America/Moncton',-4,-3,-4),(149,'MX','America/Monterrey',-6,-5,-6),(150,'UY','America/Montevideo',-3,-3,-3),(151,'MS','America/Montserrat',-4,-4,-4),(152,'BS','America/Nassau',-5,-4,-5),(153,'US','America/New_York',-5,-4,-5),(154,'CA','America/Nipigon',-5,-4,-5),(155,'US','America/Nome',-9,-8,-9),(156,'BR','America/Noronha',-2,-2,-2),(157,'US','America/North_Dakota/Beulah',-6,-5,-6),(158,'US','America/North_Dakota/Center',-6,-5,-6),(159,'US','America/North_Dakota/New_Salem',-6,-5,-6),(160,'MX','America/Ojinaga',-7,-6,-7),(161,'PA','America/Panama',-5,-5,-5),(162,'CA','America/Pangnirtung',-5,-4,-5),(163,'SR','America/Paramaribo',-3,-3,-3),(164,'US','America/Phoenix',-7,-7,-7),(165,'HT','America/Port-au-Prince',-5,-4,-5),(166,'TT','America/Port_of_Spain',-4,-4,-4),(167,'BR','America/Porto_Velho',-4,-4,-4),(168,'PR','America/Puerto_Rico',-4,-4,-4),(169,'CL','America/Punta_Arenas',-3,-3,-3),(170,'CA','America/Rainy_River',-6,-5,-6),(171,'CA','America/Rankin_Inlet',-6,-5,-6),(172,'BR','America/Recife',-3,-3,-3),(173,'CA','America/Regina',-6,-6,-6),(174,'CA','America/Resolute',-6,-5,-6),(175,'BR','America/Rio_Branco',-5,-5,-5),(176,'BR','America/Santarem',-3,-3,-3),(177,'CL','America/Santiago',-3,-4,-4),(178,'DO','America/Santo_Domingo',-4,-4,-4),(179,'BR','America/Sao_Paulo',-2,-3,-3),(180,'GL','America/Scoresbysund',-1,0,-1),(181,'US','America/Sitka',-9,-8,-9),(182,'BL','America/St_Barthelemy',-4,-4,-4),(183,'CA','America/St_Johns',-3.5,-2.5,-3.5),(184,'KN','America/St_Kitts',-4,-4,-4),(185,'LC','America/St_Lucia',-4,-4,-4),(186,'VI','America/St_Thomas',-4,-4,-4),(187,'VC','America/St_Vincent',-4,-4,-4),(188,'CA','America/Swift_Current',-6,-6,-6),(189,'HN','America/Tegucigalpa',-6,-6,-6),(190,'GL','America/Thule',-4,-3,-4),(191,'CA','America/Thunder_Bay',-5,-4,-5),(192,'MX','America/Tijuana',-8,-7,-8),(193,'CA','America/Toronto',-5,-4,-5),(194,'VG','America/Tortola',-4,-4,-4),(195,'CA','America/Vancouver',-8,-7,-8),(196,'CA','America/Whitehorse',-8,-7,-8),(197,'CA','America/Winnipeg',-6,-5,-6),(198,'US','America/Yakutat',-9,-8,-9),(199,'CA','America/Yellowknife',-7,-6,-7),(200,'AQ','Antarctica/Casey',11,11,11),(201,'AQ','Antarctica/Davis',7,7,7),(202,'AQ','Antarctica/DumontDUrville',10,10,10),(203,'AU','Antarctica/Macquarie',11,11,11),(204,'AQ','Antarctica/Mawson',5,5,5),(205,'AQ','Antarctica/McMurdo',13,12,12),(206,'AQ','Antarctica/Palmer',-3,-3,-3),(207,'AQ','Antarctica/Rothera',-3,-3,-3),(208,'AQ','Antarctica/Syowa',3,3,3),(209,'AQ','Antarctica/Troll',0,2,0),(210,'AQ','Antarctica/Vostok',6,6,6),(211,'SJ','Arctic/Longyearbyen',1,2,1),(212,'YE','Asia/Aden',3,3,3),(213,'KZ','Asia/Almaty',6,6,6),(214,'JO','Asia/Amman',2,3,2),(215,'RU','Asia/Anadyr',12,12,12),(216,'KZ','Asia/Aqtau',5,5,5),(217,'KZ','Asia/Aqtobe',5,5,5),(218,'TM','Asia/Ashgabat',5,5,5),(219,'KZ','Asia/Atyrau',5,5,5),(220,'IQ','Asia/Baghdad',3,3,3),(221,'BH','Asia/Bahrain',3,3,3),(222,'AZ','Asia/Baku',4,4,4),(223,'TH','Asia/Bangkok',7,7,7),(224,'RU','Asia/Barnaul',7,7,7),(225,'LB','Asia/Beirut',2,3,2),(226,'KG','Asia/Bishkek',6,6,6),(227,'BN','Asia/Brunei',8,8,8),(228,'RU','Asia/Chita',9,9,9),(229,'MN','Asia/Choibalsan',8,8,8),(230,'LK','Asia/Colombo',5.5,5.5,5.5),(231,'SY','Asia/Damascus',2,3,2),(232,'BD','Asia/Dhaka',6,6,6),(233,'TL','Asia/Dili',9,9,9),(234,'AE','Asia/Dubai',4,4,4),(235,'TJ','Asia/Dushanbe',5,5,5),(236,'CY','Asia/Famagusta',3,3,3),(237,'PS','Asia/Gaza',2,3,2),(238,'PS','Asia/Hebron',2,3,2),(239,'VN','Asia/Ho_Chi_Minh',7,7,7),(240,'HK','Asia/Hong_Kong',8,8,8),(241,'MN','Asia/Hovd',7,7,7),(242,'RU','Asia/Irkutsk',8,8,8),(243,'ID','Asia/Jakarta',7,7,7),(244,'ID','Asia/Jayapura',9,9,9),(245,'IL','Asia/Jerusalem',2,3,2),(246,'AF','Asia/Kabul',4.5,4.5,4.5),(247,'RU','Asia/Kamchatka',12,12,12),(248,'PK','Asia/Karachi',5,5,5),(249,'NP','Asia/Kathmandu',5.75,5.75,5.75),(250,'RU','Asia/Khandyga',9,9,9),(251,'IN','Asia/Kolkata',5.5,5.5,5.5),(252,'RU','Asia/Krasnoyarsk',7,7,7),(253,'MY','Asia/Kuala_Lumpur',8,8,8),(254,'MY','Asia/Kuching',8,8,8),(255,'KW','Asia/Kuwait',3,3,3),(256,'MO','Asia/Macau',8,8,8),(257,'RU','Asia/Magadan',11,11,11),(258,'ID','Asia/Makassar',8,8,8),(259,'PH','Asia/Manila',8,8,8),(260,'OM','Asia/Muscat',4,4,4),(261,'CY','Asia/Nicosia',2,3,2),(262,'RU','Asia/Novokuznetsk',7,7,7),(263,'RU','Asia/Novosibirsk',7,7,7),(264,'RU','Asia/Omsk',6,6,6),(265,'KZ','Asia/Oral',5,5,5),(266,'KH','Asia/Phnom_Penh',7,7,7),(267,'ID','Asia/Pontianak',7,7,7),(268,'KP','Asia/Pyongyang',8.5,8.5,8.5),(269,'QA','Asia/Qatar',3,3,3),(270,'KZ','Asia/Qyzylorda',6,6,6),(271,'SA','Asia/Riyadh',3,3,3),(272,'RU','Asia/Sakhalin',11,11,11),(273,'UZ','Asia/Samarkand',5,5,5),(274,'KR','Asia/Seoul',9,9,9),(275,'CN','Asia/Shanghai',8,8,8),(276,'SG','Asia/Singapore',8,8,8),(277,'RU','Asia/Srednekolymsk',11,11,11),(278,'TW','Asia/Taipei',8,8,8),(279,'UZ','Asia/Tashkent',5,5,5),(280,'GE','Asia/Tbilisi',4,4,4),(281,'IR','Asia/Tehran',3.5,4.5,3.5),(282,'BT','Asia/Thimphu',6,6,6),(283,'JP','Asia/Tokyo',9,9,9),(284,'RU','Asia/Tomsk',7,7,7),(285,'MN','Asia/Ulaanbaatar',8,8,8),(286,'CN','Asia/Urumqi',6,6,6),(287,'RU','Asia/Ust-Nera',10,10,10),(288,'LA','Asia/Vientiane',7,7,7),(289,'RU','Asia/Vladivostok',10,10,10),(290,'RU','Asia/Yakutsk',9,9,9),(291,'MM','Asia/Yangon',6.5,6.5,6.5),(292,'RU','Asia/Yekaterinburg',5,5,5),(293,'AM','Asia/Yerevan',4,4,4),(294,'PT','Atlantic/Azores',-1,0,-1),(295,'BM','Atlantic/Bermuda',-4,-3,-4),(296,'ES','Atlantic/Canary',0,1,0),(297,'CV','Atlantic/Cape_Verde',-1,-1,-1),(298,'FO','Atlantic/Faroe',0,1,0),(299,'PT','Atlantic/Madeira',0,1,0),(300,'IS','Atlantic/Reykjavik',0,0,0),(301,'GS','Atlantic/South_Georgia',-2,-2,-2),(302,'SH','Atlantic/St_Helena',0,0,0),(303,'FK','Atlantic/Stanley',-3,-3,-3),(304,'AU','Australia/Adelaide',10.5,9.5,9.5),(305,'AU','Australia/Brisbane',10,10,10),(306,'AU','Australia/Broken_Hill',10.5,9.5,9.5),(307,'AU','Australia/Currie',11,10,10),(308,'AU','Australia/Darwin',9.5,9.5,9.5),(309,'AU','Australia/Eucla',8.75,8.75,8.75),(310,'AU','Australia/Hobart',11,10,10),(311,'AU','Australia/Lindeman',10,10,10),(312,'AU','Australia/Lord_Howe',11,10.5,10.5),(313,'AU','Australia/Melbourne',11,10,10),(314,'AU','Australia/Perth',8,8,8),(315,'AU','Australia/Sydney',11,10,10),(316,'NL','Europe/Amsterdam',1,2,1),(317,'AD','Europe/Andorra',1,2,1),(318,'RU','Europe/Astrakhan',4,4,4),(319,'GR','Europe/Athens',2,3,2),(320,'RS','Europe/Belgrade',1,2,1),(321,'DE','Europe/Berlin',1,2,1),(322,'SK','Europe/Bratislava',1,2,1),(323,'BE','Europe/Brussels',1,2,1),(324,'RO','Europe/Bucharest',2,3,2),(325,'HU','Europe/Budapest',1,2,1),(326,'DE','Europe/Busingen',1,2,1),(327,'MD','Europe/Chisinau',2,3,2),(328,'DK','Europe/Copenhagen',1,2,1),(329,'IE','Europe/Dublin',0,1,0),(330,'GI','Europe/Gibraltar',1,2,1),(331,'GG','Europe/Guernsey',0,1,0),(332,'FI','Europe/Helsinki',2,3,2),(333,'IM','Europe/Isle_of_Man',0,1,0),(334,'TR','Europe/Istanbul',3,3,3),(335,'JE','Europe/Jersey',0,1,0),(336,'RU','Europe/Kaliningrad',2,2,2),(337,'UA','Europe/Kiev',2,3,2),(338,'RU','Europe/Kirov',3,3,3),(339,'PT','Europe/Lisbon',0,1,0),(340,'SI','Europe/Ljubljana',1,2,1),(341,'UK','Europe/London',0,1,0),(342,'LU','Europe/Luxembourg',1,2,1),(343,'ES','Europe/Madrid',1,2,1),(344,'MT','Europe/Malta',1,2,1),(345,'AX','Europe/Mariehamn',2,3,2),(346,'BY','Europe/Minsk',3,3,3),(347,'MC','Europe/Monaco',1,2,1),(348,'RU','Europe/Moscow',3,3,3),(349,'NO','Europe/Oslo',1,2,1),(350,'FR','Europe/Paris',1,2,1),(351,'ME','Europe/Podgorica',1,2,1),(352,'CZ','Europe/Prague',1,2,1),(353,'LV','Europe/Riga',2,3,2),(354,'IT','Europe/Rome',1,2,1),(355,'RU','Europe/Samara',4,4,4),(356,'SM','Europe/San_Marino',1,2,1),(357,'BA','Europe/Sarajevo',1,2,1),(358,'RU','Europe/Saratov',4,4,4),(359,'RU','Europe/Simferopol',3,3,3),(360,'MK','Europe/Skopje',1,2,1),(361,'BG','Europe/Sofia',2,3,2),(362,'SE','Europe/Stockholm',1,2,1),(363,'EE','Europe/Tallinn',2,3,2),(364,'AL','Europe/Tirane',1,2,1),(365,'RU','Europe/Ulyanovsk',4,4,4),(366,'UA','Europe/Uzhgorod',2,3,2),(367,'LI','Europe/Vaduz',1,2,1),(368,'VA','Europe/Vatican',1,2,1),(369,'AT','Europe/Vienna',1,2,1),(370,'LT','Europe/Vilnius',2,3,2),(371,'RU','Europe/Volgograd',3,3,3),(372,'PL','Europe/Warsaw',1,2,1),(373,'HR','Europe/Zagreb',1,2,1),(374,'UA','Europe/Zaporozhye',2,3,2),(375,'CH','Europe/Zurich',1,2,1),(376,'MG','Indian/Antananarivo',3,3,3),(377,'IO','Indian/Chagos',6,6,6),(378,'CX','Indian/Christmas',7,7,7),(379,'CC','Indian/Cocos',6.5,6.5,6.5),(380,'KM','Indian/Comoro',3,3,3),(381,'TF','Indian/Kerguelen',5,5,5),(382,'SC','Indian/Mahe',4,4,4),(383,'MV','Indian/Maldives',5,5,5),(384,'MU','Indian/Mauritius',4,4,4),(385,'YT','Indian/Mayotte',3,3,3),(386,'RE','Indian/Reunion',4,4,4),(387,'WS','Pacific/Apia',14,13,13),(388,'NZ','Pacific/Auckland',13,12,12),(389,'PG','Pacific/Bougainville',11,11,11),(390,'NZ','Pacific/Chatham',13.75,12.75,12.75),(391,'FM','Pacific/Chuuk',10,10,10),(392,'CL','Pacific/Easter',-5,-6,-6),(393,'VU','Pacific/Efate',11,11,11),(394,'KI','Pacific/Enderbury',13,13,13),(395,'TK','Pacific/Fakaofo',13,13,13),(396,'FJ','Pacific/Fiji',13,12,12),(397,'TV','Pacific/Funafuti',12,12,12),(398,'EC','Pacific/Galapagos',-6,-6,-6),(399,'PF','Pacific/Gambier',-9,-9,-9),(400,'SB','Pacific/Guadalcanal',11,11,11),(401,'GU','Pacific/Guam',10,10,10),(402,'US','Pacific/Honolulu',-10,-10,-10),(403,'KI','Pacific/Kiritimati',14,14,14),(404,'FM','Pacific/Kosrae',11,11,11),(405,'MH','Pacific/Kwajalein',12,12,12),(406,'MH','Pacific/Majuro',12,12,12),(407,'PF','Pacific/Marquesas',-9.5,-9.5,-9.5),(408,'UM','Pacific/Midway',-11,-11,-11),(409,'NR','Pacific/Nauru',12,12,12),(410,'NU','Pacific/Niue',-11,-11,-11),(411,'NF','Pacific/Norfolk',11,11,11),(412,'NC','Pacific/Noumea',11,11,11),(413,'AS','Pacific/Pago_Pago',-11,-11,-11),(414,'PW','Pacific/Palau',9,9,9),(415,'PN','Pacific/Pitcairn',-8,-8,-8),(416,'FM','Pacific/Pohnpei',11,11,11),(417,'PG','Pacific/Port_Moresby',10,10,10),(418,'CK','Pacific/Rarotonga',-10,-10,-10),(419,'MP','Pacific/Saipan',10,10,10),(420,'PF','Pacific/Tahiti',-10,-10,-10),(421,'KI','Pacific/Tarawa',12,12,12),(422,'TO','Pacific/Tongatapu',14,13,13),(423,'UM','Pacific/Wake',12,12,12),(424,'WF','Pacific/Wallis',12,12,12);
/*!40000 ALTER TABLE `time_zones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_types`
--

DROP TABLE IF EXISTS `user_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_types` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `active` tinyint(1) unsigned DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `user_types_active_index` (`active`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_types`
--

LOCK TABLES `user_types` WRITE;
/*!40000 ALTER TABLE `user_types` DISABLE KEYS */;
INSERT INTO `user_types` VALUES (1,'Professional',1),(2,'Individual',1);
/*!40000 ALTER TABLE `user_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `country_code` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language_code` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_type_id` tinyint(3) unsigned DEFAULT NULL,
  `gender_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `about` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone_hidden` tinyint(1) unsigned DEFAULT '0',
  `username` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_admin` tinyint(1) unsigned DEFAULT '0',
  `can_be_impersonated` tinyint(1) unsigned DEFAULT '1',
  `disable_comments` tinyint(1) unsigned DEFAULT '0',
  `ip_addr` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `provider` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'facebook, google, twitter, linkedin, ...',
  `provider_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Provider User ID',
  `email_token` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone_token` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `verified_email` tinyint(1) unsigned DEFAULT '1',
  `verified_phone` tinyint(1) unsigned DEFAULT '1',
  `accept_terms` tinyint(1) DEFAULT '0',
  `accept_marketing_offers` tinyint(1) DEFAULT '0',
  `blocked` tinyint(1) unsigned DEFAULT '0',
  `closed` tinyint(1) unsigned DEFAULT '0',
  `last_login_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `users_country_code_index` (`country_code`),
  KEY `users_user_type_id_index` (`user_type_id`),
  KEY `users_gender_id_index` (`gender_id`),
  KEY `users_verified_email_index` (`verified_email`),
  KEY `users_verified_phone_index` (`verified_phone`),
  KEY `users_username_index` (`username`),
  KEY `users_phone_index` (`phone`),
  KEY `users_email_index` (`email`),
  KEY `users_is_admin_index` (`is_admin`),
  KEY `users_can_be_impersonated_index` (`can_be_impersonated`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'NA',NULL,1,1,'Paul',NULL,'Administrator',NULL,0,NULL,'paul@parezagroup.com',NULL,'$2y$10$BM3wrgJl3kjdBc/BCdIS9.0.jWPRyQR6wst/m0EeFEZd6gKufYUAm',NULL,NULL,1,0,NULL,NULL,NULL,NULL,NULL,1,1,0,0,0,0,'2021-02-10 10:08:46',NULL,'2020-12-02 04:58:32','2021-02-10 09:08:46'),(2,'ZM',NULL,NULL,1,'Paul Lokende',NULL,NULL,'+260968341554',1,NULL,'paullokende@gmail.com',NULL,'$2y$10$Z4JSFDTOUrx3BZrNmlXEUOkz7fBPxdWNqM8b4gLdsL5mA.aY3e2ki',NULL,1,1,0,NULL,NULL,NULL,NULL,NULL,1,1,0,0,0,0,'2020-12-07 21:11:08',NULL,'2020-12-02 10:41:28','2020-12-07 20:11:08'),(4,'NA','en',NULL,NULL,'Mwerenga Nicky',NULL,NULL,'0974327259',NULL,NULL,'nicky@parezagroup.com',NULL,'$2y$10$DijSSVFBhaKFuHT4xfw77Ot9tAcRl5H1msL0ep1PqudqRwyz3mDYC',NULL,0,1,0,'41.174.40.74',NULL,NULL,NULL,NULL,1,1,1,1,0,0,NULL,NULL,'2020-12-08 07:17:03','2020-12-08 07:17:03'),(5,'NA','en',NULL,2,'Chazi',NULL,NULL,'761270181',1,'Chazi','chama@parezagroup.com',NULL,'$2y$10$BBW4FRwbOMi8lBQLqqL5FOEQOi72gY81umAGaosAg7VU.5V24Jaay',NULL,0,1,0,'165.56.181.187',NULL,NULL,NULL,NULL,1,1,1,1,0,0,NULL,NULL,'2020-12-08 09:30:18','2020-12-08 09:31:05'),(6,'NA',NULL,NULL,1,'Benny Josea',NULL,NULL,NULL,0,NULL,'ben@parezagroup.com',NULL,'$2y$10$XOnPkMuNGqKinrDwoDo/guGb9F/3iPps09u2QFY5/LpulWzIBdVA.',NULL,1,1,0,NULL,NULL,NULL,NULL,NULL,1,1,0,0,0,0,'2021-02-14 15:10:18',NULL,'2020-12-11 18:16:11','2021-02-14 14:10:18'),(7,'NA','en',NULL,5,'Marjorie',NULL,NULL,'+264812474528',NULL,'Jollies','mnjollies@gmail.com',NULL,'$2y$10$XnjpqXA9j9y7XYmQgX6ZlucHIr0oXiMkjiJMjDW1t6n5q/o.Y51m6',NULL,0,1,0,'105.232.2.87',NULL,NULL,NULL,NULL,1,1,1,0,0,0,NULL,NULL,'2021-01-03 19:30:35','2021-01-03 19:32:57'),(8,'NA','en',NULL,5,'Melzi',NULL,NULL,'+264816280395',1,'Melzi','melodydoeses@gmail.com',NULL,'$2y$10$Ym66mRJ2BvUL8sxyopeGCuCm0CrREROYyhULuDVZLG1Ain.bHUaKi',NULL,0,1,0,'41.182.23.165',NULL,NULL,NULL,NULL,1,1,1,0,0,0,NULL,NULL,'2021-01-04 14:42:15','2021-01-04 14:43:11'),(9,'NA','en',NULL,NULL,'Hendrina',NULL,NULL,'+264857369849',NULL,NULL,'hendrinafirstlady@gmail.com',NULL,'$2y$10$bOmCtag125zLt7oaUMuC9e9egBA9ONVwIiOGRCKt/N.ucJoQJgjUi',NULL,0,1,0,'105.232.28.114',NULL,NULL,NULL,NULL,1,1,1,1,0,0,NULL,NULL,'2021-01-04 15:00:13','2021-01-04 15:00:13'),(10,'NA','en',NULL,5,'Ndina Jonas','avatars/na/10/1fd3e19c84290ad49b4fa7810ceb2ba6.jpeg',NULL,'+264813049244',NULL,'Njhair124','Ndinajonas20@gmail.com',NULL,'$2y$10$xHkUV.0RIHoqmCNXNbril.oYxHdwq9tdSkwCJ6eX.QlU8zpLNmyC2',NULL,0,1,0,'105.232.255.172',NULL,NULL,NULL,NULL,1,1,1,1,0,0,NULL,NULL,'2021-01-05 23:15:49','2021-01-05 23:20:41'),(15,'NA','en',NULL,NULL,'Trusted spell caster Mponye',NULL,NULL,'+27718452838',NULL,NULL,'mama.mponye@gmail.com',NULL,'$2y$10$9OIB/KwwGVvi4OktGoD46Owul5G0108uKTSYpG4JT0cXTZvMjFtDq',NULL,0,1,0,'41.193.253.128',NULL,NULL,NULL,NULL,1,1,1,1,0,0,NULL,NULL,'2021-03-05 04:51:36','2021-03-05 04:51:36');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-11 18:19:29

